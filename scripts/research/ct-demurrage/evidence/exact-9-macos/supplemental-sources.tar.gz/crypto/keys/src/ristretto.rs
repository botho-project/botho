// Copyright (c) 2018-2024 The Botho Foundation

#![allow(non_snake_case)]

use crate::{
    compat::Rng06Compat, GenericArray, Kex, KexEphemeralPrivate, KexPrivate, KexPublic,
    KexReusablePrivate, KexSecret, KeyError, PrivateKey, PublicKey, SignatureEncoding,
    SignatureError,
};
use bth_crypto_digestible::{Digestible, MerlinTranscript};
use bth_crypto_digestible_signature::{DigestibleSigner, DigestibleVerifier};
use bth_util_from_random::FromRandom;
use bth_util_repr_bytes::{
    derive_core_cmp_from_as_ref, derive_debug_and_display_hex_from_as_ref,
    derive_repr_bytes_from_as_ref_and_try_from, derive_try_from_slice_from_repr_bytes, ReprBytes,
};
use core::{
    cmp::Ordering,
    fmt::{Debug, Display, Formatter, Result as FmtResult},
    hash::{Hash, Hasher},
};
use curve25519_dalek::{
    constants::RISTRETTO_BASEPOINT_POINT,
    ristretto::{CompressedRistretto, RistrettoPoint},
    scalar::Scalar,
};
use digest::generic_array::typenum::{U32, U64};
use hex_fmt::HexFmt;
use rand_core::{CryptoRng, SeedableRng};
use rand_hc::Hc128Rng;
use schnorrkel_og::{
    context::attach_rng, PublicKey as SchnorrkelPublic, SecretKey as SchnorrkelPrivate,
    Signature as SchnorrkelSignature, SignatureError as SchnorrkelError, SIGNATURE_LENGTH,
};

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

#[cfg(feature = "serde")]
use bth_util_repr_bytes::derive_serde_from_repr_bytes;

#[cfg(feature = "alloc")]
use bth_util_repr_bytes::derive_into_vec_from_repr_bytes;

#[cfg(feature = "prost")]
use bth_util_repr_bytes::derive_prost_message_from_repr_bytes;

use subtle::{Choice, ConstantTimeEq};
use zeroize::Zeroize;

/// Draw a uniformly random `Scalar` from a rand_core 0.6 CSPRNG.
///
/// This is exactly what curve25519-dalek's `Scalar::random` does (64 bytes,
/// reduced mod the group order); dalek 5's version requires rand_core 0.10
/// traits, which the workspace does not use yet (#1154).
fn random_scalar<R: CryptoRng>(csprng: &mut R) -> Scalar {
    let mut bytes = [0u8; 64];
    csprng.fill_bytes(&mut bytes);
    Scalar::from_bytes_mod_order_wide(&bytes)
}

/// Draw a uniformly random `RistrettoPoint` from a rand_core 0.6 CSPRNG.
///
/// This is exactly what curve25519-dalek's `RistrettoPoint::random` does
/// (64 bytes through the one-way uniform map); dalek 5's version requires
/// rand_core 0.10 traits, which the workspace does not use yet (#1154).
fn random_ristretto_point<R: CryptoRng>(csprng: &mut R) -> RistrettoPoint {
    let mut bytes = [0u8; 64];
    csprng.fill_bytes(&mut bytes);
    RistrettoPoint::from_uniform_bytes(&bytes)
}

/// A Ristretto-format private scalar
#[derive(Clone, Copy, Default, Digestible, Zeroize)]
#[digestible(transparent)]
pub struct RistrettoPrivate(pub(crate) Scalar);

impl Eq for RistrettoPrivate {}

impl PartialEq for RistrettoPrivate {
    fn eq(&self, other: &Self) -> bool {
        self.ct_eq(other).unwrap_u8() == 1u8
    }
}

impl AsRef<[u8; 32]> for RistrettoPrivate {
    fn as_ref(&self) -> &[u8; 32] {
        self.0.as_bytes()
    }
}

impl TryFrom<&[u8; 32]> for RistrettoPrivate {
    type Error = KeyError;

    fn try_from(src: &[u8; 32]) -> Result<Self, KeyError> {
        Ok(Self(
            Option::from(Scalar::from_canonical_bytes(*src)).ok_or(KeyError::InvalidPrivateKey)?,
        ))
    }
}

impl AsRef<[u8]> for RistrettoPrivate {
    fn as_ref(&self) -> &[u8] {
        self.0.as_bytes()
    }
}

impl TryFrom<&[u8]> for RistrettoPrivate {
    type Error = KeyError;
    fn try_from(src: &[u8]) -> Result<Self, KeyError> {
        let bytes: &[u8; 32] = src
            .try_into()
            .map_err(|_| KeyError::LengthMismatch(src.len(), 32))?;
        Self::try_from(bytes)
    }
}

derive_repr_bytes_from_as_ref_and_try_from!(RistrettoPrivate, U32);

#[cfg(feature = "alloc")]
derive_into_vec_from_repr_bytes!(RistrettoPrivate);

#[cfg(feature = "serde")]
derive_serde_from_repr_bytes!(RistrettoPrivate);

#[cfg(feature = "prost")]
derive_prost_message_from_repr_bytes!(RistrettoPrivate);

impl RistrettoPrivate {
    /// This is used by some code that used to use ReprBytes32 API
    /// This is okay in code that is not generic over the key type.
    pub fn to_bytes(&self) -> [u8; 32] {
        *self.0.as_bytes()
    }

    /// Sign the given bytes using a deterministic scheme based on Schnorrkel.
    pub fn sign_schnorrkel(&self, context: &[u8], message: &[u8]) -> RistrettoSignature {
        // Create a deterministic nonce using a merlin transcript. See this crate's
        // README for a security statement.
        let nonce = {
            let mut transcript = MerlinTranscript::new(b"SigningNonce");
            transcript.append_message(b"context", context);
            transcript.append_message(b"private", &self.to_bytes());
            transcript.append_message(b"message", message);
            let mut nonce = [0u8; 32];
            transcript.challenge_bytes(b"nonce", &mut nonce);
            nonce
        };

        // Construct a Schnorrkel SecretKey object from ourselves, and our nonce value
        let mut secret_bytes = [0u8; 64];
        secret_bytes[0..32].copy_from_slice(&self.to_bytes());
        secret_bytes[32..64].copy_from_slice(&nonce);
        let secret_key = SchnorrkelPrivate::from_bytes(&secret_bytes).unwrap();
        let keypair = secret_key.to_keypair();

        // SigningContext provides domain separation for signature
        let mut t = MerlinTranscript::new(b"SigningContext");
        t.append_message(b"", context);
        t.append_message(b"sign-bytes", message);
        // NOTE: This signature is deterministic due to using the above nonce as the rng
        // seed
        let mut csprng = Hc128Rng::from_seed(nonce);
        let transcript = attach_rng(t, Rng06Compat(&mut csprng));
        RistrettoSignature::from(keypair.sign(transcript))
    }

    /// Curve25519-dalek exposes Scalar::from_bytes_mod_order, which is helpful
    /// for converting a hash into a valid scalar, and can be useful at API
    /// boundaries. Callers need not import curve25519-dalek in order to
    /// convert a hash to a valid scalar.
    pub fn from_bytes_mod_order(src: &[u8; 32]) -> Self {
        Self(Scalar::from_bytes_mod_order(*src))
    }
}

impl AsRef<Scalar> for RistrettoPrivate {
    fn as_ref(&self) -> &Scalar {
        &self.0
    }
}

impl From<Scalar> for RistrettoPrivate {
    fn from(scalar: Scalar) -> Self {
        Self(scalar)
    }
}

impl Debug for RistrettoPrivate {
    fn fmt(&self, f: &mut Formatter) -> FmtResult {
        write!(
            f,
            "RistrettoPrivate for pubkey: {:?}",
            RistrettoPublic::from(self)
        )
    }
}

impl<T: Digestible> DigestibleSigner<RistrettoSignature, T> for RistrettoPrivate {
    fn sign_digestible(&self, context: &'static [u8], message: &T) -> RistrettoSignature {
        let message = message.digest32::<MerlinTranscript>(context);
        self.sign_schnorrkel(context, &message)
    }

    fn try_sign_digestible(
        &self,
        context: &'static [u8],
        message: &T,
    ) -> Result<RistrettoSignature, SignatureError> {
        Ok(self.sign_digestible(context, message))
    }
}

impl FromRandom for RistrettoPrivate {
    fn from_random<R: CryptoRng>(csprng: &mut R) -> RistrettoPrivate {
        Self(random_scalar(csprng))
    }
}

impl KexEphemeralPrivate for RistrettoPrivate {
    fn key_exchange(
        self,
        their_public: &<Self as PrivateKey>::Public,
    ) -> <Self as KexPrivate>::Secret {
        RistrettoSecret((self.0 * their_public.0).compress().to_bytes())
    }
}

impl KexReusablePrivate for RistrettoPrivate {
    fn key_exchange(
        &self,
        their_public: &<Self as PrivateKey>::Public,
    ) -> <Self as KexPrivate>::Secret {
        RistrettoSecret((self.0 * their_public.0).compress().to_bytes())
    }
}

impl KexPrivate for RistrettoPrivate {
    type Secret = RistrettoSecret;
}

impl PrivateKey for RistrettoPrivate {
    type Public = RistrettoPublic;
}

impl ConstantTimeEq for RistrettoPrivate {
    fn ct_eq(&self, other: &Self) -> Choice {
        self.0.ct_eq(&other.0)
    }
}

/// A private ristretto key which is ephemeral, should never be copied,
/// and should be zeroized
#[derive(Zeroize)]
#[zeroize(drop)]
pub struct RistrettoEphemeralPrivate(Scalar);

impl PrivateKey for RistrettoEphemeralPrivate {
    type Public = RistrettoPublic;
}

impl KexPrivate for RistrettoEphemeralPrivate {
    type Secret = RistrettoSecret;
}

impl KexEphemeralPrivate for RistrettoEphemeralPrivate {
    fn key_exchange(
        self,
        their_public: &<Self as PrivateKey>::Public,
    ) -> <Self as KexPrivate>::Secret {
        RistrettoSecret((self.0 * their_public.0).compress().to_bytes())
    }
}

impl FromRandom for RistrettoEphemeralPrivate {
    fn from_random<R: CryptoRng>(csprng: &mut R) -> Self {
        Self(random_scalar(csprng))
    }
}

impl Debug for RistrettoEphemeralPrivate {
    fn fmt(&self, f: &mut Formatter) -> FmtResult {
        write!(
            f,
            "RistrettoEphemeralPrivate for {:?}",
            RistrettoPublic::from(self)
        )
    }
}

/// A Ristretto-format curve point for use as a public key
#[derive(Clone, Copy, Default, Digestible, Zeroize)]
#[digestible(transparent)]
pub struct RistrettoPublic(pub(crate) RistrettoPoint);

impl AsRef<RistrettoPoint> for RistrettoPublic {
    fn as_ref(&self) -> &RistrettoPoint {
        &self.0
    }
}

impl FromRandom for RistrettoPublic {
    fn from_random<R: CryptoRng>(csprng: &mut R) -> RistrettoPublic {
        Self(random_ristretto_point(csprng))
    }
}

impl From<RistrettoPoint> for RistrettoPublic {
    fn from(point: RistrettoPoint) -> Self {
        Self(point)
    }
}

impl ReprBytes for RistrettoPublic {
    type Size = U32;
    type Error = KeyError;

    fn from_bytes(src: &GenericArray<u8, U32>) -> Result<Self, KeyError> {
        Ok(Self(
            CompressedRistretto::from_slice(src.as_slice())
                .map_err(|_e| KeyError::InvalidPublicKey)?
                .decompress()
                .ok_or(KeyError::InvalidPublicKey)?,
        ))
    }

    fn to_bytes(&self) -> GenericArray<u8, U32> {
        self.0.compress().to_bytes().into()
    }
}

#[cfg(feature = "serde")]
derive_serde_from_repr_bytes!(RistrettoPublic);

#[cfg(feature = "prost")]
derive_prost_message_from_repr_bytes!(RistrettoPublic);

#[cfg(feature = "alloc")]
derive_into_vec_from_repr_bytes!(RistrettoPublic);

derive_try_from_slice_from_repr_bytes!(RistrettoPublic);

// Many historical APIs assumed TryFrom<&[u8;32]> existed for RistrettoPublic
// This will work fine in code that is not generic over the size of the key
impl TryFrom<&[u8; 32]> for RistrettoPublic {
    type Error = KeyError;
    fn try_from(src: &[u8; 32]) -> Result<Self, KeyError> {
        Self::try_from(&src[..])
    }
}

impl RistrettoPublic {
    // Many historical APIs based on ReprBytes32 in botho use to_bytes() ->
    // [u8;32]. This is okay in non-generic code
    pub fn to_bytes(&self) -> [u8; 32] {
        self.0.compress().to_bytes()
    }

    /// Verify a deterministic Schnorrkel signature created with the
    /// corresponding [`RistrettoPrivate::sign_schnorrkel()`] method.
    pub fn verify_schnorrkel(
        &self,
        context: &'static [u8],
        message: &[u8],
        signature: &RistrettoSignature,
    ) -> Result<(), SchnorrkelError> {
        let ctx = schnorrkel_og::signing_context(context);
        // schnorrkel-og is still on curve25519-dalek 4, so its `from_point`
        // constructor no longer accepts our (dalek 5) `RistrettoPoint`.
        // Round-trip through the canonical compressed encoding instead; this
        // is the same point, at the cost of one decompression.
        let pubkey = SchnorrkelPublic::from_bytes(&self.to_bytes())?;
        pubkey.verify(ctx.bytes(message), &signature.try_into()?)
    }
}

impl PartialOrd for RistrettoPublic {
    fn partial_cmp(&self, other: &RistrettoPublic) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

impl Ord for RistrettoPublic {
    fn cmp(&self, other: &RistrettoPublic) -> Ordering {
        self.to_bytes().cmp(&other.to_bytes())
    }
}

impl Hash for RistrettoPublic {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.to_bytes().hash(state)
    }
}

impl Eq for RistrettoPublic {}
impl PartialEq for RistrettoPublic {
    fn eq(&self, other: &Self) -> bool {
        self.0 == other.0
    }
}

impl PublicKey for RistrettoPublic {}

impl From<&RistrettoPrivate> for RistrettoPublic {
    fn from(private: &RistrettoPrivate) -> Self {
        let x = private.0;
        let G = RISTRETTO_BASEPOINT_POINT;
        let Y = x * G;

        Self(Y)
    }
}

impl From<&RistrettoEphemeralPrivate> for RistrettoPublic {
    fn from(private: &RistrettoEphemeralPrivate) -> Self {
        let x = private.0;
        let G = RISTRETTO_BASEPOINT_POINT;
        let Y = x * G;

        Self(Y)
    }
}

impl<T: Digestible> DigestibleVerifier<RistrettoSignature, T> for RistrettoPublic {
    fn verify_digestible(
        &self,
        context: &'static [u8],
        message: &T,
        signature: &RistrettoSignature,
    ) -> Result<(), SignatureError> {
        let message = message.digest32::<MerlinTranscript>(context);
        self.verify_schnorrkel(context, &message, signature)
            .map_err(|_e| SignatureError::new())
    }
}

impl Debug for RistrettoPublic {
    fn fmt(&self, f: &mut Formatter) -> FmtResult {
        write!(f, "RistrettoPublic({})", HexFmt(self.to_bytes()))
    }
}

impl Display for RistrettoPublic {
    fn fmt(&self, f: &mut Formatter) -> FmtResult {
        write!(f, "{}", HexFmt(self.to_bytes()))
    }
}

#[cfg(feature = "alloc")]
impl From<&RistrettoPublic> for alloc::vec::Vec<u8> {
    fn from(src: &RistrettoPublic) -> alloc::vec::Vec<u8> {
        let compressed = src.as_ref().compress();
        alloc::vec::Vec::from(&compressed.as_bytes()[..])
    }
}

impl KexPublic for RistrettoPublic {
    type KexEphemeralPrivate = RistrettoEphemeralPrivate;
}

impl TryFrom<&CompressedRistrettoPublic> for RistrettoPublic {
    type Error = KeyError;
    fn try_from(src: &CompressedRistrettoPublic) -> Result<Self, KeyError> {
        Ok(Self(src.0.decompress().ok_or(KeyError::InvalidPublicKey)?))
    }
}

/// Shared Secret resulting from Key Exchange
///
/// This is a (compressed) curve point on the ristretto curve, but we make it a
/// different type from RistrettoPublic in order to avoid bugs where the secret
/// is publicized.
#[derive(Clone, Debug, Default)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct RistrettoSecret([u8; 32]);

impl Drop for RistrettoSecret {
    fn drop(&mut self) {
        self.0.zeroize();
    }
}

impl AsRef<[u8]> for RistrettoSecret {
    fn as_ref(&self) -> &[u8] {
        &self.0[..]
    }
}

impl AsRef<[u8; 32]> for RistrettoSecret {
    fn as_ref(&self) -> &[u8; 32] {
        &self.0
    }
}

impl KexSecret for RistrettoSecret {}

/// This is a newtype wrapper around CompressedRistretto, which implements
/// From<RistrettoPublic>, and serialization / digest implementations.
///
/// This structure does not perform any validation that the bytes contained
/// within it represent a valid point, because compression/decompression of
/// ristretto-flavored points is a very expensive operation.
///
/// As a result, this does not implement the `PublicKey` interface, nor is it
/// usable in a key-exchange.
#[derive(Clone, Copy, Default, Digestible, Zeroize)]
#[digestible(transparent)]
pub struct CompressedRistrettoPublic(pub(crate) CompressedRistretto);

impl CompressedRistrettoPublic {
    pub fn as_bytes(&self) -> &[u8; 32] {
        self.0.as_bytes()
    }
}

impl AsRef<[u8]> for CompressedRistrettoPublic {
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

impl TryFrom<&[u8]> for CompressedRistrettoPublic {
    type Error = KeyError;
    fn try_from(src: &[u8]) -> Result<Self, KeyError> {
        if src.len() != 32 {
            return Err(KeyError::LengthMismatch(src.len(), 32));
        }
        let compressed_ristretto =
            CompressedRistretto::from_slice(src).map_err(|_e| KeyError::InvalidPublicKey)?;
        Ok(Self(compressed_ristretto))
    }
}

impl TryFrom<&[u8; 32]> for CompressedRistrettoPublic {
    type Error = KeyError;
    fn try_from(src: &[u8; 32]) -> Result<Self, Self::Error> {
        let compressed_ristretto = CompressedRistretto::from_slice(src.as_slice())
            .map_err(|_e| KeyError::InvalidPublicKey)?;
        Ok(Self(compressed_ristretto))
    }
}

impl AsRef<[u8; 32]> for CompressedRistrettoPublic {
    fn as_ref(&self) -> &[u8; 32] {
        self.as_bytes()
    }
}

impl AsRef<CompressedRistretto> for CompressedRistrettoPublic {
    fn as_ref(&self) -> &CompressedRistretto {
        &self.0
    }
}

impl From<RistrettoPoint> for CompressedRistrettoPublic {
    fn from(src: RistrettoPoint) -> Self {
        Self(src.compress())
    }
}

impl From<&RistrettoPublic> for CompressedRistrettoPublic {
    fn from(src: &RistrettoPublic) -> Self {
        Self(src.0.compress())
    }
}

impl From<RistrettoPublic> for CompressedRistrettoPublic {
    fn from(src: RistrettoPublic) -> Self {
        Self(src.0.compress())
    }
}

impl From<CompressedRistretto> for CompressedRistrettoPublic {
    fn from(src: CompressedRistretto) -> Self {
        Self(src)
    }
}

impl FromRandom for CompressedRistrettoPublic {
    fn from_random<R: CryptoRng>(csprng: &mut R) -> CompressedRistrettoPublic {
        Self::from(random_ristretto_point(csprng))
    }
}

impl PublicKey for CompressedRistrettoPublic {}

derive_repr_bytes_from_as_ref_and_try_from!(CompressedRistrettoPublic, U32);

#[cfg(feature = "alloc")]
derive_into_vec_from_repr_bytes!(CompressedRistrettoPublic);

#[cfg(feature = "serde")]
derive_serde_from_repr_bytes!(CompressedRistrettoPublic);

#[cfg(feature = "prost")]
derive_prost_message_from_repr_bytes!(CompressedRistrettoPublic);

derive_core_cmp_from_as_ref!(CompressedRistrettoPublic, [u8; 32]);
derive_debug_and_display_hex_from_as_ref!(CompressedRistrettoPublic);

/// A zero-width type used to identify the Ristretto key exchange system.
pub struct Ristretto;

/// The implementation of the Ristretto key exchange system.
impl Kex for Ristretto {
    type Public = RistrettoPublic;
    type Private = RistrettoPrivate;
    type EphemeralPrivate = RistrettoEphemeralPrivate;
    type Secret = RistrettoSecret;
}

#[repr(transparent)]
#[derive(Clone)]
pub struct RistrettoSignature([u8; SIGNATURE_LENGTH]);

impl SignatureEncoding for RistrettoSignature {
    type Repr = [u8; SIGNATURE_LENGTH];
}

impl From<RistrettoSignature> for [u8; 64] {
    fn from(src: RistrettoSignature) -> Self {
        src.0
    }
}

impl AsRef<[u8]> for RistrettoSignature {
    fn as_ref(&self) -> &[u8] {
        &self.0
    }
}

impl AsRef<[u8; SIGNATURE_LENGTH]> for RistrettoSignature {
    fn as_ref(&self) -> &[u8; SIGNATURE_LENGTH] {
        &self.0
    }
}

impl Default for RistrettoSignature {
    fn default() -> RistrettoSignature {
        Self([0u8; 64])
    }
}

impl From<SchnorrkelSignature> for RistrettoSignature {
    fn from(src: SchnorrkelSignature) -> RistrettoSignature {
        Self::from(&src)
    }
}

impl From<&SchnorrkelSignature> for RistrettoSignature {
    fn from(src: &SchnorrkelSignature) -> RistrettoSignature {
        Self(src.to_bytes())
    }
}

impl TryFrom<&[u8]> for RistrettoSignature {
    type Error = SignatureError;

    fn try_from(src: &[u8]) -> Result<RistrettoSignature, SignatureError> {
        SchnorrkelSignature::from_bytes(src)
            .map(|sig| Self(sig.to_bytes()))
            .map_err(|_| SignatureError::new())
    }
}

impl TryFrom<&RistrettoSignature> for SchnorrkelSignature {
    type Error = SchnorrkelError;

    fn try_from(src: &RistrettoSignature) -> Result<SchnorrkelSignature, SchnorrkelError> {
        SchnorrkelSignature::from_bytes(&src.0)
    }
}

impl TryFrom<RistrettoSignature> for SchnorrkelSignature {
    type Error = SchnorrkelError;

    fn try_from(src: RistrettoSignature) -> Result<SchnorrkelSignature, SchnorrkelError> {
        SchnorrkelSignature::try_from(&src)
    }
}

derive_core_cmp_from_as_ref!(RistrettoSignature);
derive_debug_and_display_hex_from_as_ref!(RistrettoSignature);
derive_repr_bytes_from_as_ref_and_try_from!(RistrettoSignature, U64);

#[cfg(feature = "alloc")]
derive_into_vec_from_repr_bytes!(RistrettoSignature);

#[cfg(feature = "serde")]
derive_serde_from_repr_bytes!(RistrettoSignature);

#[cfg(feature = "prost")]
derive_prost_message_from_repr_bytes!(RistrettoSignature);

#[cfg(test)]
mod test {
    extern crate bth_util_test_helper;

    use super::*;

    // Test private key generation is random
    #[test]
    fn test_private_key_random() {
        let mut rng = bth_util_from_random::OsRng;
        let key1 = RistrettoPrivate::from_random(&mut rng);
        let key2 = RistrettoPrivate::from_random(&mut rng);
        assert_ne!(key1, key2);
    }

    // Test public key derivation is deterministic
    #[test]
    fn test_public_from_private_deterministic() {
        let mut rng = bth_util_from_random::OsRng;
        let private = RistrettoPrivate::from_random(&mut rng);
        let public1 = RistrettoPublic::from(&private);
        let public2 = RistrettoPublic::from(&private);
        assert_eq!(public1, public2);
    }

    // Test different private keys produce different public keys
    #[test]
    fn test_different_privates_different_publics() {
        let mut rng = bth_util_from_random::OsRng;
        let private1 = RistrettoPrivate::from_random(&mut rng);
        let private2 = RistrettoPrivate::from_random(&mut rng);
        let public1 = RistrettoPublic::from(&private1);
        let public2 = RistrettoPublic::from(&private2);
        assert_ne!(public1, public2);
    }

    // Test bytes roundtrip for private key
    #[test]
    fn test_private_key_bytes_roundtrip() {
        bth_util_test_helper::run_with_several_seeds(|mut rng| {
            let private = RistrettoPrivate::from_random(&mut rng);
            let bytes: &[u8; 32] = private.as_ref();
            let recovered = RistrettoPrivate::try_from(bytes).expect("Should recover private key");
            assert_eq!(private, recovered);
        });
    }

    // Test bytes roundtrip for public key
    #[test]
    fn test_public_key_bytes_roundtrip() {
        bth_util_test_helper::run_with_several_seeds(|mut rng| {
            let private = RistrettoPrivate::from_random(&mut rng);
            let public = RistrettoPublic::from(&private);
            let bytes = public.to_bytes();
            let recovered =
                RistrettoPublic::try_from(&bytes[..]).expect("Should recover public key");
            assert_eq!(public, recovered);
        });
    }

    // Test compressed public key roundtrip
    #[test]
    fn test_compressed_public_roundtrip() {
        bth_util_test_helper::run_with_several_seeds(|mut rng| {
            let private = RistrettoPrivate::from_random(&mut rng);
            let public = RistrettoPublic::from(&private);
            let compressed = CompressedRistrettoPublic::from(&public);
            let decompressed = RistrettoPublic::try_from(&compressed).expect("Should decompress");
            assert_eq!(public, decompressed);
        });
    }

    // Test key exchange produces same shared secret on both sides
    #[test]
    fn test_key_exchange() {
        bth_util_test_helper::run_with_several_seeds(|mut rng| {
            let alice_private = RistrettoPrivate::from_random(&mut rng);
            let alice_public = RistrettoPublic::from(&alice_private);

            let bob_private = RistrettoPrivate::from_random(&mut rng);
            let bob_public = RistrettoPublic::from(&bob_private);

            // Alice computes shared secret with Bob's public key
            let alice_secret = alice_private.key_exchange(&bob_public);

            // Bob computes shared secret with Alice's public key
            let bob_secret = bob_private.key_exchange(&alice_public);

            // Compare the underlying bytes since RistrettoSecret doesn't impl PartialEq
            assert_eq!(alice_secret.as_ref() as &[u8], bob_secret.as_ref() as &[u8]);
        });
    }

    // Test invalid bytes produce error
    #[test]
    fn test_invalid_bytes() {
        // All zeros is not a valid scalar
        let invalid_bytes = [0u8; 32];
        // This should still work because zero is a valid scalar
        let result = RistrettoPrivate::try_from(&invalid_bytes);
        // Zero scalar is actually valid in curve25519-dalek
        assert!(result.is_ok());

        // Invalid compressed point (all 0xff)
        let invalid_point = [0xffu8; 32];
        let result = RistrettoPublic::try_from(&invalid_point[..]);
        assert!(result.is_err());
    }

    // Test that mc-util-serial can serialize a pubkey
    #[test]
    #[cfg(feature = "serde")]
    fn test_pubkey_serialize() {
        bth_util_test_helper::run_with_several_seeds(|mut rng| {
            let pubkey = RistrettoPublic::from_random(&mut rng);
            let serialized =
                bth_util_serial::serialize(&pubkey).expect("Could not serialize pubkey");
            let deserialized: RistrettoPublic =
                bth_util_serial::deserialize(&serialized).expect("Could not deserialize pubkey");
            assert_eq!(deserialized, pubkey);
        });
    }

    // Test that mc-util-serial can serialize a private key
    #[test]
    #[cfg(feature = "serde")]
    fn test_privkey_serialize() {
        bth_util_test_helper::run_with_several_seeds(|mut rng| {
            let privkey = RistrettoPrivate::from_random(&mut rng);
            let serialized =
                bth_util_serial::serialize(&privkey).expect("Could not serialize private key.");
            let deserialized: RistrettoPrivate = bth_util_serial::deserialize(&serialized)
                .expect("Could not deserialize private key");
            let pubkey = RistrettoPublic::from(&privkey);
            let deserialized_pubkey = RistrettoPublic::from(&deserialized);
            assert_eq!(deserialized_pubkey, pubkey);
        });
    }

    // Test scalar multiplication properties
    #[test]
    fn test_scalar_multiplication() {
        bth_util_test_helper::run_with_several_seeds(|mut rng| {
            let private = RistrettoPrivate::from_random(&mut rng);
            let public = RistrettoPublic::from(&private);

            // Verify that scalar * generator = public key point
            let scalar: &Scalar = private.as_ref();
            let expected_point: RistrettoPoint = RISTRETTO_BASEPOINT_POINT * scalar;
            let public_point: &RistrettoPoint = public.as_ref();
            assert_eq!(*public_point, expected_point);
        });
    }

    // Test Scalar conversion roundtrip via bytes
    #[test]
    fn test_scalar_bytes_roundtrip() {
        bth_util_test_helper::run_with_several_seeds(|mut rng| {
            let private = RistrettoPrivate::from_random(&mut rng);
            let scalar: &Scalar = private.as_ref();
            let bytes = scalar.as_bytes();
            let recovered_scalar = Scalar::from_bytes_mod_order(*bytes);
            assert_eq!(*scalar, recovered_scalar);
        });
    }

    // Test RistrettoPoint conversion through compression
    #[test]
    fn test_point_conversion() {
        bth_util_test_helper::run_with_several_seeds(|mut rng| {
            let private = RistrettoPrivate::from_random(&mut rng);
            let public = RistrettoPublic::from(&private);
            let point: &RistrettoPoint = public.as_ref();

            // Convert back through compression
            let compressed = point.compress();
            let decompressed = compressed.decompress().expect("Should decompress");
            assert_eq!(*point, decompressed);
        });
    }

    // Test Display/Debug for public keys
    #[test]
    fn test_public_key_display() {
        bth_util_test_helper::run_with_several_seeds(|mut rng| {
            let private = RistrettoPrivate::from_random(&mut rng);
            let public = RistrettoPublic::from(&private);

            // Display should produce 64 hex chars
            let display = alloc::format!("{}", public);
            assert_eq!(display.len(), 64);

            // Debug should also work
            let debug = alloc::format!("{:?}", public);
            assert!(!debug.is_empty());
        });
    }

    // Test public key ordering
    #[test]
    fn test_public_key_ordering() {
        bth_util_test_helper::run_with_several_seeds(|mut rng| {
            let mut keys: alloc::vec::Vec<RistrettoPublic> = (0..10)
                .map(|_| RistrettoPublic::from(&RistrettoPrivate::from_random(&mut rng)))
                .collect();

            // Should be sortable
            keys.sort();

            // Verify ordering is consistent with PartialOrd
            for i in 0..keys.len() - 1 {
                assert!(keys[i] <= keys[i + 1]);
            }
        });
    }

    // Test private key Clone and Zeroize
    #[test]
    fn test_private_key_clone() {
        bth_util_test_helper::run_with_several_seeds(|mut rng| {
            let private = RistrettoPrivate::from_random(&mut rng);
            let cloned = private.clone();
            assert_eq!(private, cloned);
            assert_eq!(
                RistrettoPublic::from(&private),
                RistrettoPublic::from(&cloned)
            );
        });
    }

    // Test CompressedRistrettoPublic
    #[test]
    fn test_compressed_public_from_slice() {
        bth_util_test_helper::run_with_several_seeds(|mut rng| {
            let private = RistrettoPrivate::from_random(&mut rng);
            let public = RistrettoPublic::from(&private);
            let compressed = CompressedRistrettoPublic::from(&public);

            // Get as bytes and reconstruct
            let bytes: &[u8; 32] = compressed.as_ref();
            let from_slice = CompressedRistrettoPublic::try_from(&bytes[..]).expect("Should work");
            assert_eq!(compressed, from_slice);
        });
    }

    // Test invalid compressed point fails gracefully
    #[test]
    fn test_invalid_compressed_point() {
        // All 1s is not a valid compressed ristretto point
        let invalid = [1u8; 32];
        let result = CompressedRistrettoPublic::try_from(&invalid[..]);
        // The compressed point can be created, but decompression should fail
        if let Ok(compressed) = result {
            let decompressed = RistrettoPublic::try_from(&compressed);
            assert!(decompressed.is_err());
        }
    }

    // Test public key hash consistency (using HashSet for Hash trait testing)
    #[test]
    fn test_public_key_hash() {
        use alloc::collections::BTreeSet;

        bth_util_test_helper::run_with_several_seeds(|mut rng| {
            let private = RistrettoPrivate::from_random(&mut rng);
            let public = RistrettoPublic::from(&private);
            let public_clone = public.clone();

            // Insert into a set and verify equality works
            let mut set = BTreeSet::new();
            set.insert(public.clone());

            // Same key should be found
            assert!(set.contains(&public_clone));

            // Different key should not be found
            let other = RistrettoPublic::from(&RistrettoPrivate::from_random(&mut rng));
            assert!(!set.contains(&other));
        });
    }

    // Test key exchange with self (should produce same result)
    #[test]
    fn test_key_exchange_deterministic() {
        bth_util_test_helper::run_with_several_seeds(|mut rng| {
            let alice = RistrettoPrivate::from_random(&mut rng);
            let bob_public = RistrettoPublic::from(&RistrettoPrivate::from_random(&mut rng));

            let secret1 = alice.key_exchange(&bob_public);
            let secret2 = alice.key_exchange(&bob_public);

            assert_eq!(secret1.as_ref() as &[u8], secret2.as_ref() as &[u8]);
        });
    }

    // Test RistrettoPublic bytes roundtrip via point
    #[test]
    fn test_public_bytes_roundtrip_via_point() {
        bth_util_test_helper::run_with_several_seeds(|mut rng| {
            let private = RistrettoPrivate::from_random(&mut rng);
            let public = RistrettoPublic::from(&private);

            // Get bytes, reconstruct
            let bytes = public.to_bytes();
            let recovered = RistrettoPublic::try_from(&bytes[..]).expect("Should work");
            assert_eq!(public, recovered);
        });
    }

    // Test FromRandom implementations
    #[test]
    fn test_from_random() {
        bth_util_test_helper::run_with_several_seeds(|mut rng| {
            // RistrettoPublic::from_random
            let public1 = RistrettoPublic::from_random(&mut rng);
            let public2 = RistrettoPublic::from_random(&mut rng);
            assert_ne!(public1, public2);

            // RistrettoPrivate::from_random
            let private1 = RistrettoPrivate::from_random(&mut rng);
            let private2 = RistrettoPrivate::from_random(&mut rng);
            assert_ne!(private1, private2);
        });
    }

    // Test Default implementation for RistrettoPublic
    #[test]
    fn test_default() {
        let default_public = RistrettoPublic::default();
        // Default is identity point
        let bytes = default_public.to_bytes();
        assert_eq!(bytes.len(), 32);
    }
}
