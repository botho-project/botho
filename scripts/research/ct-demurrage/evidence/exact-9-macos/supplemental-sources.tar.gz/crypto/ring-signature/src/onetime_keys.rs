// Copyright (c) 2018-2022 The Botho Foundation

//! # Botho transactions use CryptoNote-style `onetime keys` to protect
//! recipient privacy.
//!
//! When creating a transaction, the sender computes a onetime public key for
//! each output in such a way that only the sender and the recipient know who
//! the recipient is, and only the recipient is able to compute the
//! corresponding onetime private key that is required to spend the output.
//!
//! To further protect recipient privacy, an output's onetime key is computed
//! for a `subaddress` that the recipient generated from their CryptoNote-style
//! address. This makes it easy for a recipient to use different subaddresses
//! for different purposes and keep track of how much Botho was sent to
//! each subaddress.
//!
//! ## User account keys (a,b)
//! To begin, a user creates unique account keys `(a,b)`, where `a` is the
//! private view key and `b` is the private spend key. The corresponding public
//! keys are `A = a*G` and `B = b*G`, where `G` is the Ristretto base point. The
//! keys `a`, `b`, `A`, and `B` "stay in the user's wallet": they are not shared
//! with other users and they do not appear in the ledger.
//!
//! ## Creating the i^th subaddress (C_i, D_i)
//! Instead, when a user wishes to receive Botho, they compute a pair of
//! public keys
//!
//!    `D_i = B + Hs( a | i ) * G`
//!    `C_i = a * D`
//!
//! where `Hs` denotes an appropriately domain-separated hash function that
//! returns a scalar. `C_i` is called the subaddress public view key; `D_i` is
//! the public subadress spend key. The `subaddress index` `i` allows the user
//! to generate many distinct subaddresses from a single address.
//!
//! See the `account_keys` crate for more about account keys and subaddresses.
//!
//! ## Sending Botho to a subaddress (C,D)
//! To send Botho to a recipient's subaddress (C,D), the sender generates a
//! unique random number `r`, and creates the following public keys and includes
//! them in a transaction output:
//!
//!    `onetime_public_key = Hs( r * C ) * G + D`
//!    `tx_public_key = r * D`
//!
//! The `onetime_public_key` is sometimes called `target_key`.
//! It is always referred to as `target_key` in rust source code, and the root
//! of this key is the `onetime_private_key` in rust source code.
//!
//! ## Identifying an output sent to your subaddress (C_i, D_i).
//! If you are the recipient of an output, even though you don’t know the random
//! number `r` used in the output's tx_pub_key, you can use the fact that `a *
//! rD_i = r * aD_i = rC_i` and compute the value
//!
//!    `Hs( a * tx_public_key ) * G + D_i`.
//!
//! If this value equals the output's onetime_key, then the output was sent to
//! your i^th subaddress.
//!
//! ## Spending Botho sent to your subaddress (C_i, D_i)
//! To spend an output sent to your i^th subaddress, compute the onetime private
//! key:
//!
//! ```text
//!     onetime_private_key = Hs(a * tx_public_key) + d
//!                         = Hs(a * tx_public_key) + b + Hs( a | i )
//! ```
//!
//! # References
//! * [CryptoNote Whitepaper, Sections 4.3 and 4.4](https://cryptonote.org/whitepaper.pdf)

#![allow(non_snake_case)]

use crate::domain_separators::HASH_TO_SCALAR_DOMAIN_TAG;
use bth_core_types::account::RingCtAddress;
use bth_crypto_hashes::{Blake2b512, Digest};
use bth_crypto_keys::{RistrettoPrivate, RistrettoPublic};
use curve25519_dalek::{
    constants::RISTRETTO_BASEPOINT_POINT, ristretto::RistrettoPoint, scalar::Scalar,
};

const G: RistrettoPoint = RISTRETTO_BASEPOINT_POINT;

/// Hashes a curve point to a Scalar.
fn hash_to_scalar(point: RistrettoPoint) -> Scalar {
    let mut hasher = Blake2b512::new();
    hasher.update(HASH_TO_SCALAR_DOMAIN_TAG);
    hasher.update(point.compress().as_bytes());
    crate::compat::scalar_from_hash(hasher)
}

/// Creates target_key `Hs( r * C ) * G + D` for an output sent to
/// subaddress (C, D).
///
/// # Arguments
/// * `tx_private_key` - The output's tx_private_key `r`. Must be unique for
///   each output.
/// * `recipient` - The recipient subaddress `(C,D)`.
pub fn create_tx_out_target_key(
    tx_private_key: &RistrettoPrivate,
    recipient: &impl RingCtAddress,
) -> RistrettoPublic {
    // `Hs( r * C)`
    let Hs: Scalar = {
        let r = tx_private_key.as_ref();
        let view_public = recipient.view_public_key();
        let C: &RistrettoPoint = &RistrettoPoint::from(&view_public);
        hash_to_scalar(r * C)
    };

    let spend_public = recipient.spend_public_key();
    let D: &RistrettoPoint = &RistrettoPoint::from(&spend_public);
    RistrettoPublic::from(Hs * G + D)
}

/// Creates the `tx_out_public_key = r * D` for an output sent to subaddress (C,
/// D).
///
/// # Arguments
/// * `tx_private_key` - The transaction private key `r`. Must be unique for
///   each output.
/// * `recipient_spend_key` - The recipient's public subaddress spend key `D`.
pub fn create_tx_out_public_key(
    tx_out_private_key: &RistrettoPrivate,
    recipient_spend_key: &RistrettoPublic,
) -> RistrettoPublic {
    let r: &Scalar = tx_out_private_key.as_ref();
    let D = recipient_spend_key.as_ref();
    RistrettoPublic::from(r * D)
}

/// Recovers the subaddress spend key D_i that an output was sent to.
///
/// This computes `P - Hs( a * R ) * G`. If the output was sent to this
/// recipient, the returned value equals D_i for some subaddress index i. This
/// is helpful for checking an output against a set of subaddresses.
///
/// If the output was sent to a different recipient, the returned value is
/// meaningless.
///
/// # Arguments
/// * `view_private_key` - The recipient's view private key `a`.
/// * `tx_out_target_key` - The output's tx_target_key.
/// * `tx_out_public_key` - The output's tx_public_key `R`.
pub fn recover_public_subaddress_spend_key(
    view_private_key: &RistrettoPrivate,
    tx_out_target_key: &RistrettoPublic,
    tx_out_public_key: &RistrettoPublic,
) -> RistrettoPublic {
    // `Hs( a * R )`
    let Hs: Scalar = {
        let a = view_private_key.as_ref();
        let R = tx_out_public_key.as_ref();
        hash_to_scalar(a * R)
    };

    let P = tx_out_target_key.as_ref();
    RistrettoPublic::from(P - Hs * G)
}

/// Computes the onetime private key `Hs( a * R ) + d`.
///
/// This assumes that the output belongs to the provided private keys.
///
/// # Arguments
/// * `tx_out_public_key` - The output's tx_public_key `R`.
/// * `view_private_key` - A private view key `a`.
/// * `subaddress_spend_private_key` - A private spend key `d = Hs(a || i) + b`.
pub fn recover_onetime_private_key(
    tx_out_public_key: &RistrettoPublic,
    view_private_key: &RistrettoPrivate,
    subaddress_spend_private_key: &RistrettoPrivate,
) -> RistrettoPrivate {
    // `Hs( a * R )`
    let Hs: Scalar = {
        let a = view_private_key.as_ref();
        let R = tx_out_public_key.as_ref();
        hash_to_scalar(a * R)
    };

    let d = subaddress_spend_private_key.as_ref();
    let x = Hs + d;
    RistrettoPrivate::from(x)
}

/// Returns the shared secret `xY` from a private key `x` and a public key `Y`.
///
/// # Arguments
/// * `public_key` - A public key `Y`.
/// * `private_key` - A private key `x`
pub fn create_shared_secret(
    public_key: &RistrettoPublic,
    private_key: &RistrettoPrivate,
) -> RistrettoPublic {
    let x = private_key.as_ref();
    let Y = public_key.as_ref();
    RistrettoPublic::from(x * Y)
}

// ============================================================================
// Hybrid post-quantum stealth one-time keys (issue #954, whitepaper §4.2)
// ============================================================================
//
// The classical helpers above derive the one-time key scalar as
// `Hs(r * C) = Hs(a * R)` — a pure classical Diffie--Hellman shared secret.
// A quantum adversary running Shor's algorithm against the permanently
// on-chain ephemeral key `R = r * D` recovers that secret and deanonymises the
// recipient ("harvest now, decrypt later").
//
// The hybrid helpers below fold a second, ML-KEM-768 shared secret `K` into
// the same scalar. `K` is encapsulated against the recipient's ML-KEM public
// key (published in the recipient's address) and its 1,088-byte ciphertext is
// carried on the output; recovering `K` requires breaking a lattice problem
// believed hard even for quantum adversaries. Because the scalar binds BOTH
// secrets, an adversary must break the classical curve problem *and* the
// ML-KEM lattice problem to link or spend the output:
//
//     s = Blake2b-512( DOMAIN || dh_secret.compress() || K || output_index )
// mod q     target_key         = s * G + D
//     onetime_private_key = s + d
//
// where `dh_secret = r * C` for the sender and `dh_secret = a * R` for the
// recipient (these are equal by DH symmetry). This is a strict superset of the
// whitepaper §4.2 construction `s = Hs(K || output_index)`: dropping the
// `dh_secret` term recovers the pure-ML-KEM scalar, and the IND-CCA2
// recipient-unlinkability reduction of §4.2 still goes through because `K`
// remains an unrecoverable random input to the hash.
//
// The ML-KEM shared secret is passed as an opaque 32-byte array so this crate
// takes no dependency on the PQ primitives; the caller (the transaction layer)
// performs encapsulation/decapsulation and threads the 32 bytes through.

use crate::domain_separators::HYBRID_PQ_STEALTH_SCALAR_DOMAIN_TAG;

/// Length in bytes of an ML-KEM-768 shared secret.
pub const KEM_SHARED_SECRET_LEN: usize = 32;

/// Computes the hybrid stealth one-time-key scalar
/// `Hs(dh_secret || K || output_index)`.
///
/// # Arguments
/// * `dh_secret` - The classical DH shared secret point (`r * C` for the
///   sender, `a * R` for the recipient).
/// * `kem_shared_secret` - The 32-byte ML-KEM-768 shared secret `K`.
/// * `output_index` - The output's index within its transaction (domain
///   separation across multiple outputs).
fn hybrid_stealth_scalar(
    dh_secret: RistrettoPoint,
    kem_shared_secret: &[u8; KEM_SHARED_SECRET_LEN],
    output_index: u32,
) -> Scalar {
    let mut hasher = Blake2b512::new();
    hasher.update(HYBRID_PQ_STEALTH_SCALAR_DOMAIN_TAG.as_bytes());
    hasher.update(dh_secret.compress().as_bytes());
    hasher.update(kem_shared_secret);
    hasher.update(output_index.to_le_bytes());
    crate::compat::scalar_from_hash(hasher)
}

/// Creates the hybrid `target_key = Hs(r * C || K || i) * G + D` for an output
/// sent to subaddress `(C, D)` with ML-KEM shared secret `K`.
///
/// # Arguments
/// * `tx_private_key` - The output's ephemeral private key `r` (unique per
///   output).
/// * `recipient` - The recipient subaddress `(C, D)`.
/// * `kem_shared_secret` - The 32-byte ML-KEM-768 shared secret `K` from
///   encapsulating against the recipient's ML-KEM public key.
/// * `output_index` - The output's index within its transaction.
pub fn create_tx_out_target_key_hybrid(
    tx_private_key: &RistrettoPrivate,
    recipient: &impl RingCtAddress,
    kem_shared_secret: &[u8; KEM_SHARED_SECRET_LEN],
    output_index: u32,
) -> RistrettoPublic {
    let s: Scalar = {
        let r = tx_private_key.as_ref();
        let view_public = recipient.view_public_key();
        let C: &RistrettoPoint = &RistrettoPoint::from(&view_public);
        hybrid_stealth_scalar(r * C, kem_shared_secret, output_index)
    };

    let spend_public = recipient.spend_public_key();
    let D: &RistrettoPoint = &RistrettoPoint::from(&spend_public);
    RistrettoPublic::from(s * G + D)
}

/// Recovers the subaddress spend key `D` an output was sent to, under the
/// hybrid construction: computes `P - Hs(a * R || K || i) * G`.
///
/// If the output belongs to this recipient the returned value equals `D_i`;
/// otherwise it is meaningless.
///
/// # Arguments
/// * `view_private_key` - The recipient's view private key `a`.
/// * `tx_out_target_key` - The output's target key `P`.
/// * `tx_out_public_key` - The output's ephemeral public key `R = r * D`.
/// * `kem_shared_secret` - The 32-byte ML-KEM-768 shared secret `K` recovered
///   by decapsulating the output's ciphertext.
/// * `output_index` - The output's index within its transaction.
pub fn recover_public_subaddress_spend_key_hybrid(
    view_private_key: &RistrettoPrivate,
    tx_out_target_key: &RistrettoPublic,
    tx_out_public_key: &RistrettoPublic,
    kem_shared_secret: &[u8; KEM_SHARED_SECRET_LEN],
    output_index: u32,
) -> RistrettoPublic {
    let s: Scalar = {
        let a = view_private_key.as_ref();
        let R = tx_out_public_key.as_ref();
        hybrid_stealth_scalar(a * R, kem_shared_secret, output_index)
    };

    let P = tx_out_target_key.as_ref();
    RistrettoPublic::from(P - s * G)
}

/// Computes the hybrid one-time private key `Hs(a * R || K || i) + d`.
///
/// This assumes the output belongs to the provided keys (check with
/// [`recover_public_subaddress_spend_key_hybrid`] first).
///
/// # Arguments
/// * `tx_out_public_key` - The output's ephemeral public key `R = r * D`.
/// * `view_private_key` - The recipient's view private key `a`.
/// * `subaddress_spend_private_key` - The subaddress spend private key `d`.
/// * `kem_shared_secret` - The 32-byte ML-KEM-768 shared secret `K` recovered
///   by decapsulating the output's ciphertext.
/// * `output_index` - The output's index within its transaction.
pub fn recover_onetime_private_key_hybrid(
    tx_out_public_key: &RistrettoPublic,
    view_private_key: &RistrettoPrivate,
    subaddress_spend_private_key: &RistrettoPrivate,
    kem_shared_secret: &[u8; KEM_SHARED_SECRET_LEN],
    output_index: u32,
) -> RistrettoPrivate {
    let s: Scalar = {
        let a = view_private_key.as_ref();
        let R = tx_out_public_key.as_ref();
        hybrid_stealth_scalar(a * R, kem_shared_secret, output_index)
    };

    let d = subaddress_spend_private_key.as_ref();
    let x = s + d;
    RistrettoPrivate::from(x)
}

#[cfg(test)]
mod tests {
    use super::*;
    use bth_account_keys::{AccountKey, PublicAddress};
    use bth_util_from_random::FromRandom;
    use bth_util_test_helper::run_with_several_seeds;

    // Returns (tx_target_key, tx_public_key)
    fn get_output_public_keys(
        tx_private_key: &RistrettoPrivate,
        recipient: &PublicAddress,
    ) -> (RistrettoPublic, RistrettoPublic) {
        let tx_target_key = create_tx_out_target_key(tx_private_key, recipient);
        let tx_public_key = create_tx_out_public_key(tx_private_key, recipient.spend_public_key());
        (tx_target_key, tx_public_key)
    }

    // Get the account's i^th subaddress.
    fn get_subaddress(
        account: &AccountKey,
        index: u64,
    ) -> (RistrettoPrivate, RistrettoPrivate, PublicAddress) {
        // (view, spend)
        let (c, d) = (
            account.subaddress_view_private(index),
            account.subaddress_spend_private(index),
        );

        // (View, Spend)
        let (C, D) = (RistrettoPublic::from(&c), RistrettoPublic::from(&d));
        // Look out! The argument ordering here is weird.
        let subaddress = PublicAddress::new(&D, &C);

        (c, d, subaddress)
    }

    #[test]
    // `create_target_key` should produce a public key that agrees with the
    // recipient's view key.
    fn test_create_target_key() {
        run_with_several_seeds(|mut rng| {
            let account: AccountKey = AccountKey::random(&mut rng);
            let recipient = account.default_subaddress();

            let tx_private_key = RistrettoPrivate::from_random(&mut rng);
            let (tx_target_key, tx_public_key) =
                get_output_public_keys(&tx_private_key, &recipient);

            assert_eq!(
                recipient.spend_public_key(),
                &recover_public_subaddress_spend_key(
                    account.view_private_key(), // (a, D_0)
                    &tx_target_key,
                    &tx_public_key
                )
            );

            let other_account = AccountKey::random(&mut rng);
            assert_ne!(
                other_account.default_subaddress().spend_public_key(),
                &recover_public_subaddress_spend_key(
                    other_account.view_private_key(),
                    &tx_target_key,
                    &tx_public_key
                ),
                "The one-time public key should not match other view keys."
            );
        })
    }

    #[test]
    // Should return `r * D`.
    fn test_create_tx_public_key() {
        run_with_several_seeds(|mut rng| {
            let r = crate::compat::random_scalar(&mut rng);
            let D = crate::compat::random_point(&mut rng);

            let expected = RistrettoPublic::from(r * D);

            let tx_private_key = RistrettoPrivate::from(r);
            let recipient_spend_key = RistrettoPublic::from(D);
            assert_eq!(
                expected,
                create_tx_out_public_key(&tx_private_key, &recipient_spend_key)
            );
        })
    }

    #[test]
    // Should recover the correct public subaddress spend key D_i when the output
    // belongs to the recipient.
    fn test_recover_public_subaddress_spend_key_ok() {
        run_with_several_seeds(|mut rng| {
            let account: AccountKey = AccountKey::random(&mut rng);
            let (_c, _d, recipient) = get_subaddress(&account, 7);

            let tx_private_key = RistrettoPrivate::from_random(&mut rng);
            let (tx_target_key, tx_public_key) =
                get_output_public_keys(&tx_private_key, &recipient);

            let D_prime = recover_public_subaddress_spend_key(
                account.view_private_key(),
                &tx_target_key,
                &tx_public_key,
            );

            assert_eq!(D_prime, *recipient.spend_public_key()); // D_7

            assert_eq!(
                recipient.spend_public_key(),
                &recover_public_subaddress_spend_key(
                    account.view_private_key(),
                    &tx_target_key,
                    &tx_public_key
                )
            );
        })
    }

    #[test]
    // Should not panic if the output contains the wrong tx_target_key.
    fn test_recover_public_subaddress_spend_key_wrong_tx_target_key() {
        run_with_several_seeds(|mut rng| {
            let account: AccountKey = AccountKey::random(&mut rng);
            let (_c, _d, recipient) = get_subaddress(&account, 7);

            let tx_private_key = RistrettoPrivate::from_random(&mut rng);
            let (_, tx_public_key) = get_output_public_keys(&tx_private_key, &recipient);
            let wrong_tx_target_key = RistrettoPublic::from_random(&mut rng);

            // Should not panic.
            let D_prime = recover_public_subaddress_spend_key(
                account.view_private_key(),
                &wrong_tx_target_key,
                &tx_public_key,
            );

            // Returns meaningless public key.
            assert!(D_prime != *recipient.spend_public_key());
        })
    }

    #[test]
    // Should not panic if the output contains the wrong tx_public_key.
    fn test_recover_public_subaddress_spend_key_wrong_tx_public_key() {
        run_with_several_seeds(|mut rng| {
            let account: AccountKey = AccountKey::random(&mut rng);
            let (_c, _d, recipient) = get_subaddress(&account, 7);

            let tx_private_key = RistrettoPrivate::from_random(&mut rng);
            let (tx_target_key, _) = get_output_public_keys(&tx_private_key, &recipient);
            let wrong_tx_public_key = RistrettoPublic::from_random(&mut rng);

            // Should not panic.
            let D_prime = recover_public_subaddress_spend_key(
                account.view_private_key(),
                &tx_target_key,
                &wrong_tx_public_key,
            );

            // Returns meaningless public key.
            assert!(D_prime != *recipient.spend_public_key());
        })
    }

    #[test]
    // Returns the private key corresponding to `tx_target_key`.
    fn test_recover_onetime_private_key_valid_keypair() {
        run_with_several_seeds(|mut rng| {
            let account = AccountKey::random(&mut rng);
            let (_c, d, recipient) = get_subaddress(&account, 787);

            let tx_private_key = RistrettoPrivate::from_random(&mut rng);
            let (tx_target_key, tx_public_key) =
                get_output_public_keys(&tx_private_key, &recipient);

            let onetime_private_key =
                recover_onetime_private_key(&tx_public_key, account.view_private_key(), &d);
            assert_eq!(tx_target_key, RistrettoPublic::from(&onetime_private_key));
        })
    }

    #[test]
    // Returns meaningless data if the output contains the wrong tx_target_key.
    fn test_recover_onetime_private_key_wrong_tx_target_key() {
        run_with_several_seeds(|mut rng| {
            let account = AccountKey::random(&mut rng);
            let (_c, d, recipient) = get_subaddress(&account, 787);

            let tx_private_key = RistrettoPrivate::from_random(&mut rng);
            let (_, tx_public_key) = get_output_public_keys(&tx_private_key, &recipient);

            let wrong_tx_target_key = RistrettoPublic::from_random(&mut rng);

            let onetime_private_key =
                recover_onetime_private_key(&tx_public_key, account.view_private_key(), &d);

            assert!(wrong_tx_target_key != RistrettoPublic::from(&onetime_private_key));
        })
    }

    #[test]
    // Returns meaningless data if the output contains the wrong tx_public_key.
    fn test_recover_onetime_private_key_wrong_tx_public_key() {
        run_with_several_seeds(|mut rng| {
            let account = AccountKey::random(&mut rng);
            let (_c, d, recipient) = get_subaddress(&account, 787);

            let tx_private_key = RistrettoPrivate::from_random(&mut rng);
            let (tx_target_key, _) = get_output_public_keys(&tx_private_key, &recipient);

            let wrong_tx_public_key = RistrettoPublic::from_random(&mut rng);

            let onetime_private_key =
                recover_onetime_private_key(&wrong_tx_public_key, account.view_private_key(), &d);

            assert!(tx_target_key != RistrettoPublic::from(&onetime_private_key));
        })
    }

    #[test]
    // shared_secret(a,B) should equal shared_secret(b,A)
    fn test_create_shared_secret_is_symmetric() {
        run_with_several_seeds(|mut rng| {
            let a = RistrettoPrivate::from_random(&mut rng);
            let A = RistrettoPublic::from(&a);

            let b = RistrettoPrivate::from_random(&mut rng);
            let B = RistrettoPublic::from(&b);

            let aB = create_shared_secret(&B, &a);
            let bA = create_shared_secret(&A, &b);

            assert_eq!(aB, bA);
        })
    }

    // ------------------------------------------------------------------
    // Hybrid post-quantum stealth one-time keys (issue #954)
    // ------------------------------------------------------------------

    #[test]
    // The hybrid target key must round-trip: the recipient recovers their own
    // spend key and the matching one-time private key, given the same K.
    fn test_hybrid_target_key_roundtrip() {
        run_with_several_seeds(|mut rng| {
            let account = AccountKey::random(&mut rng);
            let (_c, d, recipient) = get_subaddress(&account, 42);
            let kem_secret = [0xABu8; KEM_SHARED_SECRET_LEN];
            let output_index: u32 = 3;

            let tx_private_key = RistrettoPrivate::from_random(&mut rng);
            let tx_target_key = create_tx_out_target_key_hybrid(
                &tx_private_key,
                &recipient,
                &kem_secret,
                output_index,
            );
            let tx_public_key =
                create_tx_out_public_key(&tx_private_key, recipient.spend_public_key());

            // Detection: recovered spend key equals the recipient's D.
            let d_prime = recover_public_subaddress_spend_key_hybrid(
                account.view_private_key(),
                &tx_target_key,
                &tx_public_key,
                &kem_secret,
                output_index,
            );
            assert_eq!(&d_prime, recipient.spend_public_key());

            // Spend: recovered one-time private key regenerates the target key.
            let onetime_private_key = recover_onetime_private_key_hybrid(
                &tx_public_key,
                account.view_private_key(),
                &d,
                &kem_secret,
                output_index,
            );
            assert_eq!(tx_target_key, RistrettoPublic::from(&onetime_private_key));
        })
    }

    #[test]
    // The ML-KEM secret is load-bearing: a wrong/absent K must not detect the
    // output (breaking the classical layer alone is insufficient).
    fn test_hybrid_wrong_kem_secret_fails_detection() {
        run_with_several_seeds(|mut rng| {
            let account = AccountKey::random(&mut rng);
            let (_c, _d, recipient) = get_subaddress(&account, 9);
            let kem_secret = [0x11u8; KEM_SHARED_SECRET_LEN];
            let wrong_kem_secret = [0x22u8; KEM_SHARED_SECRET_LEN];
            let output_index: u32 = 0;

            let tx_private_key = RistrettoPrivate::from_random(&mut rng);
            let tx_target_key = create_tx_out_target_key_hybrid(
                &tx_private_key,
                &recipient,
                &kem_secret,
                output_index,
            );
            let tx_public_key =
                create_tx_out_public_key(&tx_private_key, recipient.spend_public_key());

            // Correct classical keys but the wrong ML-KEM secret => no match.
            let d_prime = recover_public_subaddress_spend_key_hybrid(
                account.view_private_key(),
                &tx_target_key,
                &tx_public_key,
                &wrong_kem_secret,
                output_index,
            );
            assert_ne!(&d_prime, recipient.spend_public_key());
        })
    }

    #[test]
    // The output index domain-separates: the same (r, K) at a different index
    // yields a different scalar, so detection at the wrong index fails.
    fn test_hybrid_output_index_domain_separation() {
        run_with_several_seeds(|mut rng| {
            let account = AccountKey::random(&mut rng);
            let (_c, _d, recipient) = get_subaddress(&account, 5);
            let kem_secret = [0x33u8; KEM_SHARED_SECRET_LEN];

            let tx_private_key = RistrettoPrivate::from_random(&mut rng);
            let tx_target_key =
                create_tx_out_target_key_hybrid(&tx_private_key, &recipient, &kem_secret, 0);
            let tx_public_key =
                create_tx_out_public_key(&tx_private_key, recipient.spend_public_key());

            let d_prime_wrong_index = recover_public_subaddress_spend_key_hybrid(
                account.view_private_key(),
                &tx_target_key,
                &tx_public_key,
                &kem_secret,
                1, // wrong index
            );
            assert_ne!(&d_prime_wrong_index, recipient.spend_public_key());
        })
    }

    #[test]
    // The hybrid scalar is deterministic in its inputs.
    fn test_hybrid_scalar_deterministic() {
        run_with_several_seeds(|mut rng| {
            let dh = crate::compat::random_point(&mut rng);
            let kem_secret = [0x44u8; KEM_SHARED_SECRET_LEN];
            let s1 = hybrid_stealth_scalar(dh, &kem_secret, 7);
            let s2 = hybrid_stealth_scalar(dh, &kem_secret, 7);
            assert_eq!(s1, s2);

            // Changing any input changes the scalar.
            assert_ne!(s1, hybrid_stealth_scalar(dh, &kem_secret, 8));
            let mut other_secret = kem_secret;
            other_secret[0] ^= 1;
            assert_ne!(s1, hybrid_stealth_scalar(dh, &other_secret, 7));
        })
    }
}
