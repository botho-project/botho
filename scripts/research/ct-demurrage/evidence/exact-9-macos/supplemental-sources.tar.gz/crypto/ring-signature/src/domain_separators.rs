// Copyright (c) 2018-2022 The Botho Foundation

//! Domain separation tags for hash functions used in the Botho amount and
//! MLSAG protocols.
//!
//! Domain separation allows multiple distinct hash functions to be derived from
//! a single base function:
//!   Hash_1(X) = Hash("Hash_1" || X),
//!   Hash_2(X) = Hash("Hash_2" || X),
//!   etc.
//!
//! Here, "Hash_1" and "Hash_2" are called domain separation tags. Tags should
//! uniquely identify the hash function within the protocol and may include the
//! protocol's version so that each derived hash function is independent of
//! others within the protocol and independent of hash functions in other
//! versions of the protocol.

/// Domain separator for onetime key "hash_to_point" function.
pub const HASH_TO_POINT_DOMAIN_TAG: &str = "mc_onetime_key_hash_to_point";

/// Domain separator for onetime key "hash_to_scalar" function.
pub const HASH_TO_SCALAR_DOMAIN_TAG: &str = "mc_onetime_key_hash_to_scalar";

/// Domain separator for RingMLSAG's challenges.
pub const RING_MLSAG_CHALLENGE_DOMAIN_TAG: &str = "mc_ring_mlsag_challenge";

/// Domain separator for CLSAG aggregation coefficient mu_P (for public keys).
pub const CLSAG_AGG_COEFF_P_DOMAIN_TAG: &str = "bth_clsag_agg_p";

/// Domain separator for CLSAG aggregation coefficient mu_C (for commitments).
pub const CLSAG_AGG_COEFF_C_DOMAIN_TAG: &str = "bth_clsag_agg_c";

/// Domain separator for CLSAG round hash (challenge computation).
pub const CLSAG_ROUND_HASH_DOMAIN_TAG: &str = "bth_clsag_round";

/// Domain separator for the hybrid post-quantum stealth one-time key scalar.
///
/// Used by the universal ML-KEM-768 stealth envelope (issue #954, whitepaper
/// §4.2). The one-time key scalar folds BOTH the classical Diffie--Hellman
/// shared secret (`r * C = a * R`) and the ML-KEM-768 shared secret `K` into a
/// single Blake2b-512 → scalar reduction, so an adversary must break *both*
/// the classical elliptic-curve problem *and* the ML-KEM lattice problem to
/// link or steal an output. The `v1` suffix version-binds the construction to
/// the protocol 6.0.0 output format.
pub const HYBRID_PQ_STEALTH_SCALAR_DOMAIN_TAG: &str = "bth_hybrid_pq_stealth_scalar_v1";
