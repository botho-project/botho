# Demurrage counterexamples (#1711)

`Botho/Demurrage/Counterexamples.lean` refutes three proposed properties of
the pre-9.0.0 integer kernels. It does not change consensus behavior.
The six theorems are **proven (model)**; the three DRT legs call the actual
Rust functions to test correspondence. DRT is evidence, not a proof of
Rust-to-Lean equivalence.

Tracked findings: [#1875](https://github.com/botho-project/botho/issues/1875)
(time quantization) and [#1876](https://github.com/botho-project/botho/issues/1876)
(ring saturation). Statement-record review precedes proofs in
[#1877](https://github.com/botho-project/botho/pull/1877).

## Status since protocol 9.0.0 (#1875 fixed)

The time-quantization finding below is **fixed** in protocol 9.0.0: the
operator chose exact arithmetic after the simulation study (PR #1908,
`docs/research/demurrage-quantization-study.md`). `demurrage_charge` now takes
one floor of the full rational
`value × rate × (factor − 1000) × elapsed / (10_000 × 5_000 × blocks_per_year)`,
clamped to `u64::MAX`, with no intermediate time fraction.

- `charge` (`Counterexamples.lean`) is the **legacy** pre-9.0.0 kernel. Its
  theorems (`six_block_dead_zone`, `churn_counterexample`,
  `charge_exceeds_value`, `saturation_lowers_charge`) and their statement
  records are unchanged: they are the machine-checked record of the finding.
- `exactCharge` (`ExactCharge.lean`) is the 9.0.0 kernel, written as the
  specification itself on `Nat` (it does not mirror the Rust u128
  decomposition, so the DRT checks that the decomposition is exact). The
  `demurrage_charge` DRT leg now runs `exactCharge`. Its four claims below
  are listed in `Theorems.lean` and bound in `statements.txt` (#1916).
- With the DRT dispatch temporarily pointed back at the legacy `charge`, the
  committed regression lines produce mismatches against the 9.0.0 Rust
  kernel, so the leg distinguishes the two kernels.
- `charge_exceeds_value` still holds for the exact kernel (51 years at 2%
  and 6x is 102% of principal): the clamp is to `u64::MAX`, not principal.
- The #1908 study's u128 candidate was exact only for
  `blocks_per_year <= 368_934_881_474` and saturated upward beyond. The
  production kernel splits `elapsed` at 2^32, so it is exact for every input;
  `cluster-tax` tests compare it with a 256-bit oracle on both sides of that
  limit, and the regression file pins two inputs beyond it.

### Exact-charge threshold and splitting (#1916)

Write `p = clamp(factor, 1000, 6000) - 1000`, `K = rate * p * elapsed`,
`D = 10000 * 5000 * year`, `M = u64::MAX`, and
`C(v) = min(floor(v*K/D), M)`. The following are **proven (model)** in
`Botho/Demurrage/ExactCharge.lean`; the existing DRT leg provides separate
evidence of correspondence with Rust.

- `exactCharge_positive_iff`: if year, rate and elapsed are positive and
  factor is greater than 1000, then `C(v) > 0` exactly when
  `v >= (D + K - 1) / K`. This is the sharp ceiling threshold, including
  zero below it. If factor is at most 1000, or year, rate or elapsed is zero,
  the charge is zero; checked examples cover all four guards. A threshold
  above `u64::MAX` cannot be met by a Rust-width input.
- At factor 6000, rate 200, year 6,307,200 and elapsed 1, the threshold is
  **315,360,000 pico**. Kernel-checked examples give zero at 315,359,999 and
  one at 315,360,000. The exact kernel therefore has a value threshold even
  at one block, unlike the legacy six-block dead zone.
- `exactCharge_split_loss_bound`: for any nonempty list `xs` of natural
  values with common parameters and positive year, write `whole = C(sum xs)`,
  `parts = sum(map C xs)` and `n = length xs`. Then `whole < parts + n`,
  including when charges are capped. Zero-valued pieces are allowed. The
  empty list is excluded because its strict inequality would be false.
- `exactCharge_split_rounding`: with the additional aggregate no-cap
  condition `floor((sum xs)*K/D) <= M`, also `parts <= whole`. Together the
  bounds limit pure rounding loss to at most `n - 1` pico. The checked split
  `[315359999, 1]` at the threshold parameters charges zero in parts and one
  as a whole, without clipping.
- `exactCharge_split_clipping_counterexample`: with values
  `[9223372036854775807, 9223372036854775808]`, factor 6000, rate 10000,
  elapsed 2 and year 1, the total value and whole charge are
  `M = 18446744073709551615`, while the parts charge **36893488147419103229**
  (`2*M - 1`). Both values and the parameters fit their Rust widths. This
  synthetic helper-domain witness explains why `parts <= whole` requires
  the no-cap condition; it does not construct a reachable ledger history.

These statements preserve the existing `exactCharge` definition. They prove
arithmetic properties of the model, not Rust-to-Lean equivalence or general
fee-floor, churn, monotonicity or ledger-reachability claims.

## Time quantization defeats a positive-value threshold (pre-9.0.0)

`cluster-tax/src/demurrage.rs::demurrage_charge` computes
`time_fraction = elapsed * 1_000_000 / blocks_per_year` before multiplying by
the annual charge. With the production five-second reference year
(`6_307_200` blocks), every elapsed time from zero through six gives zero.
`six_block_dead_zone` proves this for all values, factors and rates. Increasing
the transfer value cannot repair the zero, so #1711's positive-charge target
needs an elapsed-time precondition as well as a value threshold.

At a fixed principal of `10^18` picocredits (1,000,000 BTH), factor `6000`
and rate `200` basis points, the charge for six blocks is zero; the charge for
twelve blocks is `20_000_000_000` picocredits (0.02 BTH). Thus two six-block
kernel calls do not equal one twelve-block call. This refutes the documented
same-class churn identity. The theorem does not construct transactions:
ring-age selection, transaction fees, principal changes and accepted-state
reachability still matter. A class downgrade has a separate capitalized
charge, which is outside this counterexample.

## Numerator saturation lowers the ring factor (pre-9.0.0; fixed by #1876)

This section describes the 8.x code. Protocol 9.0.0 fixes it; see
[the next section](#fixed-in-protocol-900-exact-centroid-1876). The theorems
below still hold: they are statements about the pre-fix model `centroid` /
`ringFactor`, which is kept unchanged as the historical witness.

Before 9.0.0, `ring_centroid_implied_factor` saturated its weighted numerator, then divided
by the total value. Its comment says overflow pins the centroid to `u128::MAX`
and the factor to `6000`. Division after saturation makes that claim false.

Take twenty members, each with the same effective wealth of `10^20`
picocredits (100,000,000 BTH):

| Value of each member | Calculated centroid | Default factor |
| --- | --- | --- |
| `10^17` picocredits | `100000000000000000000` | `5949` |
| `10^18` picocredits | `17014118346046923173` | `5841` |

Multiplying every value by ten changes a homogeneous weighted mean and lowers
the fee factor. Each individual product in the second ring fits `u128`; the
sum overflows. The denominator stays exact. All inputs fit Rust's widths.
`homogeneous_ring_scale_counterexample` pins both factors;
`homogeneous_centroid_counterexample` pins the saturated quotient;
`saturation_lowers_charge` proves the lower factor lowers a one-year accrued
charge on the same principal.

All members have equal wealth, so this is independent of #1686's ordinary
background-decoy dilution. The scalar ring satisfies the twenty-member shape,
but we have not constructed a ledger history producing these values and
effective wealths. A larger claimed/import factor could mask the lower ring
floor in the final fee composition.

## Fixed in protocol 9.0.0: exact centroid (#1876)

The operator ruled to fix all three fee-floor weighted means with exact wide
arithmetic: `ring_centroid_implied_factor`, and `ring_centroid_floored_factor`
and `effective_cluster_wealth_from_outputs` in
`botho/src/ledger/store/validation.rs`. They now compute the exact floor of
`Σ value·wealth / Σ value` over a 256-bit numerator
(`cluster-tax/src/wide.rs`). The result is clamped at `u128::MAX` only at the
end. For the ring centroid that clamp cannot be reached, because a weighted
mean never exceeds its largest member wealth.

`Botho/Demurrage/Exact.lean` models the fixed kernel as `exactCentroid` /
`ringFactorExact`:

- `exactCentroid_homogeneous`: for every member count `n > 0`, value `v > 0`
  and wealth `w ≤ u128::MAX`, a homogeneous ring's centroid is `w`. This is
  scale invariance.
- `homogeneous_ring_scale_exact`: both counterexample rings now give 5949.
- `homogeneous_centroid_exact`: the 10^18 ring's centroid is `10^20`.
- `exact_versus_saturating_boundary`: the pre-fix and fixed models agree on
  the largest homogeneous 20-member ring at `W = 10^20` whose numerator fits
  u128, and they diverge at the next value.

These theorems and the supporting `foldl_replicate_exact` theorem are
**proven (model)**, listed in `Theorems.lean` and bound in `statements.txt`
(#1916), with their original types and definition closures unchanged.

The `ring_centroid_factor` DRT leg now compares the Rust function against
`ringFactorExact`. Run against the old `ringFactor`, the fixed Rust function
mismatches immediately, starting with the second pinned ring (Lean 5841, Rust
5949). The `effective_cluster_wealth` leg likewise now compares against
`Botho.Tags.effectiveWealthExact` (`Botho/Tags/EffectiveExact.lean`, theorem
`whale_claimed_wealth_exact`, likewise listed and bound by #1916). Seed 1876 ran 100,000
generated cases on each of `demurrage_charge`, `default_cluster_factor`,
`ring_centroid_factor` and `effective_cluster_wealth`, plus 20 pinned
fixtures. There were zero mismatches; see
`formal-drt/results/demurrage-1876.json`. The pinned
`ring_centroid_factor.jsonl` fixtures keep both original rings and add the
#1876 boundary and extreme rings.

For #1916, seed 1916 ran 10,000 generated cases on each of
`demurrage_charge`, `ring_centroid_factor` and `effective_cluster_wealth`,
plus 8, 8 and 3 committed replays respectively: **30,019 Lean calls, zero
mismatches**. The Rust functions, fixtures and generators were unchanged;
the harness retained release overflow checks. After building
`formal-drt/lean` with Lean 4.35.0, reproduce this bounded run from the repo root:

```sh
CARGO_BUILD_JOBS=2 cargo +nightly-2026-06-09 run --release \
  --manifest-path formal-drt/Cargo.toml -- --cases 10000 --seed 1916 \
  --legs demurrage_charge,ring_centroid_factor,effective_cluster_wealth \
  --model formal-drt/lean/.lake/build/bin/botho-model \
  --regressions formal-drt/regressions --no-write-regressions
```

## Charge is not always bounded by principal

`charge_exceeds_value` gives `1_020_000` charged on a `1_000_000` principal
after 51 years at 2% and factor `6000`. The kernel clamps to `u64::MAX`, not
to principal. This refutes #1711's unconditional bound. It is a long-horizon
specification issue; transaction balance validation remains a separate gate.

## Model correspondence and remaining scope

| Lean definition | Rust source | DRT leg |
| --- | --- | --- |
| `exactCharge` | `demurrage.rs::demurrage_charge` (protocol 9.0.0) | `demurrage_charge` |
| `charge` (legacy) | `demurrage.rs::demurrage_charge` before 9.0.0 (kept in its tests as `legacy_quantized_charge`) | none since #1875 (receipt `demurrage-1711.json`) |
| `defaultFactor` | `fee_curve.rs::ClusterFactorCurve::default_params().factor` | `default_cluster_factor` |
| `ringFactorExact` / `exactCentroid` | `demurrage.rs::ring_centroid_implied_factor` (protocol 9.0.0) | `ring_centroid_factor` |
| `ringFactor` / `centroid` | `demurrage.rs::ring_centroid_implied_factor` before 9.0.0 (historical) | none since #1876 |

The model uses natural numbers with explicit saturation and return clamps.
For Rust-width inputs, the first charge product is below `2^109`; elapsed
times the time scale is below `2^84`. The curve model covers only the default
parameters, preserves signed division toward zero and uses the production
seven-knot lookup table. The pre-fix ring model retains input order and
saturates both accumulators exactly where the 8.x Rust did. The exact model
keeps both accumulators unbounded and clamps the result once.

Pinned DRT fixtures include both rings, the six/twelve-block calls, the
51-year call and curve boundaries. Generated cases cover the Rust integer
widths, near-zero elapsed times, saturation and homogeneous rings.
See `formal-drt/results/demurrage-1711.json` for the run receipt.
The seed-1711 run compared 100,000 generated cases per leg and all 11 pinned
fixtures, with zero mismatches (300,011 comparisons), against the legacy
kernel. The #1875 receipt, `formal-drt/results/demurrage-1875.json`, is the
same three legs with seed 1875 against the exact kernel (`exactCharge`),
including the five new `demurrage_charge` regression lines.

Reproduce after building `formal-drt/lean` and `formal-drt`:

```sh
cd formal-drt
target/release/botho-formal-drt --cases 100000 --seed 1711 \
  --legs demurrage_charge,default_cluster_factor,ring_centroid_factor \
  --no-write-regressions --json /tmp/demurrage-1711.json
# 9.0.0 exact kernel (#1875): the same command with --seed 1875
```

This is a partial #1711 contribution. Settlement/reset/spend composition,
ring elapsed centroid/quantile, `consensus_fee_floor`, monotonicity proofs,
fuzz-corpus replay and accepted-block witnesses remain outstanding. Do not
mark #1711 complete on these counterexamples or weaken its targets silently.
Any arithmetic repair changes consensus outputs and needs its own reviewed
policy, activation and regression work.
