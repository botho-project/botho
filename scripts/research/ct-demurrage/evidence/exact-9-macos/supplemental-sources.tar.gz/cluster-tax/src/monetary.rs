//! Two-phase monetary policy for Botho (BTH).
//!
//! # BTH Tokenomics Summary
//!
//! - **Initial supply**: 0 BTH (100% mined, no pre-mine)
//! - **Unit**: 1 BTH = 10^12 picocredits (12 decimal places; picocredits are
//!   the single base unit below the UI edge, decision #649)
//! - **Phase 1 (Years 0-10)**: Halving schedule distributes ~100M BTH
//! - **Phase 2 (Year 10+)**: 2% target annual inflation
//! - **Fee burns**: All cluster taxes are burned, reducing effective inflation
//!
//! # Overflow Safety
//!
//! With picocredits (10^12 per BTH) as the base unit, realistic full-scale
//! supplies exceed `u64::MAX` (~1.84 × 10^19 picocredits ≈ 18.4M BTH):
//! - 100M BTH = 10^20 picocredits.
//!
//! The node therefore performs its supply accounting and tail-reward
//! computation in `u128` (issues #333/#626); see
//! [`MonetaryPolicy::calculate_tail_reward_u128`]. The `u64` fields on
//! [`MonetaryState`] / [`DifficultyController`] in this crate are simulation
//! tooling used at horizon-scaled magnitudes, where totals stay far below
//! `u64::MAX`.
//!
//! # Design Goals
//!
//! 1. **Early adoption incentives**: Halving schedule for ~10 years rewards
//!    early adopters
//! 2. **Long-term stability**: 2% net inflation after halving period
//! 3. **Fee burn integration**: Progressive cluster taxes are always burned
//! 4. **Predictable minting**: Fixed reward per block, variable block rate
//!
//! # Two-Phase Model
//!
//! ## Phase 1: Adoption (Years 0-10)
//!
//! - Block reward follows halving schedule (halves every 2 years, 5 halvings
//!   total)
//! - Initial reward: ~50 BTH per block
//! - Difficulty adjusts traditionally to maintain target block time (1 minute)
//! - Fee burns create bonus deflation (not compensated)
//!
//! Emission schedule:
//! ```text
//! Halving 0 (years 0-2):  ~50 BTH/block  → ~26.3M BTH
//! Halving 1 (years 2-4):  ~25 BTH/block  → ~13.1M BTH
//! Halving 2 (years 4-6):  ~12.5 BTH/block → ~6.6M BTH
//! Halving 3 (years 6-8):   ~6.25 BTH/block → ~3.3M BTH
//! Halving 4 (years 8-10):  ~3.125 BTH/block → ~1.6M BTH
//! ─────────────────────────────────────────────────────
//! Total Phase 1:                          ~100M BTH
//! ```
//!
//! ## Phase 2: Stability (Years 10+)
//!
//! > **Node parity note (#1699).** The example numbers in this header are the
//! > generic 60 s library default, not mainnet (see
//! > [`mainnet_policy_mirror`]). And the node does NOT fix the tail reward or
//! > target inflation with difficulty: it recomputes the tail reward every
//! > block from cumulative gross issuance
//! > ([`MonetaryPolicy::block_reward_at`]), so gross issuance compounds at
//! > `tail_inflation_bps + expected_fee_burn_rate_bps` per policy-year, and
//! > its difficulty controller targets block time only. The
//! > [`DifficultyController`] here now follows both rules. The original
//! > design notes are kept below for context.
//!
//! - Block reward is fixed (set at transition based on supply)
//! - Difficulty adjusts to achieve target NET inflation (2%)
//! - Block time floats within bounds (45-90 seconds)
//! - Higher fees → faster blocks → more gross emission → stable net
//!
//! Example at year 10 with 100M BTH supply:
//! - 2% target = 2M BTH/year net emission
//! - With 0.5% fee burn = 0.5M BTH/year burned
//! - Gross needed = 2.5M BTH/year
//! - At ~525k blocks/year = ~4.76 BTH/block tail reward
//!
//! # Key Insight
//!
//! Instead of adjusting reward per block (unpredictable for minters),
//! we adjust how many blocks are produced (via difficulty):
//!
//! ```text
//! net_inflation = gross_emission - fees_burned
//!               = (reward × blocks) - fees_burned
//!
//! To hit target net inflation:
//!   blocks_needed = (target_net + fees_burned) / reward
//!   difficulty adjusts to produce this many blocks
//! ```

/// Monetary policy configuration.
///
/// All monetary values are denominated in picocredits (10^-12 BTH).
#[derive(Clone, Debug, PartialEq, Eq)]
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
pub struct MonetaryPolicy {
    // === Phase 1: Halving ===
    /// Initial block reward in picocredits.
    ///
    /// Default: 50 BTH = 50_000_000_000_000 picocredits
    pub initial_reward: u64,

    /// Number of blocks between halvings.
    pub halving_interval: u64,

    /// Number of halvings before transitioning to tail emission.
    /// After this many halvings, Phase 2 begins.
    pub halving_count: u32,

    // === Phase 2: Tail Emission ===
    /// Target annual NET inflation rate in basis points (200 = 2%).
    pub tail_inflation_bps: u32,

    // === Block Time ===
    /// Target block time in seconds.
    pub target_block_time_secs: u64,

    /// Minimum block time in seconds (security floor).
    /// Blocks faster than this risk propagation issues.
    pub min_block_time_secs: u64,

    /// Maximum block time in seconds (usability ceiling).
    /// Blocks slower than this hurt user experience.
    pub max_block_time_secs: u64,

    // === Difficulty Adjustment ===
    /// Number of blocks per difficulty adjustment epoch.
    pub difficulty_adjustment_interval: u64,

    /// Maximum difficulty adjustment per epoch in basis points.
    /// E.g., 2500 = 25% max change per epoch.
    pub max_difficulty_adjustment_bps: u32,

    // === Phase 2 Calibration ===
    /// Expected steady-state fee burn rate as fraction of supply (bps).
    /// Used to calibrate tail reward. E.g., 50 = 0.5% of supply burned/year.
    pub expected_fee_burn_rate_bps: u32,
}

impl Default for MonetaryPolicy {
    /// Library defaults for monetary policy.
    ///
    /// **NOTE**: This is a generic library default assuming 60-second blocks.
    /// It is intentionally NOT the canonical mainnet schedule and is not used
    /// for any mainnet/consensus decision. Botho mainnet uses different
    /// parameters via `botho/src/monetary.rs::mainnet_policy()`:
    /// - 5-second assumed block time (not 60s)
    /// - Dynamic timing adjusts actual blocks 3-40s based on network load
    /// - Canonical schedule (#351): ~1-year halvings (`BLOCKS_PER_YEAR` at 5s),
    ///   5 halvings → ~5 years to tail, 2% tail, derived ~611M BTH supply
    /// - See `docs/architecture.md#block-timing-architecture` for details
    ///
    /// The emission sweep (#350, `simulation::emission_sweep`) sets each
    /// candidate `MonetaryPolicy` explicitly per-schedule, so it does not rely
    /// on this default. Calibrated Gini/lottery/demurrage tests likewise build
    /// their own policies. This default therefore stays at the generic 60s/1min
    /// units and is left unchanged by the #351 schedule decision.
    fn default() -> Self {
        Self {
            // Phase 1: ~10 years of halvings
            // Initial reward: 50 BTH = 50_000_000_000_000 picocredits
            // Over 5 halvings: 50 + 25 + 12.5 + 6.25 + 3.125 ≈ 96.9 BTH/block-equivalent
            // With ~1.05M blocks/halving → ~100M BTH distributed in Phase 1
            initial_reward: 50_000_000_000_000,
            halving_interval: 1_051_200, // ~2 years at 1 min blocks (525,600 blocks/year)
            halving_count: 5,            // 5 halvings = 10 years

            // Phase 2: 2% net inflation target
            tail_inflation_bps: 200,

            // Block time: 1 minute target, 45s-90s bounds
            target_block_time_secs: 60,
            min_block_time_secs: 45,
            max_block_time_secs: 90,

            // Difficulty: adjust every 1440 blocks (~1 day at 1 min blocks)
            difficulty_adjustment_interval: 1440,
            max_difficulty_adjustment_bps: 2500, // 25% max change per epoch

            // Expected ~0.5% of supply burned in cluster fees annually
            expected_fee_burn_rate_bps: 50,
        }
    }
}

impl MonetaryPolicy {
    /// Create policy with Bitcoin-like parameters (10 min blocks, 4 year
    /// halvings).
    pub fn bitcoin_like() -> Self {
        Self {
            // 50 BTH = 50_000_000_000_000 picocredits
            initial_reward: 50_000_000_000_000,
            halving_interval: 210_000, // ~4 years at 10 min blocks
            halving_count: 5,

            tail_inflation_bps: 200,

            target_block_time_secs: 600, // 10 minutes
            min_block_time_secs: 480,    // 8 minutes
            max_block_time_secs: 720,    // 12 minutes

            difficulty_adjustment_interval: 2016, // ~2 weeks
            max_difficulty_adjustment_bps: 2500,

            expected_fee_burn_rate_bps: 50,
        }
    }

    /// Create policy for faster testing.
    pub fn fast_test() -> Self {
        Self {
            initial_reward: 1000,
            halving_interval: 100,
            halving_count: 3,

            tail_inflation_bps: 200,

            target_block_time_secs: 1,
            min_block_time_secs: 1,
            max_block_time_secs: 2,

            difficulty_adjustment_interval: 10,
            max_difficulty_adjustment_bps: 5000, // 50% for faster convergence

            expected_fee_burn_rate_bps: 100,
        }
    }

    /// Get the block height where Phase 2 (tail emission) begins.
    pub fn tail_emission_start_height(&self) -> u64 {
        self.halving_interval * self.halving_count as u64
    }

    /// Fraction of the block reward routed to the redistribution lottery,
    /// in basis points, as a deterministic function of block height.
    ///
    /// Schedule: 0 during the bootstrap epoch (epoch 0), then +1000 bps per
    /// halving epoch, capped at 5000 (50%).
    ///
    /// Rationale (see docs/design/cluster-tilted-redistribution.md):
    /// - Epoch 0: mining seeds the network; the only lottery-eligible UTXOs
    ///   would be miner coinbases, so routing emission would be circular at
    ///   best. Miners keep the full (large) reward while security depends
    ///   entirely on emission.
    /// - The ramp counteracts the absolute decay of f x reward across halvings,
    ///   maintaining redistribution intensity as wealth concentration
    ///   accumulates.
    /// - The cap preserves at least half of tail emission as the permanent
    ///   mining security budget.
    ///
    /// CONSENSUS-CRITICAL: pure integer math; every validator must compute
    /// the same share.
    #[allow(
        clippy::manual_saturating_arithmetic,
        reason = "saturating_mul has no Aeneas model; this spelling extracts to Lean (#1820)"
    )]
    pub fn lottery_emission_bps(&self, height: u64) -> u32 {
        /// Per-halving-epoch increase in lottery emission share (10%).
        const LOTTERY_EMISSION_STEP_BPS: u32 = 1_000;
        /// Maximum lottery emission share (50% of the block reward).
        const LOTTERY_EMISSION_MAX_BPS: u32 = 5_000;

        if self.halving_interval == 0 {
            return 0;
        }
        let epoch = (height / self.halving_interval).min(u32::MAX as u64) as u32;
        // `checked_mul(..).unwrap_or(u32::MAX)` is `saturating_mul` for
        // unsigned integers, spelled with operations Aeneas models (#1820).
        epoch
            .checked_mul(LOTTERY_EMISSION_STEP_BPS)
            .unwrap_or(u32::MAX)
            .min(LOTTERY_EMISSION_MAX_BPS)
    }

    /// The portion of a block reward routed to the redistribution lottery
    /// at the given height. The miner receives `reward - share`.
    pub fn lottery_emission_share(&self, height: u64, reward: u64) -> u64 {
        (reward as u128 * self.lottery_emission_bps(height) as u128 / 10_000) as u64
    }

    /// Annual cluster demurrage rate at maximum cluster factor, in basis
    /// points, as a deterministic function of block height.
    ///
    /// Zero during the bootstrap epoch (epoch 0): early UTXOs are almost
    /// entirely miner coinbases, and demurrage proceeds would circulate
    /// among miners while discouraging the mining that seeds the network.
    /// From epoch 1 onward the full rate applies — the same activation
    /// boundary as lottery emission routing.
    ///
    /// 200 bps (2%/year at factor 6, scaling down to 0 at factor 1) is the
    /// rate validated by the emission-fraction sweep
    /// (experiments/ANALYSIS.md): demurrage is load-bearing for the
    /// Δgini > 0.05 criterion at miner-viable emission fractions.
    ///
    /// CONSENSUS-CRITICAL: pure integer math.
    pub fn demurrage_rate_bps(&self, height: u64) -> u32 {
        const DEMURRAGE_RATE_BPS: u32 = 200;

        if self.halving_interval == 0 || height < self.halving_interval {
            return 0;
        }
        DEMURRAGE_RATE_BPS
    }

    /// Check if a given height is in Phase 1 (halving period).
    pub fn is_halving_phase(&self, height: u64) -> bool {
        height < self.tail_emission_start_height()
    }

    /// Get the block reward for a given height (Phase 1 only).
    /// Returns None in Phase 2; recompute the tail from current gross issuance.
    pub fn halving_reward(&self, height: u64) -> Option<u64> {
        if !self.is_halving_phase(height) {
            return None;
        }

        let halvings = height / self.halving_interval;
        Some(self.initial_reward >> halvings)
    }

    /// Calculate the tail reward from a u64 supply, widening before arithmetic.
    ///
    /// The node uses the u128 variant with current cumulative gross issuance
    /// on every tail block. This compatibility wrapper is for narrow callers.
    pub fn calculate_tail_reward(&self, supply_at_transition: u64) -> u64 {
        self.calculate_tail_reward_u128(supply_at_transition as u128)
    }

    /// `u128`-input variant of [`Self::calculate_tail_reward`].
    ///
    /// At picocredit scale (1 BTH = 10^12 picocredits, decision #649) realistic
    /// full-scale supplies exceed `u64::MAX` (~1.84e19 picocredits ≈ 18.4M
    /// BTH), so callers that track supply in `u128` (the node's ledger, #333;
    /// the emission sweep's analytic track) must not truncate through the `u64`
    /// entry point. The arithmetic is identical to the `u64` version (which
    /// already computed internally in `u128`) — only the input width differs.
    ///
    /// This helper has a bounded arithmetic domain: ordinary u128 products
    /// and addition panic on overflow under the workspace release profile.
    /// The final `max(1) as u64` truncates; an arithmetic-safe synthetic supply
    /// can therefore return zero. For the mainnet policy, supply at most
    /// `u64::MAX * 6_307_200 * 40` gives safe arithmetic, lossless narrowing
    /// and reward >= 1 (formal/MONETARY.md, #1921). This sufficient one-call
    /// bound is not a proved invariant or genesis-reachable horizon.
    pub fn calculate_tail_reward_u128(&self, supply_at_transition: u128) -> u64 {
        // Target annual NET emission
        let target_net = supply_at_transition * self.tail_inflation_bps as u128 / 10_000;

        // Expected annual fee burns
        let expected_burns =
            supply_at_transition * self.expected_fee_burn_rate_bps as u128 / 10_000;

        // Gross emission needed
        let gross_needed = target_net + expected_burns;

        // Blocks per year at target rate
        let secs_per_year: u128 = 365 * 24 * 3600;
        let blocks_per_year = secs_per_year / self.target_block_time_secs as u128;

        // Reward per block
        let reward = gross_needed / blocks_per_year;

        reward.max(1) as u64
    }

    /// The block reward at `height` given the cumulative gross issuance
    /// `total_mined` *before* that block — the exact rule the node applies.
    ///
    /// Mirrors `botho::block::calculate_block_reward(height, total_mined)`
    /// (which validators call with `ChainState::total_mined`, the running sum
    /// of every minting reward, NOT reduced by fee burns):
    ///
    /// - Phase 1 (`height < tail_emission_start_height()`): the halving reward,
    ///   independent of supply.
    /// - Phase 2: [`Self::calculate_tail_reward_u128`] of `total_mined`,
    ///   **recomputed every block**. Because each tail reward is added back
    ///   into `total_mined`, the tail compounds: gross issuance grows by
    ///   `(tail_inflation_bps + expected_fee_burn_rate_bps)` per policy-year
    ///   (2.5% for mainnet), not by a fixed per-block amount (#1699).
    ///
    /// A drift guard in `botho` (`ledger::emission_parity_tests`) pins this to
    /// the node over 20 policy-years.
    pub fn block_reward_at(&self, height: u64, total_mined: u128) -> u64 {
        if self.is_halving_phase(height) {
            self.halving_reward(height).unwrap_or(1)
        } else {
            self.calculate_tail_reward_u128(total_mined)
        }
    }

    /// Cumulative gross issuance (picocredits) after the block at `height` has
    /// been applied, with the node's height convention: genesis (height 0)
    /// mints nothing and every block `h >= 1` mints
    /// [`Self::block_reward_at`]`(h, issuance through h - 1)`.
    ///
    /// This is the value the node stores as `ChainState::total_mined` at that
    /// tip. Phase 1 is summed in closed form; the tail is iterated block by
    /// block because the reward changes every block (it is a function of the
    /// running total). Cost is O(tail blocks) — about 6.3M iterations per
    /// mainnet policy-year of tail.
    pub fn cumulative_issuance_at(&self, height: u64) -> u128 {
        self.issuance_at_checkpoints(&[height])[0]
    }

    /// [`Self::cumulative_issuance_at`] for several heights in one pass.
    ///
    /// `checkpoints` may be in any order; the result is in the same order.
    pub fn issuance_at_checkpoints(&self, checkpoints: &[u64]) -> Vec<u128> {
        let mut order: Vec<usize> = (0..checkpoints.len()).collect();
        order.sort_by_key(|&i| checkpoints[i]);
        let mut out = vec![0u128; checkpoints.len()];

        let tail_start = self.tail_emission_start_height();
        let mut height = 0u64; // last applied block
        let mut total = 0u128;
        for i in order {
            let target = checkpoints[i];
            if target > height {
                // Phase-1 part in closed form.
                if height + 1 < tail_start {
                    let last = target.min(tail_start - 1);
                    total += self.halving_issuance_between(height + 1, last);
                    height = last;
                }
                // Tail part, block by block (reward depends on the total).
                while height < target {
                    height += 1;
                    total += self.block_reward_at(height, total) as u128;
                }
            }
            out[i] = total;
        }
        out
    }

    /// Sum of halving rewards for heights `first..=last` (all in Phase 1).
    fn halving_issuance_between(&self, first: u64, last: u64) -> u128 {
        if first > last || self.halving_interval == 0 {
            return 0;
        }
        let h = self.halving_interval;
        let mut total = 0u128;
        for epoch in (first / h)..=(last / h) {
            if epoch >= self.halving_count as u64 {
                break;
            }
            let lo = first.max(epoch * h);
            let hi = last.min((epoch + 1) * h - 1);
            if lo <= hi {
                total += (hi - lo + 1) as u128 * (self.initial_reward >> epoch) as u128;
            }
        }
        total
    }

    /// Blocks per year at target block time.
    pub fn target_blocks_per_year(&self) -> u64 {
        let secs_per_year: u64 = 365 * 24 * 3600;
        secs_per_year / self.target_block_time_secs
    }

    /// Epochs per year at target block time.
    pub fn target_epochs_per_year(&self) -> u64 {
        self.target_blocks_per_year() / self.difficulty_adjustment_interval
    }
}

/// Node constants the emission model mirrors (#1699).
///
/// `cluster-tax` cannot depend on `botho`, so these are copies. Each one is
/// drift-guarded by `botho`'s `ledger::emission_parity_tests`, which fails CI
/// if the node's value changes without this copy following.
pub mod node_constants {
    /// Share of every block's transaction fees (base fee **and** the
    /// demurrage charge, which is collected as part of the fee) that the node
    /// destroys, in permille. The rest (800‰) goes to the lottery pool and is
    /// paid back out. Mirrors `1000 - pool_fraction_permille` of the node's
    /// canonical lottery config (`ledger::lottery_v2::canonical_config`).
    pub const FEE_BURN_SHARE_PERMILLE: u32 = 200;

    /// The time-based difficulty controller's target inter-block time
    /// (`botho::block::difficulty::TARGET_BLOCK_TIME_SECS`). The node targets
    /// block **time**, in both phases; it has no inflation-targeting
    /// controller (M5, #554).
    pub const TARGET_BLOCK_TIME_SECS: u64 = 5;

    /// Consensus floor on block time
    /// (`ConsensusConfig::MIN_BLOCK_TIME_SECS`).
    pub const MIN_BLOCK_TIME_SECS: u64 = 3;

    /// Idle ceiling on block time (`dynamic_timing::MAX_BLOCK_TIME`).
    pub const MAX_BLOCK_TIME_SECS: u64 = 40;

    /// The load-paced block-time tiers `(tx_rate_threshold, block_time_secs)`
    /// (`dynamic_timing::BLOCK_TIME_LEVELS`). Blocks are produced at the tier
    /// matching the recent transaction rate, so wall-clock emission depends
    /// on load: one policy-year (6,307,200 blocks) lasts 0.6 calendar years at
    /// 3 s blocks and 8 calendar years at 40 s blocks.
    pub const BLOCK_TIME_LEVELS: [(f64, u64); 5] =
        [(20.0, 3), (5.0, 5), (1.0, 10), (0.2, 20), (0.0, 40)];

    /// Block time the node's load pacing selects for a sustained `tx_rate`
    /// (tx/s), as `dynamic_timing::compute_block_time` does.
    pub fn block_time_for_tx_rate(tx_rate: f64) -> u64 {
        for (threshold, secs) in BLOCK_TIME_LEVELS {
            if tx_rate >= threshold {
                return secs;
            }
        }
        MAX_BLOCK_TIME_SECS
    }
}

/// A copy of the canonical mainnet schedule, `botho::monetary::mainnet_policy`
/// (ratified #351: 50 BTH, ~1-year halvings x 5, 2% tail calibrated with a
/// 0.5% assumed fee burn, 5 s reference blocks).
///
/// For simulations that need the node's real policy. Drift-guarded in
/// `botho` (`ledger::emission_parity_tests`): any change to the node's policy
/// fails CI until this copy is updated. This is NOT a place to change the
/// policy — the ratified parameters live in the node.
pub fn mainnet_policy_mirror() -> MonetaryPolicy {
    const SECS_PER_YEAR: u64 = 365 * 24 * 60 * 60;
    const BLOCKS_PER_YEAR: u64 = SECS_PER_YEAR / 5;
    MonetaryPolicy {
        initial_reward: 50_000_000_000_000,
        halving_interval: BLOCKS_PER_YEAR,
        halving_count: 5,
        tail_inflation_bps: 200,
        target_block_time_secs: 5,
        min_block_time_secs: 3,
        max_block_time_secs: 60,
        difficulty_adjustment_interval: BLOCKS_PER_YEAR / 365,
        max_difficulty_adjustment_bps: 2500,
        expected_fee_burn_rate_bps: 50,
    }
}

/// Current state of the monetary system.
#[derive(Clone, Debug)]
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
pub struct MonetaryState {
    /// Current block height.
    pub height: u64,

    /// Total circulating supply.
    pub total_supply: u64,

    /// Current minting difficulty.
    /// Higher = harder to mine = slower blocks.
    pub difficulty: u64,

    /// Block reward for Phase 2 (set at transition).
    /// None during Phase 1.
    pub tail_reward: Option<u64>,

    // === Epoch Tracking ===
    /// Block height at start of current difficulty epoch.
    pub epoch_start_height: u64,

    /// Timestamp (seconds) at start of current difficulty epoch.
    pub epoch_start_time: u64,

    /// Total rewards emitted in current epoch.
    pub epoch_rewards_emitted: u64,

    /// Total fees burned in current epoch.
    pub epoch_fees_burned: u64,

    // === Cumulative Stats ===
    /// Total rewards emitted all time.
    pub total_rewards_emitted: u64,

    /// Total fees burned all time.
    pub total_fees_burned: u64,

    /// Number of difficulty adjustments made.
    pub adjustment_count: u64,

    /// Cumulative gross issuance: the initial supply plus every block reward,
    /// never reduced by burns. The sim's analogue of the node's
    /// `ChainState::total_mined`, which is what the node's tail reward is
    /// computed from (#1699). `u128` like the node's.
    ///
    /// Caveat: state serialized before #1699 lacks this field and deserializes
    /// as 0, which would drop Phase-2 rewards to the 1-pico floor. Nothing
    /// persists `MonetaryState` today; anything that starts to must migrate
    /// old records (initial supply plus `total_rewards_emitted`) first.
    #[cfg_attr(feature = "serde", serde(default))]
    pub gross_issued: u128,
}

impl MonetaryState {
    /// Create initial state.
    pub fn new(initial_supply: u64, initial_difficulty: u64, start_time: u64) -> Self {
        Self {
            height: 0,
            total_supply: initial_supply,
            difficulty: initial_difficulty,
            tail_reward: None,

            epoch_start_height: 0,
            epoch_start_time: start_time,
            epoch_rewards_emitted: 0,
            epoch_fees_burned: 0,

            total_rewards_emitted: 0,
            total_fees_burned: 0,
            adjustment_count: 0,

            gross_issued: initial_supply as u128,
        }
    }

    /// Net supply change since genesis.
    pub fn net_supply_change(&self) -> i64 {
        self.total_rewards_emitted as i64 - self.total_fees_burned as i64
    }

    /// Current effective inflation rate (annualized, in bps).
    pub fn effective_inflation_bps(&self, policy: &MonetaryPolicy) -> i64 {
        if self.total_supply == 0 || self.height == 0 {
            return 0;
        }

        // Estimate time elapsed based on target block time
        let estimated_secs = self.height * policy.target_block_time_secs;
        let years = estimated_secs as f64 / (365.25 * 24.0 * 3600.0);

        if years < 0.001 {
            return 0;
        }

        let net_change = self.net_supply_change();
        let annual_rate = net_change as f64 / self.total_supply as f64 / years;

        (annual_rate * 10_000.0) as i64
    }

    /// Blocks mined in current epoch.
    pub fn blocks_in_epoch(&self) -> u64 {
        self.height - self.epoch_start_height
    }
}

/// Difficulty controller implementing the two-phase monetary policy.
#[derive(Clone, Debug)]
pub struct DifficultyController {
    pub policy: MonetaryPolicy,
    pub state: MonetaryState,
}

impl DifficultyController {
    /// Create a new difficulty controller.
    pub fn new(
        policy: MonetaryPolicy,
        initial_supply: u64,
        initial_difficulty: u64,
        start_time: u64,
    ) -> Self {
        Self {
            policy,
            state: MonetaryState::new(initial_supply, initial_difficulty, start_time),
        }
    }

    /// Get the reward for the next block.
    ///
    /// Node parity (#1699): the next block has node height
    /// `state.height + 1` (genesis mints nothing), and its reward is
    /// [`MonetaryPolicy::block_reward_at`] of the cumulative gross issuance —
    /// in the tail this is recomputed every block, exactly as the node's
    /// `calculate_block_reward(height, total_mined)` does. (It used to be
    /// fixed once at the phase transition, from supply *net* of burns, which
    /// understated post-tail issuance.)
    pub fn block_reward(&self) -> u64 {
        self.policy
            .block_reward_at(self.state.height + 1, self.state.gross_issued)
    }

    /// Record a fee burn.
    pub fn record_fee_burn(&mut self, amount: u64) {
        self.state.epoch_fees_burned += amount;
        self.state.total_fees_burned += amount;
        self.state.total_supply = self.state.total_supply.saturating_sub(amount);
    }

    /// Process a mined block.
    ///
    /// Returns the block reward. Call this after a block is successfully mined.
    pub fn process_block(&mut self, block_time: u64) -> u64 {
        let reward = self.block_reward();

        // Update state
        self.state.height += 1;
        self.state.total_supply += reward;
        self.state.total_rewards_emitted += reward;
        self.state.epoch_rewards_emitted += reward;
        self.state.gross_issued += reward as u128;

        // Informational: the tail reward the *next* block will pay, once the
        // next block is in Phase 2. It changes every block (node parity,
        // #1699); `block_reward()` is the authority.
        if !self.policy.is_halving_phase(self.state.height + 1) {
            self.state.tail_reward = Some(self.block_reward());
        }

        // Check for difficulty adjustment
        if self.state.blocks_in_epoch() >= self.policy.difficulty_adjustment_interval {
            self.adjust_difficulty(block_time);
        }

        reward
    }

    /// Adjust difficulty at epoch boundary.
    ///
    /// Node parity (#1699): the node's only difficulty controller
    /// (`botho::block::difficulty::EmissionController`, M5 #554) targets
    /// **block time** (`TARGET_BLOCK_TIME_SECS` = 5 s) in both phases. It has
    /// no inflation target; the tail's monetary behaviour comes entirely from
    /// the supply-dependent reward. So Phase 2 uses the same block-time
    /// adjustment as Phase 1. The node adjusts per block with a [0.5x, 2x]
    /// clamp, this controller per epoch with a rate clamp — same target,
    /// coarser kernel. The former inflation-targeting Phase-2 controller is
    /// kept below as [`Self::monetary_adjustment`] (unused).
    fn adjust_difficulty(&mut self, current_time: u64) {
        let new_difficulty = self.traditional_adjustment(current_time);

        // Apply new difficulty and reset epoch
        self.state.difficulty = new_difficulty;
        self.state.epoch_start_height = self.state.height;
        self.state.epoch_start_time = current_time;
        self.state.epoch_rewards_emitted = 0;
        self.state.epoch_fees_burned = 0;
        self.state.adjustment_count += 1;
    }

    /// Traditional difficulty adjustment (Phase 1): target block time.
    fn traditional_adjustment(&self, current_time: u64) -> u64 {
        let elapsed = current_time.saturating_sub(self.state.epoch_start_time);
        let blocks = self.state.blocks_in_epoch();

        if elapsed == 0 || blocks == 0 {
            return self.state.difficulty;
        }

        // Expected time for this many blocks
        let expected = self.policy.target_block_time_secs * blocks;

        // If blocks came too fast (elapsed < expected), difficulty rises.
        // CONSENSUS-CRITICAL: pure integer arithmetic — difficulty is
        // validated state (minting txs are rejected on mismatch), so every
        // node must compute the identical value.
        let proposed = (self.state.difficulty as u128 * expected as u128) / elapsed as u128;

        self.apply_bounded_adjustment(proposed)
    }

    /// LEGACY (superseded, #1699): monetary-aware Phase-2 adjustment that
    /// targets net inflation.
    ///
    /// The node never ran this — its controller targets block time in both
    /// phases (M5, #554) — so the simulator no longer uses it either. Kept
    /// (CLAUDE.md: stash rather than delete) and exercised by a unit test so
    /// it can be recovered if an inflation-targeting controller is ever
    /// proposed.
    #[allow(dead_code)]
    fn monetary_adjustment(&self, current_time: u64) -> u64 {
        let elapsed = current_time.saturating_sub(self.state.epoch_start_time);
        let blocks = self.state.blocks_in_epoch();

        if elapsed == 0 || blocks == 0 {
            return self.state.difficulty;
        }

        // CONSENSUS-CRITICAL: all ratios in integer basis points
        // (10_000 = 1.0x) — difficulty is validated state, so every node
        // must compute the identical value.
        const RATIO_SCALE: u128 = 10_000;

        // === Timing Component ===
        let expected_time = self.policy.target_block_time_secs * blocks;
        let timing_ratio_bps = expected_time as u128 * RATIO_SCALE / elapsed as u128;

        // === Monetary Component ===
        // Calculate actual net emission this epoch
        let net_emission =
            self.state.epoch_rewards_emitted as i64 - self.state.epoch_fees_burned as i64;

        // Calculate target net emission per epoch
        let epochs_per_year = self.policy.target_epochs_per_year();
        let annual_target =
            self.state.total_supply as u128 * self.policy.tail_inflation_bps as u128 / 10_000;
        let epoch_target = (annual_target / epochs_per_year as u128) as i64;

        // If net emission is too high, we need slower blocks (higher difficulty)
        //   → ratio > 1.0x → multiply difficulty up
        // If net emission is too low, we need faster blocks (lower difficulty)
        //   → ratio < 1.0x → multiply difficulty down
        let monetary_ratio_bps: u128 = if net_emission > 0 && epoch_target > 0 {
            // Normal case: what fraction of target did we achieve?
            net_emission as u128 * RATIO_SCALE / epoch_target as u128
        } else if net_emission <= 0 {
            // We're in deflation! Speed up significantly (lower difficulty),
            // but no lower than min/max block time ratio, floored at 0.5x.
            let bt_ratio_bps = self.policy.min_block_time_secs as u128 * RATIO_SCALE
                / self.policy.max_block_time_secs.max(1) as u128;
            bt_ratio_bps.max(RATIO_SCALE / 2)
        } else {
            // Edge case: target is 0 or negative (shouldn't happen)
            RATIO_SCALE
        };

        // === Blend ===
        // In Phase 2, prioritize monetary target but don't ignore timing
        // stability: 70% monetary, 30% timing
        let combined_ratio_bps = (timing_ratio_bps * 3 + monetary_ratio_bps * 7) / 10;

        let proposed = self.state.difficulty as u128 * combined_ratio_bps / RATIO_SCALE;
        self.apply_bounded_adjustment(proposed)
    }

    /// Apply adjustment with bounds.
    ///
    /// `proposed` is the unbounded new difficulty (u128 to tolerate
    /// intermediate overflow); the result is rate-limited around the
    /// current difficulty.
    fn apply_bounded_adjustment(&self, proposed: u128) -> u64 {
        let current = self.state.difficulty;

        let new = u64::try_from(proposed).unwrap_or(u64::MAX).max(1);

        // Bound by max adjustment rate
        let max_change =
            current as u128 * self.policy.max_difficulty_adjustment_bps as u128 / 10_000;
        let max_change = (max_change as u64).max(1);

        let rate_floor = current.saturating_sub(max_change);
        let rate_ceiling = current.saturating_add(max_change);

        // Also bound by block time limits (for Phase 2)
        // This only applies meaningfully when we're in monetary adjustment mode
        // Higher difficulty = slower blocks, so:
        // - min_difficulty corresponds to max_block_time (easier = slower)
        // - max_difficulty corresponds to min_block_time (harder = faster)
        //
        // But these are relative to TARGET, not current. We need to think about
        // what difficulty would produce the min/max block times.
        //
        // For simplicity, we just apply rate bounds. Block time bounds are
        // implicitly maintained by the gradual rate limits over multiple epochs.

        // Apply rate bounds only
        new.clamp(rate_floor.max(1), rate_ceiling)
    }

    /// Get current phase description.
    pub fn phase(&self) -> &'static str {
        if self.policy.is_halving_phase(self.state.height) {
            "Halving"
        } else {
            "Tail Emission"
        }
    }

    /// Get current halving number (0-indexed), or None if in tail emission.
    pub fn current_halving(&self) -> Option<u32> {
        if self.policy.is_halving_phase(self.state.height) {
            Some((self.state.height / self.policy.halving_interval) as u32)
        } else {
            None
        }
    }

    /// Blocks until next halving, or None if in tail emission.
    pub fn blocks_until_next_halving(&self) -> Option<u64> {
        if self.policy.is_halving_phase(self.state.height) {
            let next_halving_height = ((self.state.height / self.policy.halving_interval) + 1)
                * self.policy.halving_interval;
            Some(next_halving_height - self.state.height)
        } else {
            None
        }
    }

    /// Estimate current block time based on recent epoch.
    pub fn estimated_block_time(&self, current_time: u64) -> f64 {
        let elapsed = current_time.saturating_sub(self.state.epoch_start_time);
        let blocks = self.state.blocks_in_epoch();

        if blocks == 0 {
            return self.policy.target_block_time_secs as f64;
        }

        elapsed as f64 / blocks as f64
    }
}

/// Statistics snapshot for reporting.
#[derive(Clone, Debug)]
pub struct MonetaryStats {
    pub height: u64,
    pub phase: &'static str,
    pub current_halving: Option<u32>,
    pub blocks_until_halving: Option<u64>,
    pub block_reward: u64,
    pub difficulty: u64,
    pub total_supply: u64,
    pub total_rewards_emitted: u64,
    pub total_fees_burned: u64,
    pub net_supply_change: i64,
    pub effective_inflation_bps: i64,
    pub estimated_block_time: f64,
}

impl DifficultyController {
    /// Get a statistics snapshot.
    pub fn stats(&self, current_time: u64) -> MonetaryStats {
        MonetaryStats {
            height: self.state.height,
            phase: self.phase(),
            current_halving: self.current_halving(),
            blocks_until_halving: self.blocks_until_next_halving(),
            block_reward: self.block_reward(),
            difficulty: self.state.difficulty,
            total_supply: self.state.total_supply,
            total_rewards_emitted: self.state.total_rewards_emitted,
            total_fees_burned: self.state.total_fees_burned,
            net_supply_change: self.state.net_supply_change(),
            effective_inflation_bps: self.state.effective_inflation_bps(&self.policy),
            estimated_block_time: self.estimated_block_time(current_time),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_halving_reward() {
        let policy = MonetaryPolicy {
            initial_reward: 1000,
            halving_interval: 100,
            halving_count: 3,
            ..Default::default()
        };

        // Before first halving
        assert_eq!(policy.halving_reward(0), Some(1000));
        assert_eq!(policy.halving_reward(50), Some(1000));
        assert_eq!(policy.halving_reward(99), Some(1000));

        // After first halving
        assert_eq!(policy.halving_reward(100), Some(500));
        assert_eq!(policy.halving_reward(150), Some(500));

        // After second halving (height 200-299)
        assert_eq!(policy.halving_reward(200), Some(250));
        assert_eq!(policy.halving_reward(299), Some(250));

        // After all halvings (tail emission)
        assert_eq!(policy.halving_reward(300), None);
        assert_eq!(policy.halving_reward(1000), None);
    }

    #[test]
    fn test_lottery_emission_schedule() {
        let policy = MonetaryPolicy {
            initial_reward: 1000,
            halving_interval: 100,
            halving_count: 3,
            ..Default::default()
        };

        // Epoch 0 (bootstrap): no lottery emission — mining seeds the network
        assert_eq!(policy.lottery_emission_bps(0), 0);
        assert_eq!(policy.lottery_emission_bps(99), 0);
        assert_eq!(policy.lottery_emission_share(50, 1000), 0);

        // Ramp: +10% per halving epoch
        assert_eq!(policy.lottery_emission_bps(100), 1000); // 10%
        assert_eq!(policy.lottery_emission_bps(250), 2000); // 20%
        assert_eq!(policy.lottery_emission_share(100, 500), 50);

        // Capped at 50%: the tail emission stays at least half mining
        // security budget
        assert_eq!(policy.lottery_emission_bps(100 * 5), 5000);
        assert_eq!(policy.lottery_emission_bps(1_000_000), 5000);
        assert_eq!(policy.lottery_emission_share(1_000_000, 1000), 500);

        // Degenerate config must not panic or divide by zero
        let zero_policy = MonetaryPolicy {
            halving_interval: 0,
            ..Default::default()
        };
        assert_eq!(zero_policy.lottery_emission_bps(12345), 0);
    }

    #[test]
    fn test_demurrage_schedule() {
        let policy = MonetaryPolicy {
            initial_reward: 1000,
            halving_interval: 100,
            halving_count: 3,
            ..Default::default()
        };

        // Epoch 0 (bootstrap): no demurrage — early UTXOs are miner
        // coinbases and demurrage would discourage network seeding
        assert_eq!(policy.demurrage_rate_bps(0), 0);
        assert_eq!(policy.demurrage_rate_bps(99), 0);

        // From epoch 1: full validated rate (2%/yr at factor 6)
        assert_eq!(policy.demurrage_rate_bps(100), 200);
        assert_eq!(policy.demurrage_rate_bps(1_000_000), 200);

        // Degenerate config must not panic
        let zero_policy = MonetaryPolicy {
            halving_interval: 0,
            ..Default::default()
        };
        assert_eq!(zero_policy.demurrage_rate_bps(12345), 0);
    }

    #[test]
    fn test_phase_transition() {
        let policy = MonetaryPolicy::fast_test();
        let mut controller = DifficultyController::new(policy, 100_000, 1000, 0);

        assert_eq!(controller.phase(), "Halving");
        assert!(controller.state.tail_reward.is_none());

        // Mine through halving phase
        // 3 halvings × 100 blocks = 300 blocks
        for block_num in 1..=300 {
            controller.process_block(block_num);
        }

        assert_eq!(controller.phase(), "Tail Emission");
        assert!(controller.state.tail_reward.is_some());
    }

    #[test]
    fn test_halving_reduces_reward() {
        let policy = MonetaryPolicy {
            initial_reward: 1000,
            halving_interval: 10,
            halving_count: 3,
            difficulty_adjustment_interval: 100, // Don't adjust during test
            ..MonetaryPolicy::fast_test()
        };
        let mut controller = DifficultyController::new(policy, 0, 1000, 0);

        // First halving period
        assert_eq!(controller.block_reward(), 1000);

        for i in 1..=10 {
            controller.process_block(i);
        }

        // Second halving period
        assert_eq!(controller.block_reward(), 500);

        for i in 11..=20 {
            controller.process_block(i);
        }

        // Third halving period
        assert_eq!(controller.block_reward(), 250);
    }

    #[test]
    fn test_fee_burn_tracking() {
        let policy = MonetaryPolicy::fast_test();
        let mut controller = DifficultyController::new(policy, 100_000, 1000, 0);

        controller.record_fee_burn(500);
        assert_eq!(controller.state.epoch_fees_burned, 500);
        assert_eq!(controller.state.total_fees_burned, 500);
        assert_eq!(controller.state.total_supply, 99_500);

        controller.record_fee_burn(300);
        assert_eq!(controller.state.epoch_fees_burned, 800);
        assert_eq!(controller.state.total_fees_burned, 800);
        assert_eq!(controller.state.total_supply, 99_200);
    }

    #[test]
    fn test_traditional_difficulty_adjustment() {
        let policy = MonetaryPolicy {
            target_block_time_secs: 10,
            difficulty_adjustment_interval: 10,
            max_difficulty_adjustment_bps: 5000,
            ..MonetaryPolicy::fast_test()
        };
        let mut controller = DifficultyController::new(policy, 100_000, 1000, 0);

        // Mine 10 blocks in half the expected time (blocks too fast)
        // Expected: 10 blocks × 10 secs = 100 secs
        // Actual: 50 secs
        for i in 1..=10 {
            controller.process_block(i * 5); // 5 secs per block
        }

        // Difficulty should have increased (blocks were too fast)
        assert!(
            controller.state.difficulty > 1000,
            "Difficulty should increase when blocks are fast: {}",
            controller.state.difficulty
        );
    }

    #[test]
    fn test_monetary_difficulty_adjustment() {
        let policy = MonetaryPolicy {
            initial_reward: 100,
            halving_interval: 10,
            halving_count: 1, // Quick transition to tail
            tail_inflation_bps: 200,
            target_block_time_secs: 10,
            difficulty_adjustment_interval: 10,
            max_difficulty_adjustment_bps: 5000,
            expected_fee_burn_rate_bps: 100,
            ..MonetaryPolicy::fast_test()
        };
        let mut controller = DifficultyController::new(policy, 100_000, 1000, 0);

        // Get through halving phase with correct timing
        for i in 1..=10 {
            controller.process_block(i * 10); // Exactly target block time
        }

        assert_eq!(controller.phase(), "Tail Emission");

        // Mine another epoch at correct timing to establish baseline
        for i in 11..=20 {
            controller.process_block(i * 10);
        }
        let baseline_difficulty = controller.state.difficulty;

        // Node parity (#1699): fee burns do NOT move difficulty. The node's
        // controller targets block time in both phases; only timing does.
        controller.record_fee_burn(50_000); // Very large burn (50% of supply!)

        // Mine another epoch at correct timing
        for i in 21..=30 {
            controller.process_block(i * 10);
        }
        assert_eq!(
            controller.state.difficulty, baseline_difficulty,
            "Phase-2 difficulty must ignore fee burns (block-time target only)"
        );

        // Slow blocks in the tail ease difficulty, exactly as in Phase 1.
        for i in 31..=40 {
            controller.process_block(300 + (i - 30) * 20); // 2x target
        }
        assert!(
            controller.state.difficulty < baseline_difficulty,
            "slow tail blocks should lower difficulty: {} vs {}",
            controller.state.difficulty,
            baseline_difficulty
        );
    }

    /// The superseded inflation-targeting Phase-2 kernel still computes what
    /// it used to (kept for recovery, #1699): a burn-induced emission deficit
    /// proposes a lower difficulty.
    #[test]
    fn test_legacy_monetary_adjustment_still_targets_inflation() {
        let policy = MonetaryPolicy {
            initial_reward: 100,
            halving_interval: 10,
            halving_count: 1,
            target_block_time_secs: 10,
            difficulty_adjustment_interval: 10,
            max_difficulty_adjustment_bps: 5000,
            expected_fee_burn_rate_bps: 100,
            ..MonetaryPolicy::fast_test()
        };
        let mut controller = DifficultyController::new(policy, 100_000, 1000, 0);
        for i in 1..=15 {
            controller.process_block(i * 10);
        }
        let before = controller.state.difficulty;
        controller.record_fee_burn(50_000);
        let proposed = controller.monetary_adjustment(150);
        assert!(proposed < before, "{proposed} vs {before}");
    }

    #[test]
    fn test_difficulty_bounds() {
        let policy = MonetaryPolicy {
            target_block_time_secs: 10,
            min_block_time_secs: 8,
            max_block_time_secs: 12,
            difficulty_adjustment_interval: 5,
            max_difficulty_adjustment_bps: 2500, // 25% max change
            ..MonetaryPolicy::fast_test()
        };
        let mut controller = DifficultyController::new(policy, 100_000, 1000, 0);

        // Mine blocks extremely fast (1 sec each, target is 10)
        for i in 1..=5 {
            controller.process_block(i);
        }

        // Difficulty should increase but be bounded by 25% max change
        let max_expected = 1000 + (1000 * 2500 / 10_000); // 1250
        assert!(
            controller.state.difficulty <= max_expected,
            "Difficulty {} should be bounded by max adjustment rate (max {})",
            controller.state.difficulty,
            max_expected
        );
        assert!(
            controller.state.difficulty > 1000,
            "Difficulty should have increased from 1000: {}",
            controller.state.difficulty
        );
    }

    #[test]
    fn test_net_supply_change() {
        let policy = MonetaryPolicy::fast_test();
        let mut controller = DifficultyController::new(policy, 100_000, 1000, 0);

        // Mine some blocks
        for i in 1..=10 {
            controller.process_block(i);
        }
        let rewards = controller.state.total_rewards_emitted;

        // Burn some fees
        controller.record_fee_burn(500);

        assert_eq!(controller.state.net_supply_change(), rewards as i64 - 500);
    }

    #[test]
    fn test_tail_reward_calculation() {
        let policy = MonetaryPolicy {
            tail_inflation_bps: 200,        // 2%
            expected_fee_burn_rate_bps: 50, // 0.5%
            target_block_time_secs: 60,     // 1 minute
            ..Default::default()
        };

        let supply = 100_000_000u64; // 100M
        let tail_reward = policy.calculate_tail_reward(supply);

        // Annual target: 2% of 100M = 2M net
        // Expected burns: 0.5% of 100M = 0.5M
        // Gross needed: 2.5M
        // Blocks per year: 525,600 (at 1 min)
        // Reward per block: 2.5M / 525,600 ≈ 4.76

        let blocks_per_year = 365 * 24 * 60; // 525,600
        let expected_gross = 2_500_000u64;
        let expected_reward = expected_gross / blocks_per_year;

        assert!(
            (tail_reward as i64 - expected_reward as i64).abs() < 2,
            "Tail reward {} should be close to {}",
            tail_reward,
            expected_reward
        );
    }

    #[test]
    fn test_stats_snapshot() {
        let policy = MonetaryPolicy::fast_test();
        let mut controller = DifficultyController::new(policy, 100_000, 1000, 0);

        for i in 1..=50 {
            controller.process_block(i);
        }
        controller.record_fee_burn(1000);

        let stats = controller.stats(50);

        assert_eq!(stats.height, 50);
        assert_eq!(stats.phase, "Halving");
        assert_eq!(stats.total_fees_burned, 1000);
        assert!(stats.total_rewards_emitted > 0);
    }

    #[test]
    fn test_blocks_until_halving() {
        let policy = MonetaryPolicy {
            halving_interval: 100,
            halving_count: 3,
            ..MonetaryPolicy::fast_test()
        };
        let mut controller = DifficultyController::new(policy, 100_000, 1000, 0);

        assert_eq!(controller.blocks_until_next_halving(), Some(100));

        for i in 1..=50 {
            controller.process_block(i);
        }
        assert_eq!(controller.blocks_until_next_halving(), Some(50));

        for i in 51..=100 {
            controller.process_block(i);
        }
        assert_eq!(controller.blocks_until_next_halving(), Some(100));

        // Get to tail emission
        for i in 101..=300 {
            controller.process_block(i);
        }
        assert_eq!(controller.blocks_until_next_halving(), None);
    }

    // === Edge Case Tests ===

    #[test]
    fn test_zero_initial_supply() {
        let policy = MonetaryPolicy::fast_test();
        let mut controller = DifficultyController::new(policy, 0, 1000, 0);

        // Should still work - minting creates supply
        let reward = controller.process_block(1);
        assert!(reward > 0);
        assert_eq!(controller.state.total_supply, reward);
    }

    #[test]
    fn test_minimum_difficulty() {
        let policy = MonetaryPolicy::fast_test();
        let mut controller = DifficultyController::new(policy, 100_000, 1, 0);

        // Difficulty should never go below 1
        assert_eq!(controller.state.difficulty, 1);

        // Even with slow blocks, difficulty shouldn't go to 0
        for i in 1..=10 {
            controller.process_block(i * 1000); // Very slow blocks
        }
        assert!(
            controller.state.difficulty >= 1,
            "Difficulty should never be 0: {}",
            controller.state.difficulty
        );
    }

    #[test]
    fn test_fee_burn_exceeds_rewards() {
        let policy = MonetaryPolicy {
            initial_reward: 100,
            halving_interval: 10,
            halving_count: 1,
            tail_inflation_bps: 200,
            difficulty_adjustment_interval: 5,
            max_difficulty_adjustment_bps: 5000,
            ..MonetaryPolicy::fast_test()
        };
        let mut controller = DifficultyController::new(policy, 100_000, 1000, 0);

        // Get to tail emission
        for i in 1..=10 {
            controller.process_block(i * 10);
        }

        // Burn more than rewards in epoch
        let epoch_start_difficulty = controller.state.difficulty;
        controller.record_fee_burn(100_000); // Massive burn

        // Mine through an epoch at the target block time (fast_test: 1 s).
        for i in 11..=15 {
            controller.process_block(100 + (i - 10));
        }

        // Node parity (#1699): deflation does not move difficulty — the node
        // has no inflation controller. Net supply falls; difficulty holds.
        assert_eq!(controller.state.difficulty, epoch_start_difficulty);
        assert!(controller.state.net_supply_change() < 0);
        // Tail rewards keep being paid from gross issuance, not net supply.
        assert!(controller.block_reward() >= 1);
    }

    // === Node parity: per-block tail recompute (#1699) ===

    #[test]
    fn block_reward_at_matches_phase_rules() {
        let p = mainnet_policy_mirror();
        let h = p.halving_interval;
        assert_eq!(p.block_reward_at(1, 0), 50_000_000_000_000);
        assert_eq!(p.block_reward_at(h - 1, 0), 50_000_000_000_000);
        assert_eq!(p.block_reward_at(h, 0), 25_000_000_000_000);
        assert_eq!(p.block_reward_at(5 * h - 1, 0), 50_000_000_000_000 >> 4);
        // Tail: a pure function of total_mined (2.5% / blocks-per-year).
        let s = 611_010_000u128 * 1_000_000_000_000;
        assert_eq!(p.block_reward_at(5 * h, s), p.calculate_tail_reward_u128(s));
        assert_eq!(p.block_reward_at(9 * h, s), p.calculate_tail_reward_u128(s));
    }

    #[test]
    fn cumulative_issuance_matches_block_by_block_sum() {
        // Small schedule so a naive per-block loop is cheap.
        let p = MonetaryPolicy {
            initial_reward: 1_000_000_000_000,
            halving_interval: 1_000,
            halving_count: 3,
            target_block_time_secs: 31_536, // 1_000 blocks per "year"
            ..MonetaryPolicy::default()
        };
        let mut total = 0u128;
        let mut naive = vec![0u128];
        for h in 1..=10_000u64 {
            total += p.block_reward_at(h, total) as u128;
            naive.push(total);
        }
        let checkpoints = [0u64, 1, 999, 1_000, 2_999, 3_000, 3_001, 5_000, 10_000];
        let fast = p.issuance_at_checkpoints(&checkpoints);
        for (i, &c) in checkpoints.iter().enumerate() {
            assert_eq!(fast[i], naive[c as usize], "height {c}");
            assert_eq!(p.cumulative_issuance_at(c), naive[c as usize]);
        }
        // Unordered checkpoints come back in input order.
        assert_eq!(
            p.issuance_at_checkpoints(&[5_000, 1]),
            vec![naive[5_000], naive[1]]
        );
        // The tail compounds: the last tail reward exceeds the first.
        assert!(p.block_reward_at(10_000, naive[9_999]) > p.block_reward_at(3_000, naive[2_999]));
    }

    #[test]
    fn controller_tail_is_recomputed_from_gross_issuance() {
        let p = MonetaryPolicy {
            initial_reward: 1_000_000_000_000,
            halving_interval: 100,
            halving_count: 2,
            target_block_time_secs: 315_360, // 100 blocks per "year"
            difficulty_adjustment_interval: 1_000_000,
            ..MonetaryPolicy::default()
        };
        let mut c = DifficultyController::new(p.clone(), 0, 1000, 0);
        for h in 1..=1_000u64 {
            c.process_block(h);
            // Burns reduce net supply but not the gross base of the reward.
            if h % 10 == 0 {
                c.record_fee_burn(1_000);
            }
        }
        assert_eq!(c.state.gross_issued, p.cumulative_issuance_at(1_000));
        assert_eq!(
            c.state.total_supply as u128,
            p.cumulative_issuance_at(1_000) - 100 * 1_000
        );
    }

    #[test]
    fn test_very_slow_blocks() {
        let policy = MonetaryPolicy {
            target_block_time_secs: 10,
            difficulty_adjustment_interval: 5,
            max_difficulty_adjustment_bps: 5000,
            ..MonetaryPolicy::fast_test()
        };
        let mut controller = DifficultyController::new(policy, 100_000, 1000, 0);

        // Blocks come 10x slower than target
        for i in 1..=5 {
            controller.process_block(i * 100); // 100 secs each vs 10 target
        }

        // Difficulty should decrease
        assert!(
            controller.state.difficulty < 1000,
            "Difficulty should decrease for slow blocks: {}",
            controller.state.difficulty
        );
    }

    #[test]
    fn test_instant_blocks() {
        let policy = MonetaryPolicy {
            target_block_time_secs: 60,
            difficulty_adjustment_interval: 5,
            max_difficulty_adjustment_bps: 2500,
            ..MonetaryPolicy::fast_test()
        };
        let mut controller = DifficultyController::new(policy, 100_000, 1000, 0);

        // All blocks at same timestamp (elapsed = 0 edge case)
        for _ in 1..=5 {
            controller.process_block(0); // All at time 0
        }

        // Should handle gracefully - difficulty should stay same or increase
        assert!(
            controller.state.difficulty >= 1000,
            "Difficulty should not crash with zero elapsed: {}",
            controller.state.difficulty
        );
    }

    #[test]
    fn test_effective_inflation_at_genesis() {
        let policy = MonetaryPolicy::fast_test();
        let controller = DifficultyController::new(policy, 0, 1000, 0);

        // At height 0 with 0 supply, should return 0 without panic
        let inflation = controller.state.effective_inflation_bps(&controller.policy);
        assert_eq!(inflation, 0);
    }

    #[test]
    fn test_estimated_block_time_empty_epoch() {
        let policy = MonetaryPolicy::fast_test();
        let controller = DifficultyController::new(policy, 100_000, 1000, 0);

        // At epoch start, no blocks mined yet
        let est = controller.estimated_block_time(0);
        assert_eq!(
            est, controller.policy.target_block_time_secs as f64,
            "Should return target block time when no blocks in epoch"
        );
    }

    #[test]
    fn test_halving_with_single_halving() {
        let policy = MonetaryPolicy {
            initial_reward: 1000,
            halving_interval: 10,
            halving_count: 1,
            ..MonetaryPolicy::fast_test()
        };

        // At height 9: still halving phase with reward 1000
        assert!(policy.is_halving_phase(9));
        assert_eq!(policy.halving_reward(9), Some(1000));

        // At height 10: tail emission
        assert!(!policy.is_halving_phase(10));
        assert_eq!(policy.halving_reward(10), None);
    }

    #[test]
    fn test_large_supply_tail_reward() {
        let policy = MonetaryPolicy {
            tail_inflation_bps: 200,
            expected_fee_burn_rate_bps: 50,
            target_block_time_secs: 60,
            ..Default::default()
        };

        // Test with very large supply (near u64 max / 10)
        let large_supply = u64::MAX / 10;
        let tail_reward = policy.calculate_tail_reward(large_supply);

        // Should not overflow and should return a sensible value
        assert!(tail_reward > 0);
        assert!(tail_reward < large_supply); // Reward should be much smaller
                                             // than supply
    }

    #[test]
    fn test_multiple_epochs() {
        let policy = MonetaryPolicy {
            target_block_time_secs: 10,
            difficulty_adjustment_interval: 5,
            max_difficulty_adjustment_bps: 2500,
            initial_reward: 100,
            halving_interval: 1000, // Stay in halving phase
            halving_count: 10,
            ..MonetaryPolicy::fast_test()
        };
        let mut controller = DifficultyController::new(policy, 100_000, 1000, 0);

        // Track adjustments across multiple epochs
        let mut difficulties = vec![controller.state.difficulty];

        for epoch in 0..5 {
            // Each epoch: 5 blocks at consistent timing
            let base_time = epoch * 50;
            for i in 1..=5 {
                controller.process_block(base_time + i * 10);
            }
            difficulties.push(controller.state.difficulty);
        }

        // With consistent timing, difficulty should stabilize
        // Last two values should be close
        let last = *difficulties.last().unwrap() as i64;
        let second_last = difficulties[difficulties.len() - 2] as i64;
        assert!(
            (last - second_last).abs() < 200,
            "Difficulty should stabilize: {:?}",
            difficulties
        );
    }

    #[test]
    fn test_adjustment_count_increments() {
        let policy = MonetaryPolicy {
            difficulty_adjustment_interval: 3,
            ..MonetaryPolicy::fast_test()
        };
        let mut controller = DifficultyController::new(policy, 100_000, 1000, 0);

        assert_eq!(controller.state.adjustment_count, 0);

        // First epoch
        for i in 1..=3 {
            controller.process_block(i);
        }
        assert_eq!(controller.state.adjustment_count, 1);

        // Second epoch
        for i in 4..=6 {
            controller.process_block(i);
        }
        assert_eq!(controller.state.adjustment_count, 2);
    }

    #[test]
    fn test_epoch_counters_reset() {
        let policy = MonetaryPolicy {
            difficulty_adjustment_interval: 3,
            ..MonetaryPolicy::fast_test()
        };
        let mut controller = DifficultyController::new(policy, 100_000, 1000, 0);

        // Mine some blocks and record fees
        controller.process_block(1);
        controller.process_block(2);
        controller.record_fee_burn(100);

        assert!(controller.state.epoch_rewards_emitted > 0);
        assert_eq!(controller.state.epoch_fees_burned, 100);

        // Trigger adjustment
        controller.process_block(30); // time=30 for this block

        // Epoch counters should reset
        assert_eq!(controller.state.epoch_rewards_emitted, 0);
        assert_eq!(controller.state.epoch_fees_burned, 0);
        assert_eq!(controller.state.epoch_start_height, 3); // After 3 blocks
        assert_eq!(controller.state.epoch_start_time, 30);
    }

    #[test]
    fn test_current_halving_number() {
        let policy = MonetaryPolicy {
            halving_interval: 10,
            halving_count: 3,
            ..MonetaryPolicy::fast_test()
        };
        let mut controller = DifficultyController::new(policy, 100_000, 1000, 0);

        assert_eq!(controller.current_halving(), Some(0));

        for i in 1..=10 {
            controller.process_block(i);
        }
        assert_eq!(controller.current_halving(), Some(1));

        for i in 11..=20 {
            controller.process_block(i);
        }
        assert_eq!(controller.current_halving(), Some(2));

        // Transition to tail
        for i in 21..=30 {
            controller.process_block(i);
        }
        assert_eq!(controller.current_halving(), None);
    }

    // === BTH Tokenomics Tests ===

    /// Picocredits per BTH (1 BTH = 10^12 picocredits).
    const PICOCREDITS_PER_BTH: u128 = 1_000_000_000_000;

    /// Pin the BTH-denominated value of the library default policies after the
    /// nanoBTH -> picocredits re-denomination (#694): the initial block reward
    /// must still be exactly 50 BTH, now expressed in picocredits.
    #[test]
    fn test_initial_reward_is_50_bth_in_picocredits() {
        assert_eq!(
            MonetaryPolicy::default().initial_reward as u128,
            50 * PICOCREDITS_PER_BTH,
            "default initial_reward must be 50 BTH in picocredits"
        );
        assert_eq!(
            MonetaryPolicy::bitcoin_like().initial_reward as u128,
            50 * PICOCREDITS_PER_BTH,
            "bitcoin_like initial_reward must be 50 BTH in picocredits"
        );
    }

    /// The `u128` tail-reward entry point must be bit-for-bit identical to the
    /// `u64` version over the shared input range.
    #[test]
    fn test_tail_reward_u128_matches_u64_variant() {
        let policy = MonetaryPolicy::default();
        for supply in [0u64, 1, 999, 100_000_000, u64::MAX / 2, u64::MAX] {
            assert_eq!(
                policy.calculate_tail_reward(supply),
                policy.calculate_tail_reward_u128(supply as u128),
                "divergence at supply {supply}"
            );
        }
    }

    /// Verify the documented BTH emission schedule produces ~100M BTH in Phase
    /// 1.
    #[test]
    fn test_bth_phase1_total_emission() {
        // Use default policy (50 BTH initial reward, 5 halvings, 1,051,200
        // blocks/halving)
        let policy = MonetaryPolicy::default();

        // Verify halving parameters
        assert_eq!(policy.halving_count, 5, "5 halvings expected");
        assert_eq!(
            policy.halving_interval, 1_051_200,
            "~2 years per halving at 1 min blocks"
        );

        // Calculate total emission in Phase 1
        // R + R/2 + R/4 + R/8 + R/16 per halving_interval blocks
        let r = policy.initial_reward as u128;
        let h = policy.halving_interval as u128;

        let total_phase1_picocredits = h * r +           // Halving 0: 50 BTH/block
            h * (r / 2) +     // Halving 1: 25 BTH/block
            h * (r / 4) +     // Halving 2: 12.5 BTH/block
            h * (r / 8) +     // Halving 3: 6.25 BTH/block
            h * (r / 16); // Halving 4: 3.125 BTH/block

        // Convert to BTH (from picocredits)
        let total_phase1_bth = total_phase1_picocredits / PICOCREDITS_PER_BTH;

        // Should be approximately 100M BTH (within 5% tolerance)
        let expected = 100_000_000u128;
        let tolerance = expected / 20; // 5%
        assert!(
            (total_phase1_bth as i128 - expected as i128).unsigned_abs() < tolerance as u128,
            "Phase 1 emission {} BTH should be ~{} BTH (± {})",
            total_phase1_bth,
            expected,
            tolerance
        );
    }

    /// Verify Phase 2 tail reward calculation with BTH values.
    #[test]
    fn test_bth_phase2_tail_reward() {
        let policy = MonetaryPolicy::default();

        // At end of Phase 1, supply is ~100M BTH = 10^20 picocredits. This
        // exceeds u64::MAX, so the u128 entry point must be used (as the
        // node's ledger does, #333).
        let supply_at_phase2 = 100_000_000u128 * PICOCREDITS_PER_BTH; // 100M BTH

        let tail_reward = policy.calculate_tail_reward_u128(supply_at_phase2);

        // Expected calculation:
        // Target NET inflation: 2% of 100M = 2M BTH/year
        // Expected fee burns: 0.5% of 100M = 0.5M BTH/year
        // Gross needed: 2.5M BTH/year
        // Blocks per year at 1 min: 525,600
        // Tail reward = 2.5M BTH / 525,600 ≈ 4.76 BTH/block
        let expected_bth_per_block = 4.76;
        let actual_bth_per_block = tail_reward as f64 / PICOCREDITS_PER_BTH as f64;

        assert!(
            (actual_bth_per_block - expected_bth_per_block).abs() < 0.5,
            "Tail reward {} BTH/block should be ~{} BTH/block",
            actual_bth_per_block,
            expected_bth_per_block
        );
    }

    /// Verify the overflow envelope at picocredit scale (#694).
    ///
    /// At the pico scale, full Phase-1 supply no longer fits in u64 — that is
    /// expected, and it is why the node's supply accounting is u128 (#333) and
    /// why [`MonetaryPolicy::calculate_tail_reward_u128`] exists. u128 has
    /// astronomically more headroom than 250 years of 2% inflation needs.
    #[test]
    fn test_bth_overflow_safety() {
        // Phase 1 supply: 100M BTH = 10^20 picocredits.
        let phase1_supply_pico = 100_000_000u128 * PICOCREDITS_PER_BTH;

        // Exceeds u64::MAX — the reason full-scale supply tracking is u128.
        assert!(
            phase1_supply_pico > u64::MAX as u128,
            "100M BTH in picocredits ({}) must exceed u64::MAX",
            phase1_supply_pico
        );

        // 250 years of 2% inflation: (1.02)^250 ≈ 144.2 — trivially fits u128.
        let supply_250y = phase1_supply_pico * 144_210 / 1_000;
        assert!(
            supply_250y < u128::MAX / 1_000_000,
            "250-year supply {} must fit u128 with ample headroom",
            supply_250y
        );

        // Per-block quantities stay in u64: the initial (largest) block reward
        // is 50 BTH = 5e13 picocredits, far below u64::MAX.
        let initial_reward = MonetaryPolicy::default().initial_reward;
        assert!(initial_reward < u64::MAX / 100_000);
    }

    /// Simulate full Phase 1 with default policy and verify supply.
    #[test]
    fn test_bth_full_phase1_simulation() {
        let policy = MonetaryPolicy {
            // Use smaller intervals for faster test
            halving_interval: 100,
            halving_count: 5,
            initial_reward: 50_000_000_000_000, // 50 BTH in picocredits
            difficulty_adjustment_interval: 1000, // Avoid adjustments during test
            ..Default::default()
        };

        let mut controller = DifficultyController::new(policy.clone(), 0, 1000, 0);

        // Mine through all of Phase 1
        let total_blocks = policy.halving_interval * policy.halving_count as u64;
        for block in 1..=total_blocks {
            controller.process_block(block);
        }

        // Verify we're now in tail emission
        assert_eq!(controller.phase(), "Tail Emission");
        assert!(controller.state.tail_reward.is_some());

        // Verify supply was created (exact calculation for test params)
        // R × 100 × (1 + 0.5 + 0.25 + 0.125 + 0.0625) = R × 100 × 1.9375
        let expected_supply = 50_000_000_000_000u128 * 100 * 1937 / 1000;
        let actual_supply = controller.state.total_supply as u128;

        assert!(
            (actual_supply as i128 - expected_supply as i128).unsigned_abs()
                < expected_supply / 100,
            "Supply {} should be ~{} (within 1%)",
            actual_supply,
            expected_supply
        );
    }
    /// #1921: production-policy arithmetic, not the generic/fast-test schedule.
    #[test]
    fn monetary_1921_phase_and_demurrage_boundaries() {
        let p = mainnet_policy_mirror();
        let h = p.halving_interval;
        assert_eq!(
            (p.initial_reward, h, p.halving_count),
            (50_000_000_000_000, 6_307_200, 5)
        );
        assert_eq!(
            (
                p.tail_inflation_bps,
                p.expected_fee_burn_rate_bps,
                p.target_block_time_secs
            ),
            (200, 50, 5)
        );
        assert_eq!(p.target_blocks_per_year(), h);
        assert_eq!(p.tail_emission_start_height(), 31_536_000);
        let mut heights = vec![0, 1, u64::MAX];
        for k in 1..=5 {
            heights.extend([k * h - 1, k * h, k * h + 1]);
        }
        for height in heights {
            let phase1 = height < 5 * h;
            assert_eq!(p.is_halving_phase(height), phase1);
            let expected = if phase1 {
                Some(p.initial_reward >> (height / h))
            } else {
                None
            };
            assert_eq!(p.halving_reward(height), expected, "height {height}");
            assert_eq!(p.block_reward_at(height, 0), expected.unwrap_or(1));
            let reward = p.block_reward_at(height, 0);
            let share = p.lottery_emission_share(height, reward);
            assert!(share <= reward);
            assert_eq!(reward.saturating_sub(share) + share, reward);
            assert_eq!(
                p.demurrage_rate_bps(height),
                if height < h { 0 } else { 200 }
            );
        }
        assert_eq!(
            (0..5)
                .map(|k| p.halving_reward(k * h).unwrap())
                .collect::<Vec<_>>(),
            [
                50_000_000_000_000,
                25_000_000_000_000,
                12_500_000_000_000,
                6_250_000_000_000,
                3_125_000_000_000
            ]
        );
    }

    /// Synthetic helper inputs. The modulo-zero and panic cases are not
    /// claimed to be genesis-reachable blocks or accepted-chain exploits.
    #[test]
    fn monetary_1921_checked_tail_and_narrowing() {
        let p = mainnet_policy_mirror();
        let m = u64::MAX as u128;
        let b = m * p.halving_interval as u128 * 40;
        let zero_cast = (m + 1) * p.halving_interval as u128 * 40;
        assert_eq!(b, 4_653_892_168_868_035_357_845_120_000);
        assert_eq!(zero_cast, 4_653_892_168_868_035_358_097_408_000);
        for (supply, expected) in [
            (0, 1),
            (1, 1),
            (m, 73_117_802_169),
            (b - 1, u64::MAX - 1),
            (b, u64::MAX),
            (b + 1, u64::MAX),
            (zero_cast, 0),
        ] {
            assert_eq!(
                p.calculate_tail_reward_u128(supply),
                expected,
                "supply {supply}"
            );
            let net = supply.checked_mul(200).unwrap() / 10_000;
            let burn = supply.checked_mul(50).unwrap() / 10_000;
            assert!(net.checked_add(burn).is_some());
        }
        assert_eq!(
            (zero_cast * 200 / 10_000 + zero_cast * 50 / 10_000)
                / p.target_blocks_per_year() as u128,
            m + 1
        );
        for supply in [0, 1, u64::MAX] {
            assert_eq!(
                p.calculate_tail_reward(supply),
                p.calculate_tail_reward_u128(supply as u128)
            );
        }
        // Invokes the real ordinary multiply. The workspace release profile
        // has overflow-checks=true; a wrapping release build fails this test.
        assert!(std::panic::catch_unwind(|| p.calculate_tail_reward_u128(u128::MAX)).is_err());
    }

    #[test]
    fn monetary_1921_genesis_excluding_phase1_and_first_tail() {
        let p = mainnet_policy_mirror();
        let tail = p.tail_emission_start_height();
        assert_eq!(p.cumulative_issuance_at(0), 0);
        assert_eq!(p.cumulative_issuance_at(1), p.initial_reward as u128);
        let accepted = p.cumulative_issuance_at(tail - 1);
        let nominal: u128 = (0..5)
            .map(|k| (p.initial_reward >> k) as u128 * p.halving_interval as u128)
            .sum();
        assert_eq!(nominal, 611_010_000_000_000_000_000);
        assert_eq!(accepted, 611_009_950_000_000_000_000);
        assert_eq!(nominal - accepted, p.initial_reward as u128);
        assert_eq!(p.block_reward_at(tail, accepted), 2_421_874_801_813);
        assert_eq!(p.cumulative_issuance_at(tail), accepted + 2_421_874_801_813);
    }

    /// Legacy simulator's u64 shadow counters, not the node's u128 ledger.
    #[test]
    fn monetary_1921_legacy_raw_pico_counter_boundary() {
        let p = mainnet_policy_mirror();
        let reward = p.initial_reward;
        let good = u64::MAX / reward;
        assert_eq!(good, 368_934);
        let mut c = DifficultyController::new(p, 0, 1, 0);
        for height in 1..=good {
            assert_eq!(c.process_block(height * 5), reward);
        }
        assert_eq!(c.state.height, good);
        assert_eq!(c.state.total_supply, good * reward);
        assert_eq!(c.state.total_rewards_emitted, good * reward);
        assert_eq!(c.state.gross_issued, good as u128 * reward as u128);
        assert!(std::panic::catch_unwind(std::panic::AssertUnwindSafe(
            || c.process_block((good + 1) * 5)
        ))
        .is_err());
    }

    #[test]
    fn monetary_1921_legacy_height_successor_panics() {
        let mut c = DifficultyController::new(mainnet_policy_mirror(), 0, 1, 0);
        c.state.height = u64::MAX;
        assert!(std::panic::catch_unwind(|| c.block_reward()).is_err());
    }
}

/// Differential tests for the #1820 Aeneas-friendly rewrite of
/// `lottery_emission_bps` (`saturating_mul` ->
/// `checked_mul(..).unwrap_or(MAX)`). The pre-#1820 implementation is kept
/// verbatim as a reference copy.
#[cfg(test)]
mod aeneas_refactor_drt {
    use super::*;

    /// Pre-#1820 `MonetaryPolicy::lottery_emission_bps` (reference copy).
    fn lottery_emission_bps_reference(p: &MonetaryPolicy, height: u64) -> u32 {
        const LOTTERY_EMISSION_STEP_BPS: u32 = 1_000;
        const LOTTERY_EMISSION_MAX_BPS: u32 = 5_000;

        if p.halving_interval == 0 {
            return 0;
        }
        let epoch = (height / p.halving_interval).min(u32::MAX as u64) as u32;
        epoch
            .saturating_mul(LOTTERY_EMISSION_STEP_BPS)
            .min(LOTTERY_EMISSION_MAX_BPS)
    }

    /// Pre-#1820 `MonetaryPolicy::lottery_emission_share` (reference copy).
    fn lottery_emission_share_reference(p: &MonetaryPolicy, height: u64, reward: u64) -> u64 {
        (reward as u128 * lottery_emission_bps_reference(p, height) as u128 / 10_000) as u64
    }

    struct Gen(u64);

    impl Gen {
        fn next(&mut self) -> u64 {
            self.0 = self.0.wrapping_add(0x9E37_79B9_7F4A_7C15);
            let mut z = self.0;
            z = (z ^ (z >> 30)).wrapping_mul(0xBF58_476D_1CE4_E5B9);
            z = (z ^ (z >> 27)).wrapping_mul(0x94D0_49BB_1331_11EB);
            z ^ (z >> 31)
        }

        fn edge_u64(&mut self) -> u64 {
            match self.next() % 6 {
                0 => [0, 1, 2, u64::MAX, u64::MAX - 1, u64::MAX / 2][(self.next() % 6) as usize],
                1 => {
                    let p = 1u64 << (self.next() % 64);
                    match self.next() % 3 {
                        0 => p - 1,
                        1 => p,
                        _ => p.wrapping_add(1),
                    }
                }
                2 => self.next() % 32,
                _ => self.next(),
            }
        }
    }

    fn check(p: &MonetaryPolicy, height: u64, reward: u64) {
        assert_eq!(
            p.lottery_emission_bps(height),
            lottery_emission_bps_reference(p, height),
            "interval {} height {height}",
            p.halving_interval
        );
        assert_eq!(
            p.lottery_emission_share(height, reward),
            lottery_emission_share_reference(p, height, reward),
            "interval {} height {height} reward {reward}",
            p.halving_interval
        );
    }

    #[test]
    fn lottery_emission_matches_reference_at_edges() {
        let mut p = mainnet_policy_mirror();
        let intervals = [0u64, 1, 2, 3, p.halving_interval, u64::MAX / 2, u64::MAX];
        let heights = [
            0u64,
            1,
            2,
            4_294_967,
            4_294_968,
            u32::MAX as u64,
            u32::MAX as u64 + 1,
            u64::MAX,
        ];
        let rewards = [0u64, 1, 9_999, 10_000, u64::MAX];
        for &i in &intervals {
            p.halving_interval = i;
            for &h in &heights {
                for &r in &rewards {
                    check(&p, h, r);
                }
                // Each epoch boundary up to and past the 50% cap, and the
                // u32 saturation point of epoch * 1000.
                for e in [1u64, 2, 4, 5, 6, 4_294_967, 4_294_968, u32::MAX as u64] {
                    let h = i.saturating_mul(e);
                    check(&p, h, u64::MAX);
                    check(&p, h.saturating_sub(1), u64::MAX);
                }
            }
        }
    }

    #[test]
    fn lottery_emission_matches_reference_sweep() {
        let mut p = mainnet_policy_mirror();
        let mut g = Gen(0x1820_0010);
        for _ in 0..200_000 {
            p.halving_interval = g.edge_u64();
            check(&p, g.edge_u64(), g.edge_u64());
        }
    }

    /// The equivalence the rewrite rests on, exhaustive over the u32 edges.
    #[test]
    #[allow(
        clippy::manual_saturating_arithmetic,
        reason = "the spelling under test"
    )]
    fn checked_mul_unwrap_or_max_is_saturating_mul_u32() {
        let edges = [
            0u32,
            1,
            2,
            1_000,
            4_294_967,
            4_294_968,
            u16::MAX as u32,
            u16::MAX as u32 + 1,
            u32::MAX / 2,
            u32::MAX / 2 + 1,
            u32::MAX - 1,
            u32::MAX,
        ];
        for &a in &edges {
            for &b in &edges {
                assert_eq!(
                    a.checked_mul(b).unwrap_or(u32::MAX),
                    a.saturating_mul(b),
                    "{a} * {b}"
                );
            }
        }
    }
}
