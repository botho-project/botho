#![deny(clippy::print_stdout)]
// Sweep SEED constants use mnemonic hex groupings (e.g. 0xB07A_0902_D2).
#![allow(clippy::unusual_byte_groupings)]
// Test-only style lints in files whose contents are hash-pinned by the
// CT-contract inventory (tag.rs, fee_curve.rs, monetary.rs,
// provenance_factor_sweep.rs); allowed here rather than editing those files.
#![cfg_attr(
    test,
    allow(
        clippy::manual_range_contains,
        clippy::unnecessary_cast,
        clippy::identity_op,
        clippy::useless_vec
    )
)]

//! Botho fee system with size-based progressive pricing.
//!
//! This module implements Botho's fee model with two key features:
//!
//! 1. **Size-based fees**: Fees scale with transaction size in bytes, ensuring
//!    larger transactions (e.g., PQ-Private with ~63 KB signatures) pay more.
//!
//! 2. **Progressive wealth taxation**: A cluster factor (1x-6x) multiplies the
//!    size fee, discouraging wealth concentration.
//!
//! ## Transaction Types
//!
//! | Type             | Ring Signature | Fee Formula                           |
//! |------------------|----------------|---------------------------------------|
//! | Standard-Private | CLSAG (~700B)  | fee_per_byte × size × cluster_factor  |
//! | Minting          | N/A            | No fee (PoW reward claim)             |
//!
//! ## Key Concepts
//!
//! - **Cluster**: An identity derived from coin creation (minting rewards). A
//!   lineage marker that fades through trade via decay.
//! - **Tag Vector**: Each UTXO carries weights indicating what fraction of its
//!   value traces back to each cluster origin.
//! - **Cluster Wealth**: Total value in the system tagged to a given cluster.
//! - **Cluster Factor**: Wealthy clusters pay 1x-6x the base fee.
//!
//! ## Rationale
//!
//! - **Size-based fees** ensure fair pricing regardless of transaction type.
//! - **Progressive taxation** discourages wealth concentration by increasing
//!   fees for wealthy clusters.
//! - **Minting transactions** create new coins via PoW and establish new
//!   clusters.

pub mod analysis;
pub mod bridge_import;
pub mod consensus_fee;
pub mod crypto;
pub mod demurrage;
pub mod dynamic_fee;
pub mod fee_floor_inputs;
pub mod monetary;
pub mod signing;
#[cfg(any(feature = "cli", test))]
pub mod simulation;
pub mod validate;
pub mod wide;

mod age_decay;
mod block_decay;
mod cluster;
mod entropy_decay;
mod fee_curve;
mod lottery;
mod tag;
mod transfer;

pub use bridge_import::{
    apply_import_floor, import_cluster_factor, import_cluster_id, import_cluster_id_for_height,
    import_epoch, BRIDGE_IMPORT_EPOCH_BLOCKS, BRIDGE_IMPORT_FACTOR_FLOOR,
};
pub use cluster::{ClusterId, ClusterWealth};
// One shared consensus fee model for every economic sim (#1695).
pub use consensus_fee::{
    consensus_fee_breakdown, consensus_fee_model, consensus_tx_size_bytes, mainnet_monetary_policy,
    ClaimedClass, ConsensusFeeBreakdown, ConsensusFeeInputs, ConsensusFeeParams, FeeModelMode,
    SimConsensusFee, RELAY_MIN_TX_FEE,
};
// Pure mirrors of the ledger's DB-dependent fee-floor resolution (#1697).
pub use fee_floor_inputs::{
    resolve_fee_floor, resolve_fee_floor_at, FloorOutput, ResolvedFeeFloor, TagPair,
    WALLET_CLUSTER_DECAY_RATE,
};

// ============================================================================
// Monetary Policy (Canonical)
// ============================================================================
//
// The Two-Phase Monetary Model is the canonical approach:
// - Phase 1 (Halving): Fixed rewards with halving schedule, timing-based
//   difficulty
// - Phase 2 (Tail): Fixed tail reward, inflation-targeting difficulty
//
// Key insight: Difficulty should adapt to hit monetary targets, not rewards.
// This gives minters predictable income while absorbing fee volatility.
pub use monetary::{DifficultyController, MonetaryPolicy, MonetaryState, MonetaryStats};

pub use age_decay::{apply_age_decay, ring_cluster_factor, AgeDecayConfig, RingDecayInfo};
pub use block_decay::{
    AndDecayConfig, AndTagVector, BlockAwareTagVector, BlockDecayConfig, RateLimitedDecayConfig,
    RateLimitedTagVector,
};
pub use crypto::{
    // Phase 2/3: ZK fee verification
    CommittedFeeProof,
    CommittedFeeProofBuilder,
    CommittedFeeProofVerifier,
    CommittedFeeProver,
    CommittedFeeVerifier,
    CommittedTagVector,
    CommittedTagVectorSecret,
    // Phase 2B: Entropy proofs
    EntropyLinkageProof,
    EntropyProof,
    EntropyProofBuilder,
    EntropyProofVerifier,
    EntropyRangeProof,
    ExtendedTxSignature,
    RingTagData,
    SegmentOrProof,
    TransactionVersion,
    ENTROPY_SCALE,
    MIN_ENTROPY_THRESHOLD_SCALED,
};
pub use demurrage::{
    capitalized_reset_charge, demurrage_charge, demurrage_settlement_charge,
    ring_centroid_implied_factor, ring_elapsed_centroid, ring_elapsed_quantile,
    spend_demurrage_charge, BLOCKS_PER_YEAR_5S, FACTOR_SCALE, SETTLEMENT_HORIZON_BLOCKS,
};
pub use dynamic_fee::{DynamicFeeBase, DynamicFeeState, FeeSuggestion};
pub use entropy_decay::{
    apply_entropy_decay, calculate_entropy_decay, compare_decay_modes, conservative_entropy_delta,
    ring_entropy_decay, AttackResult, AttackStrategy, DecayBlockReason, DecayMode,
    EntropyDecayConfig, EntropyDecayResult, EntropyScaling, RingDecayBlockReason,
    RingEntropyDecayInfo, SimUtxo,
};
pub use fee_curve::{
    count_outputs_with_memos,
    ClusterFactorCurve,
    FeeConfig,
    FeeCurve,
    FeeRateBps,
    SegmentParams,
    TransactionType,
    // Phase 2/3: ZK-compatible fee curve
    ZkFeeCurve,
    // Picocredits per BTH (ledger scale) — consumed by the bridge-import floor.
    PICO_PER_BTH,
};
pub use signing::{
    create_tag_signature, verify_tag_signature, TagSigningConfig, TagSigningError, TagSigningInput,
    TagSigningOutput, TagSigningResult,
};
pub use tag::{TagVector, TagWeight, TAG_WEIGHT_SCALE};
pub use transfer::{
    execute_transfer, execute_transfer_and, execute_transfer_with_fee, mint, mint_and, Account,
    AndTransferConfig, AndTransferResult, BlockAwareAccount, TransferConfig, TransferError,
    TransferResult,
};
pub use validate::{
    validate_committed_tag_structure,
    validate_committed_tags,
    // Phase 2/3: Complete transaction validation
    validate_committed_transaction,
    CommittedTagConfig,
    CommittedTagValidationError,
    CommittedTagValidationResult,
    CommittedTransactionError,
    CommittedTransactionResult,
};

// ============================================================================
// Lottery Fee Redistribution
// ============================================================================
//
// The lottery system redistributes 80% of fees to random UTXO holders.
// Default selection mode: Uniform (Path C, value-free / CT-compatible).
// - Sybil resistance from the circulation window + endogenous reward cap
//   (`sybil_reward_cap`), not the weight formula (splitting is net-zero).
// - CT-clean: the draw reads no confidential UTXO value.
//
// See docs/research/ct-compatible-lottery-selection.md for the analysis.
pub use lottery::{
    count_eligible, draw_winners, draw_winners_with_seed, sybil_reward_cap, verify_drawing,
    LotteryCandidate, LotteryDrawConfig, LotteryResult, LotteryWinner, SelectionMode,
    CIRCULATION_WINDOW_BLOCKS, LOTTERY_BASE_FEE_PICO,
};
