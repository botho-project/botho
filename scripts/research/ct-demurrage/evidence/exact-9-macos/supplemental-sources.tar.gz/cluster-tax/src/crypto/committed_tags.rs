//! Committed cluster tags with Pedersen commitments.
//!
//! Phase 2 implementation that hides tag weights using cryptographic
//! commitments. This provides full privacy for cluster attribution while still
//! allowing verification of tag conservation and fee sufficiency.

use crate::{ClusterId, TagWeight, TAG_WEIGHT_SCALE};
use curve25519_dalek::{
    constants::RISTRETTO_BASEPOINT_POINT,
    ristretto::{CompressedRistretto, RistrettoPoint},
    scalar::Scalar,
    traits::Identity,
};
use sha2::{Digest, Sha512};
use std::collections::HashMap;

/// Domain separator for cluster tag generators.
const CLUSTER_GENERATOR_DOMAIN_TAG: &[u8] = b"mc_cluster_tag_generator";

/// Domain separator for total mass generator.
const TOTAL_MASS_GENERATOR_DOMAIN_TAG: &[u8] = b"mc_cluster_total_mass_generator";

/// The standard blinding generator (same as in ring signatures).
pub fn blinding_generator() -> RistrettoPoint {
    RISTRETTO_BASEPOINT_POINT
}

/// Derive a generator point for a specific cluster ID.
///
/// Each cluster has a unique generator H_k derived via hash-to-curve.
/// This ensures the discrete log relationship between generators is unknown.
pub fn cluster_generator(cluster_id: ClusterId) -> RistrettoPoint {
    let mut hasher = Sha512::new();
    hasher.update(CLUSTER_GENERATOR_DOMAIN_TAG);
    hasher.update(cluster_id.0.to_le_bytes());
    crate::crypto::dalek_compat::point_from_hash(hasher)
}

/// Derive the generator for total mass commitments.
pub fn total_mass_generator() -> RistrettoPoint {
    let mut hasher = Sha512::new();
    hasher.update(TOTAL_MASS_GENERATOR_DOMAIN_TAG);
    crate::crypto::dalek_compat::point_from_hash(hasher)
}

/// A Pedersen commitment to tag mass for a single cluster.
///
/// Commitment: C = mass * H_k + blinding * G
/// where mass = value * weight (in millionths, like weight).
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct CommittedTagMass {
    /// The cluster this commitment refers to.
    pub cluster_id: ClusterId,

    /// Pedersen commitment to the tag mass.
    pub commitment: CompressedRistretto,
}

impl CommittedTagMass {
    /// Create a new commitment to tag mass.
    ///
    /// # Arguments
    /// * `cluster_id` - The cluster identifier
    /// * `mass` - The tag mass (value * weight, in millionths)
    /// * `blinding` - Random blinding factor
    pub fn new(cluster_id: ClusterId, mass: u64, blinding: Scalar) -> Self {
        let h_k = cluster_generator(cluster_id);
        let g = blinding_generator();

        let commitment = Scalar::from(mass) * h_k + blinding * g;

        Self {
            cluster_id,
            commitment: commitment.compress(),
        }
    }

    /// Create a commitment to zero mass (for padding).
    pub fn zero(cluster_id: ClusterId, blinding: Scalar) -> Self {
        Self::new(cluster_id, 0, blinding)
    }

    /// Decompress the commitment point.
    pub fn decompress(&self) -> Option<RistrettoPoint> {
        self.commitment.decompress()
    }
}

/// Secret data for a committed tag entry.
#[derive(Clone, Debug)]
pub struct TagMassSecret {
    /// The cluster identifier.
    pub cluster_id: ClusterId,

    /// The actual tag mass (value * weight).
    pub mass: u64,

    /// The blinding factor used in the commitment.
    pub blinding: Scalar,
}

impl TagMassSecret {
    /// Create the corresponding commitment.
    pub fn commit(&self) -> CommittedTagMass {
        CommittedTagMass::new(self.cluster_id, self.mass, self.blinding)
    }
}

/// Full committed tag vector for a TxOut.
///
/// Contains commitments to tag masses for multiple clusters.
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct CommittedTagVector {
    /// Commitments for each cluster with non-zero weight.
    /// Sorted by cluster_id for deterministic ordering.
    pub entries: Vec<CommittedTagMass>,

    /// Commitment to total attributed mass.
    /// Used for computing background weight.
    pub total_commitment: CompressedRistretto,
}

impl CommittedTagVector {
    /// Create an empty committed tag vector (fully background).
    pub fn empty() -> Self {
        Self {
            entries: Vec::new(),
            total_commitment: RistrettoPoint::identity().compress(),
        }
    }

    /// Create from secrets.
    pub fn from_secrets(secrets: &CommittedTagVectorSecret) -> Self {
        let mut entries: Vec<CommittedTagMass> =
            secrets.entries.iter().map(|s| s.commit()).collect();

        // Sort by cluster_id for deterministic ordering
        entries.sort_by_key(|e| e.cluster_id.0);

        // Compute total commitment
        let h_total = total_mass_generator();
        let g = blinding_generator();
        let total_point = Scalar::from(secrets.total_mass) * h_total + secrets.total_blinding * g;

        Self {
            entries,
            total_commitment: total_point.compress(),
        }
    }

    /// Number of cluster entries.
    pub fn len(&self) -> usize {
        self.entries.len()
    }

    /// Check if empty.
    pub fn is_empty(&self) -> bool {
        self.entries.is_empty()
    }

    /// Compute aggregate commitment (sum of all entry commitments).
    ///
    /// This is useful for batch verification.
    pub fn aggregate_commitment(&self) -> Option<RistrettoPoint> {
        let mut sum = RistrettoPoint::identity();
        for entry in &self.entries {
            sum += entry.decompress()?;
        }
        Some(sum)
    }
}

/// Secret data for a full committed tag vector.
#[derive(Clone, Debug)]
pub struct CommittedTagVectorSecret {
    /// Secrets for each cluster entry.
    pub entries: Vec<TagMassSecret>,

    /// Total attributed mass (sum of all entry masses).
    pub total_mass: u64,

    /// Blinding factor for total commitment.
    pub total_blinding: Scalar,
}

impl CommittedTagVectorSecret {
    /// Create an empty secret (fully background).
    pub fn empty() -> Self {
        Self {
            entries: Vec::new(),
            total_mass: 0,
            total_blinding: Scalar::ZERO,
        }
    }

    /// Create from a plaintext tag vector and output value.
    ///
    /// # Arguments
    /// * `value` - The output value
    /// * `tags` - Map of cluster_id to weight (in TAG_WEIGHT_SCALE units)
    /// * `rng` - Random number generator for blinding factors
    pub fn from_plaintext<R: rand_core::CryptoRng>(
        value: u64,
        tags: &HashMap<ClusterId, TagWeight>,
        rng: &mut R,
    ) -> Self {
        let mut entries = Vec::new();
        let mut total_mass = 0u64;
        let mut total_blinding = Scalar::ZERO;

        for (&cluster_id, &weight) in tags {
            // mass = value * weight / TAG_WEIGHT_SCALE
            // We keep mass in millionths for precision
            let mass = (value as u128 * weight as u128 / TAG_WEIGHT_SCALE as u128) as u64;

            let blinding = crate::crypto::dalek_compat::random_scalar(rng);

            entries.push(TagMassSecret {
                cluster_id,
                mass,
                blinding,
            });

            total_mass += mass;
            total_blinding += blinding;
        }

        Self {
            entries,
            total_mass,
            total_blinding,
        }
    }

    /// Create the corresponding committed vector.
    pub fn commit(&self) -> CommittedTagVector {
        CommittedTagVector::from_secrets(self)
    }

    /// Apply decay to the tag masses.
    ///
    /// Returns a new secret with decayed masses and new blinding factors.
    pub fn apply_decay<R: rand_core::CryptoRng>(&self, decay_rate: TagWeight, rng: &mut R) -> Self {
        let decay_factor = TAG_WEIGHT_SCALE - decay_rate;

        let entries: Vec<TagMassSecret> = self
            .entries
            .iter()
            .map(|e| {
                let decayed_mass =
                    (e.mass as u128 * decay_factor as u128 / TAG_WEIGHT_SCALE as u128) as u64;
                TagMassSecret {
                    cluster_id: e.cluster_id,
                    mass: decayed_mass,
                    blinding: crate::crypto::dalek_compat::random_scalar(rng),
                }
            })
            .collect();

        let total_mass =
            (self.total_mass as u128 * decay_factor as u128 / TAG_WEIGHT_SCALE as u128) as u64;

        Self {
            entries,
            total_mass,
            total_blinding: crate::crypto::dalek_compat::random_scalar(rng),
        }
    }

    /// Merge multiple secrets into one (for combining inputs).
    ///
    /// Sums masses per cluster across all inputs.
    pub fn merge<R: rand_core::CryptoRng>(secrets: &[Self], rng: &mut R) -> Self {
        let mut cluster_masses: HashMap<ClusterId, u64> = HashMap::new();

        for secret in secrets {
            for entry in &secret.entries {
                *cluster_masses.entry(entry.cluster_id).or_insert(0) += entry.mass;
            }
        }

        let entries: Vec<TagMassSecret> = cluster_masses
            .into_iter()
            .map(|(cluster_id, mass)| TagMassSecret {
                cluster_id,
                mass,
                blinding: crate::crypto::dalek_compat::random_scalar(rng),
            })
            .collect();

        let total_mass: u64 = entries.iter().map(|e| e.mass).sum();

        Self {
            entries,
            total_mass,
            total_blinding: crate::crypto::dalek_compat::random_scalar(rng),
        }
    }
}

/// Proof that tag masses are conserved with decay.
///
/// For each cluster k, proves:
///   sum(C_output_k) = (1 - decay) * sum(C_input_k) + r_diff * G
///
/// This is a Schnorr-style proof of knowledge of the blinding difference.
#[derive(Clone, Debug)]
pub struct TagConservationProof {
    /// Per-cluster conservation proofs.
    pub cluster_proofs: Vec<ClusterConservationProof>,

    /// Proof that total masses are consistent.
    pub total_proof: SchnorrProof,
}

/// Conservation proof for a single cluster.
#[derive(Clone, Debug)]
pub struct ClusterConservationProof {
    /// The cluster this proof applies to.
    pub cluster_id: ClusterId,

    /// Schnorr proof of blinding difference knowledge.
    pub proof: SchnorrProof,
}

/// A simple Schnorr proof of knowledge of discrete log.
///
/// Proves knowledge of `x` such that `P = x * G`.
#[derive(Clone, Debug)]
pub struct SchnorrProof {
    /// Commitment: R = k * G
    pub commitment: CompressedRistretto,

    /// Response: s = k + c * x
    pub response: Scalar,
}

/// Builder for creating tag conservation proofs.
///
/// Given input and output committed tag vectors, this proves that:
/// sum(output_mass) = (1 - decay) * sum(input_mass)
/// for each cluster, in zero knowledge.
#[derive(Clone, Debug)]
pub struct TagConservationProver {
    /// Input tag secrets (from pseudo-outputs)
    pub input_secrets: Vec<CommittedTagVectorSecret>,

    /// Output tag secrets
    pub output_secrets: Vec<CommittedTagVectorSecret>,

    /// Decay rate (in TAG_WEIGHT_SCALE units)
    pub decay_rate: TagWeight,
}

impl TagConservationProver {
    /// Create a new prover.
    pub fn new(
        input_secrets: Vec<CommittedTagVectorSecret>,
        output_secrets: Vec<CommittedTagVectorSecret>,
        decay_rate: TagWeight,
    ) -> Self {
        Self {
            input_secrets,
            output_secrets,
            decay_rate,
        }
    }

    /// Generate the conservation proof.
    ///
    /// Returns None if conservation doesn't hold.
    pub fn prove<R: rand_core::CryptoRng>(&self, rng: &mut R) -> Option<TagConservationProof> {
        let decay_factor = TAG_WEIGHT_SCALE - self.decay_rate;

        // Collect all cluster IDs
        let mut cluster_ids: std::collections::BTreeSet<ClusterId> =
            std::collections::BTreeSet::new();
        for secret in &self.input_secrets {
            for entry in &secret.entries {
                cluster_ids.insert(entry.cluster_id);
            }
        }
        for secret in &self.output_secrets {
            for entry in &secret.entries {
                cluster_ids.insert(entry.cluster_id);
            }
        }

        let mut cluster_proofs = Vec::new();

        for &cluster_id in &cluster_ids {
            // Sum input masses and blindings for this cluster
            let (input_mass, input_blinding) =
                self.sum_cluster_data(&self.input_secrets, cluster_id);

            // Apply decay to input mass
            let decayed_input_mass =
                (input_mass as u128 * decay_factor as u128 / TAG_WEIGHT_SCALE as u128) as u64;

            // Sum output masses and blindings for this cluster
            let (output_mass, output_blinding) =
                self.sum_cluster_data(&self.output_secrets, cluster_id);

            // Check conservation (with tolerance for rounding)
            let tolerance = (input_mass / 1000).max(1);
            if output_mass > decayed_input_mass + tolerance {
                return None; // Conservation violated
            }

            // Compute blinding difference
            // We need: C_out - (decay_factor/SCALE) * C_in = r_diff * G
            // But since we're dealing with integer masses, we compute:
            // output_blinding - (decay_factor * input_blinding / SCALE) ≈ r_diff
            // This is an approximation; exact would need more care

            let scaled_input_blinding = input_blinding
                * Scalar::from(decay_factor as u64)
                * Scalar::from(TAG_WEIGHT_SCALE as u64).invert();

            let blinding_diff = output_blinding - scaled_input_blinding;

            // Create Schnorr proof for this blinding difference
            let proof =
                SchnorrProof::prove(blinding_diff, &self.conservation_context(cluster_id), rng);

            cluster_proofs.push(ClusterConservationProof { cluster_id, proof });
        }

        // Prove total mass conservation
        let (total_input_mass, total_input_blinding) = self.sum_total_data(&self.input_secrets);
        let decayed_total =
            (total_input_mass as u128 * decay_factor as u128 / TAG_WEIGHT_SCALE as u128) as u64;
        let (total_output_mass, total_output_blinding) = self.sum_total_data(&self.output_secrets);

        let tolerance = (total_input_mass / 1000).max(1);
        if total_output_mass > decayed_total + tolerance {
            return None;
        }

        let scaled_total_blinding = total_input_blinding
            * Scalar::from(decay_factor as u64)
            * Scalar::from(TAG_WEIGHT_SCALE as u64).invert();
        let total_blinding_diff = total_output_blinding - scaled_total_blinding;

        let total_proof = SchnorrProof::prove(total_blinding_diff, b"total_conservation", rng);

        Some(TagConservationProof {
            cluster_proofs,
            total_proof,
        })
    }

    fn sum_cluster_data(
        &self,
        secrets: &[CommittedTagVectorSecret],
        cluster_id: ClusterId,
    ) -> (u64, Scalar) {
        let mut total_mass = 0u64;
        let mut total_blinding = Scalar::ZERO;

        for secret in secrets {
            for entry in &secret.entries {
                if entry.cluster_id == cluster_id {
                    total_mass += entry.mass;
                    total_blinding += entry.blinding;
                }
            }
        }

        (total_mass, total_blinding)
    }

    fn sum_total_data(&self, secrets: &[CommittedTagVectorSecret]) -> (u64, Scalar) {
        let mut total_mass = 0u64;
        let mut total_blinding = Scalar::ZERO;

        for secret in secrets {
            total_mass += secret.total_mass;
            total_blinding += secret.total_blinding;
        }

        (total_mass, total_blinding)
    }

    fn conservation_context(&self, cluster_id: ClusterId) -> Vec<u8> {
        let mut context = b"cluster_conservation_".to_vec();
        context.extend_from_slice(&cluster_id.0.to_le_bytes());
        context
    }
}

/// Verifier for tag conservation proofs.
pub struct TagConservationVerifier {
    /// Input committed tag vectors (from pseudo-outputs)
    pub input_commitments: Vec<CommittedTagVector>,

    /// Output committed tag vectors
    pub output_commitments: Vec<CommittedTagVector>,

    /// Decay rate (in TAG_WEIGHT_SCALE units)
    pub decay_rate: TagWeight,
}

impl TagConservationVerifier {
    /// Create a new verifier.
    pub fn new(
        input_commitments: Vec<CommittedTagVector>,
        output_commitments: Vec<CommittedTagVector>,
        decay_rate: TagWeight,
    ) -> Self {
        Self {
            input_commitments,
            output_commitments,
            decay_rate,
        }
    }

    /// Verify the conservation proof.
    pub fn verify(&self, proof: &TagConservationProof) -> bool {
        let decay_factor = TAG_WEIGHT_SCALE - self.decay_rate;

        // Verify each cluster proof
        for cluster_proof in &proof.cluster_proofs {
            let cluster_id = cluster_proof.cluster_id;

            // Sum input commitments for this cluster
            let input_sum = self.sum_cluster_commitments(&self.input_commitments, cluster_id);
            let input_sum = match input_sum {
                Some(p) => p,
                None => return false,
            };

            // Sum output commitments for this cluster
            let output_sum = self.sum_cluster_commitments(&self.output_commitments, cluster_id);
            let output_sum = match output_sum {
                Some(p) => p,
                None => return false,
            };

            // Compute expected difference point
            // diff = C_out - (decay_factor/SCALE) * C_in
            let scale_inv = Scalar::from(TAG_WEIGHT_SCALE as u64).invert();
            let scaled_input = Scalar::from(decay_factor as u64) * scale_inv * input_sum;
            let diff = output_sum - scaled_input;

            // Verify Schnorr proof
            let context = self.conservation_context(cluster_id);
            if !cluster_proof.proof.verify(&diff.compress(), &context) {
                return false;
            }
        }

        // Verify total proof
        let input_total = self.sum_total_commitments(&self.input_commitments);
        let output_total = self.sum_total_commitments(&self.output_commitments);

        let (input_total, output_total) = match (input_total, output_total) {
            (Some(i), Some(o)) => (i, o),
            _ => return false,
        };

        let scale_inv = Scalar::from(TAG_WEIGHT_SCALE as u64).invert();
        let scaled_input = Scalar::from(decay_factor as u64) * scale_inv * input_total;
        let diff = output_total - scaled_input;

        proof
            .total_proof
            .verify(&diff.compress(), b"total_conservation")
    }

    fn sum_cluster_commitments(
        &self,
        commitments: &[CommittedTagVector],
        cluster_id: ClusterId,
    ) -> Option<RistrettoPoint> {
        let mut sum = RistrettoPoint::identity();
        for vec in commitments {
            for entry in &vec.entries {
                if entry.cluster_id == cluster_id {
                    sum += entry.decompress()?;
                }
            }
        }
        Some(sum)
    }

    fn sum_total_commitments(&self, commitments: &[CommittedTagVector]) -> Option<RistrettoPoint> {
        let mut sum = RistrettoPoint::identity();
        for vec in commitments {
            sum += vec.total_commitment.decompress()?;
        }
        Some(sum)
    }

    fn conservation_context(&self, cluster_id: ClusterId) -> Vec<u8> {
        let mut context = b"cluster_conservation_".to_vec();
        context.extend_from_slice(&cluster_id.0.to_le_bytes());
        context
    }
}

// ============================================================================
// ZK Fee Verification Proofs (Phase 2/3)
// ============================================================================

use crate::fee_curve::{SegmentParams, ZkFeeCurve};

/// Proof that a value lies within a range [lo, hi).
///
/// This is a simplified range proof using Schnorr-style commitments.
/// For production, this should be replaced with Bulletproofs or similar.
#[derive(Clone, Debug)]
pub struct RangeProof {
    /// Commitment to (value - lo), proving value >= lo
    pub lower_commitment: CompressedRistretto,
    /// Commitment to (hi - 1 - value), proving value < hi
    pub upper_commitment: CompressedRistretto,
    /// Schnorr proof for lower bound
    pub lower_proof: SchnorrProof,
    /// Schnorr proof for upper bound
    pub upper_proof: SchnorrProof,
}

/// Proof that a linear inequality holds on a committed value.
///
/// Proves: `result >= intercept + slope * committed_value`
/// where `result` is public and `committed_value` is hidden.
#[derive(Clone, Debug)]
pub struct LinearRelationProof {
    /// Commitment to excess = result - (intercept + slope * value)
    pub excess_commitment: CompressedRistretto,
    /// Proof that excess is non-negative
    pub excess_proof: SchnorrProof,
}

/// Complete proof for a single fee curve segment.
///
/// Proves:
/// 1. Wealth falls within segment bounds [w_lo, w_hi)
/// 2. Fee satisfies the linear inequality for this segment
#[derive(Clone, Debug)]
pub struct SegmentFeeProof {
    /// Range proof: wealth ∈ [w_lo, w_hi)
    pub range_proof: RangeProof,
    /// Linear proof: fee >= intercept + slope * wealth
    pub linear_proof: LinearRelationProof,
}

/// OR-proof hiding which segment the wealth falls into.
///
/// Uses Sigma protocol OR-composition where the prover computes a real
/// proof for the actual segment and simulates proofs for other segments.
/// The verifier cannot distinguish which segment is real.
#[derive(Clone, Debug)]
pub struct SegmentOrProof {
    /// One proof per segment (3 for standard curve)
    pub segment_proofs: Vec<SegmentFeeProof>,
    /// Challenge values for Fiat-Shamir (sum to hash of all commitments)
    pub challenges: Vec<Scalar>,
}

/// Complete proof for privacy-preserving fee verification.
///
/// This ties together the segment OR-proof with the tag conservation
/// proof to provide complete Phase 2 transaction validation.
#[derive(Clone, Debug)]
pub struct CommittedFeeProof {
    /// Proves fee is sufficient for committed effective_wealth
    pub fee_proof: SegmentOrProof,
    /// Links the fee proof wealth commitment to the tag commitments
    pub wealth_linkage: WealthLinkageProof,
}

/// Proof linking the wealth commitment in fee proof to tag commitments.
///
/// Proves that C_wealth = Σ_k (cluster_wealth_k * C_tag_mass_k)
/// without revealing the actual wealth value.
#[derive(Clone, Debug)]
pub struct WealthLinkageProof {
    /// Commitment to total effective wealth
    pub wealth_commitment: CompressedRistretto,
    /// Schnorr proof of correct computation from tag masses
    pub linkage_proof: SchnorrProof,
}

/// Builder for creating committed fee proofs.
pub struct CommittedFeeProver {
    /// The ZK-compatible fee curve
    pub curve: ZkFeeCurve,
    /// Committed wealth (hidden value)
    pub wealth: u64,
    /// Blinding factor for wealth commitment
    pub wealth_blinding: Scalar,
    /// Public fee paid
    pub fee_paid: u64,
    /// Public base fee (size-based)
    pub base_fee: u64,
}

impl CommittedFeeProver {
    /// Create a new prover.
    pub fn new(
        curve: ZkFeeCurve,
        wealth: u64,
        wealth_blinding: Scalar,
        fee_paid: u64,
        base_fee: u64,
    ) -> Self {
        Self {
            curve,
            wealth,
            wealth_blinding,
            fee_paid,
            base_fee,
        }
    }

    /// Generate the complete fee proof.
    ///
    /// Returns `None` if the fee is insufficient for the wealth level.
    pub fn prove<R: rand_core::CryptoRng>(&self, rng: &mut R) -> Option<SegmentOrProof> {
        // Check that fee is actually sufficient
        // fee = base_fee * factor(wealth) / FACTOR_SCALE
        let factor = self.curve.factor(self.wealth as u128);
        let required_fee =
            (self.base_fee as u128 * factor as u128 / ZkFeeCurve::FACTOR_SCALE as u128) as u64;
        if self.fee_paid < required_fee {
            return None;
        }

        // Find the real segment using in_segment
        let real_segment = (0..ZkFeeCurve::NUM_SEGMENTS)
            .find(|&i| self.curve.in_segment(self.wealth as u128, i))
            .unwrap_or(ZkFeeCurve::NUM_SEGMENTS - 1);
        let all_params = self.curve.all_segment_params();

        // Generate random challenges for simulated segments
        let mut challenges = vec![Scalar::ZERO; ZkFeeCurve::NUM_SEGMENTS];
        let mut simulated_challenges_sum = Scalar::ZERO;

        for (i, challenge) in challenges.iter_mut().enumerate() {
            if i != real_segment {
                *challenge = crate::crypto::dalek_compat::random_scalar(rng);
                simulated_challenges_sum += *challenge;
            }
        }

        // Build proofs for each segment
        let mut segment_proofs = Vec::with_capacity(ZkFeeCurve::NUM_SEGMENTS);

        for (i, params) in all_params.iter().enumerate() {
            if i == real_segment {
                // Real proof - prove honestly
                let proof = self.prove_segment_real(params, rng);
                segment_proofs.push(proof);
            } else {
                // Simulated proof - construct valid-looking proof for challenge
                let proof = self.prove_segment_simulated(params, challenges[i], rng);
                segment_proofs.push(proof);
            }
        }

        // Compute real challenge via Fiat-Shamir
        let total_challenge = self.compute_total_challenge(&segment_proofs);
        challenges[real_segment] = total_challenge - simulated_challenges_sum;

        Some(SegmentOrProof {
            segment_proofs,
            challenges,
        })
    }

    fn prove_segment_real<R: rand_core::CryptoRng>(
        &self,
        params: &SegmentParams,
        rng: &mut R,
    ) -> SegmentFeeProof {
        let g = blinding_generator();

        // Range proof: wealth in [w_lo, w_hi). `w_lo`/`w_hi` are u128 (pico);
        // the committed wealth is u64. Compute the diffs in u128 and saturate
        // back to u64 for the Scalar commitment (Phase-2 ZK path is provisional
        // and not consensus-binding — see the #626 ZkFeeCurve re-anchor note).
        let lower_diff = (self.wealth as u128)
            .saturating_sub(params.w_lo)
            .min(u64::MAX as u128) as u64;
        let upper_diff = params
            .w_hi
            .saturating_sub(self.wealth as u128 + 1)
            .min(u64::MAX as u128) as u64;

        let lower_blinding = crate::crypto::dalek_compat::random_scalar(rng);
        let upper_blinding = crate::crypto::dalek_compat::random_scalar(rng);

        let lower_commitment = (Scalar::from(lower_diff) * g + lower_blinding * g).compress();
        let upper_commitment = (Scalar::from(upper_diff) * g + upper_blinding * g).compress();

        let range_proof = RangeProof {
            lower_commitment,
            upper_commitment,
            lower_proof: SchnorrProof::prove(lower_blinding, b"range_lower", rng),
            upper_proof: SchnorrProof::prove(upper_blinding, b"range_upper", rng),
        };

        // Linear proof: fee >= intercept + slope * wealth
        // Compute factor using HEAD's SegmentParams: factor = intercept/FACTOR_SCALE +
        // slope * (w - w_lo) / SLOPE_SCALE
        let w_offset = (self.wealth as u128).saturating_sub(params.w_lo) as i128;
        let slope_contribution =
            (params.slope_scaled as i128 * w_offset / ZkFeeCurve::SLOPE_SCALE) as i64;
        let expected_factor = ((params.intercept_scaled + slope_contribution)
            / ZkFeeCurve::FACTOR_SCALE as i64)
            .max(0) as u64;
        let required = (self.base_fee as u128 * expected_factor as u128) as u64;
        let excess = self.fee_paid.saturating_sub(required);

        let excess_blinding = crate::crypto::dalek_compat::random_scalar(rng);
        let excess_commitment = (Scalar::from(excess) * g + excess_blinding * g).compress();

        let linear_proof = LinearRelationProof {
            excess_commitment,
            excess_proof: SchnorrProof::prove(excess_blinding, b"linear_excess", rng),
        };

        SegmentFeeProof {
            range_proof,
            linear_proof,
        }
    }

    fn prove_segment_simulated<R: rand_core::CryptoRng>(
        &self,
        _params: &SegmentParams,
        _challenge: Scalar,
        rng: &mut R,
    ) -> SegmentFeeProof {
        // For simulated proofs, generate valid-looking but fake proofs
        // In a real implementation, these would be constructed to satisfy
        // the OR-composition verification equation
        let g = blinding_generator();

        let lower_blinding = crate::crypto::dalek_compat::random_scalar(rng);
        let upper_blinding = crate::crypto::dalek_compat::random_scalar(rng);

        let range_proof = RangeProof {
            lower_commitment: (crate::crypto::dalek_compat::random_scalar(rng) * g).compress(),
            upper_commitment: (crate::crypto::dalek_compat::random_scalar(rng) * g).compress(),
            lower_proof: SchnorrProof::prove(lower_blinding, b"range_lower", rng),
            upper_proof: SchnorrProof::prove(upper_blinding, b"range_upper", rng),
        };

        let excess_blinding = crate::crypto::dalek_compat::random_scalar(rng);
        let linear_proof = LinearRelationProof {
            excess_commitment: (crate::crypto::dalek_compat::random_scalar(rng) * g).compress(),
            excess_proof: SchnorrProof::prove(excess_blinding, b"linear_excess", rng),
        };

        SegmentFeeProof {
            range_proof,
            linear_proof,
        }
    }

    fn compute_total_challenge(&self, proofs: &[SegmentFeeProof]) -> Scalar {
        let mut hasher = Sha512::new();
        hasher.update(b"mc_segment_or_challenge");
        hasher.update(self.fee_paid.to_le_bytes());
        hasher.update(self.base_fee.to_le_bytes());

        for proof in proofs {
            hasher.update(proof.range_proof.lower_commitment.as_bytes());
            hasher.update(proof.range_proof.upper_commitment.as_bytes());
            hasher.update(proof.linear_proof.excess_commitment.as_bytes());
        }

        crate::crypto::dalek_compat::scalar_from_hash(hasher)
    }
}

/// Verifier for committed fee proofs.
pub struct CommittedFeeVerifier {
    /// The ZK-compatible fee curve
    pub curve: ZkFeeCurve,
    /// Public fee paid
    pub fee_paid: u64,
    /// Public base fee (size-based)
    pub base_fee: u64,
}

impl CommittedFeeVerifier {
    /// Create a new verifier.
    pub fn new(curve: ZkFeeCurve, fee_paid: u64, base_fee: u64) -> Self {
        Self {
            curve,
            fee_paid,
            base_fee,
        }
    }

    /// Verify a segment OR-proof.
    ///
    /// Returns `true` if the proof is valid.
    pub fn verify(&self, proof: &SegmentOrProof) -> bool {
        // Check correct number of segments
        if proof.segment_proofs.len() != ZkFeeCurve::NUM_SEGMENTS {
            return false;
        }
        if proof.challenges.len() != ZkFeeCurve::NUM_SEGMENTS {
            return false;
        }

        // Verify challenges sum to the expected total
        let expected_challenge = self.compute_expected_challenge(proof);
        let actual_sum: Scalar = proof.challenges.iter().sum();

        if expected_challenge != actual_sum {
            return false;
        }

        // Verify each segment proof (at least one must be valid)
        // In a full OR-proof, we would verify the structure matches the challenges
        for segment_proof in &proof.segment_proofs {
            // Basic structural validation
            if segment_proof
                .range_proof
                .lower_commitment
                .decompress()
                .is_none()
            {
                return false;
            }
            if segment_proof
                .range_proof
                .upper_commitment
                .decompress()
                .is_none()
            {
                return false;
            }
            if segment_proof
                .linear_proof
                .excess_commitment
                .decompress()
                .is_none()
            {
                return false;
            }
        }

        true
    }

    fn compute_expected_challenge(&self, proof: &SegmentOrProof) -> Scalar {
        let mut hasher = Sha512::new();
        hasher.update(b"mc_segment_or_challenge");
        hasher.update(self.fee_paid.to_le_bytes());
        hasher.update(self.base_fee.to_le_bytes());

        for segment_proof in &proof.segment_proofs {
            hasher.update(segment_proof.range_proof.lower_commitment.as_bytes());
            hasher.update(segment_proof.range_proof.upper_commitment.as_bytes());
            hasher.update(segment_proof.linear_proof.excess_commitment.as_bytes());
        }

        crate::crypto::dalek_compat::scalar_from_hash(hasher)
    }
}

/// Builder for complete committed fee proofs including wealth linkage.
pub struct CommittedFeeProofBuilder {
    /// Input tag secrets for computing effective wealth
    pub input_secrets: Vec<CommittedTagVectorSecret>,
    /// Cluster wealth values (public)
    pub cluster_wealth: std::collections::HashMap<ClusterId, u64>,
    /// The ZK fee curve
    pub curve: ZkFeeCurve,
    /// Public fee paid
    pub fee_paid: u64,
    /// Public base fee
    pub base_fee: u64,
}

impl CommittedFeeProofBuilder {
    /// Create a new builder.
    pub fn new(
        input_secrets: Vec<CommittedTagVectorSecret>,
        cluster_wealth: std::collections::HashMap<ClusterId, u64>,
        curve: ZkFeeCurve,
        fee_paid: u64,
        base_fee: u64,
    ) -> Self {
        Self {
            input_secrets,
            cluster_wealth,
            curve,
            fee_paid,
            base_fee,
        }
    }

    /// Compute effective wealth from input tag secrets.
    ///
    /// Effective wealth = Σ_k (cluster_wealth_k * tag_mass_k)
    pub fn compute_effective_wealth(&self) -> (u64, Scalar) {
        let mut total_wealth = 0u128;
        let mut total_blinding = Scalar::ZERO;

        for secret in &self.input_secrets {
            for entry in &secret.entries {
                let cw = self
                    .cluster_wealth
                    .get(&entry.cluster_id)
                    .copied()
                    .unwrap_or(0);
                total_wealth += entry.mass as u128 * cw as u128 / TAG_WEIGHT_SCALE as u128;
                total_blinding += entry.blinding * Scalar::from(cw);
            }
        }

        (total_wealth as u64, total_blinding)
    }

    /// Build the complete proof.
    pub fn build<R: rand_core::CryptoRng>(&self, rng: &mut R) -> Option<CommittedFeeProof> {
        let (effective_wealth, wealth_blinding) = self.compute_effective_wealth();

        // Create fee proof
        let fee_prover = CommittedFeeProver::new(
            self.curve.clone(),
            effective_wealth,
            wealth_blinding,
            self.fee_paid,
            self.base_fee,
        );

        let fee_proof = fee_prover.prove(rng)?;

        // Create wealth linkage proof
        let g = blinding_generator();
        let wealth_commitment =
            (Scalar::from(effective_wealth) * g + wealth_blinding * g).compress();
        let linkage_proof = SchnorrProof::prove(wealth_blinding, b"wealth_linkage", rng);

        let wealth_linkage = WealthLinkageProof {
            wealth_commitment,
            linkage_proof,
        };

        Some(CommittedFeeProof {
            fee_proof,
            wealth_linkage,
        })
    }
}

/// Verifier for complete committed fee proofs.
pub struct CommittedFeeProofVerifier {
    /// Input committed tag vectors
    pub input_commitments: Vec<CommittedTagVector>,
    /// Cluster wealth values (public)
    pub cluster_wealth: std::collections::HashMap<ClusterId, u64>,
    /// The ZK fee curve
    pub curve: ZkFeeCurve,
    /// Public fee paid
    pub fee_paid: u64,
    /// Public base fee
    pub base_fee: u64,
}

impl CommittedFeeProofVerifier {
    /// Create a new verifier.
    pub fn new(
        input_commitments: Vec<CommittedTagVector>,
        cluster_wealth: std::collections::HashMap<ClusterId, u64>,
        curve: ZkFeeCurve,
        fee_paid: u64,
        base_fee: u64,
    ) -> Self {
        Self {
            input_commitments,
            cluster_wealth,
            curve,
            fee_paid,
            base_fee,
        }
    }

    /// Verify the complete fee proof.
    pub fn verify(&self, proof: &CommittedFeeProof) -> bool {
        // Verify wealth commitment is valid
        if proof
            .wealth_linkage
            .wealth_commitment
            .decompress()
            .is_none()
        {
            return false;
        }

        // Verify the fee OR-proof
        let fee_verifier =
            CommittedFeeVerifier::new(self.curve.clone(), self.fee_paid, self.base_fee);

        if !fee_verifier.verify(&proof.fee_proof) {
            return false;
        }

        // Verify linkage proof structure
        // In a full implementation, we would verify that the wealth_commitment
        // is correctly computed from the input tag commitments
        true
    }
}

impl SchnorrProof {
    /// Create a Schnorr proof for knowledge of `x` where `P = x * G`.
    pub fn prove<R: rand_core::CryptoRng>(x: Scalar, context: &[u8], rng: &mut R) -> Self {
        let g = blinding_generator();
        let p = x * g;

        // Random nonce
        let k = crate::crypto::dalek_compat::random_scalar(rng);
        let r = k * g;

        // Challenge (Fiat-Shamir)
        let c = Self::compute_challenge(&r.compress(), &p.compress(), context);

        // Response
        let s = k + c * x;

        Self {
            commitment: r.compress(),
            response: s,
        }
    }

    /// Verify a Schnorr proof.
    pub fn verify(&self, p: &CompressedRistretto, context: &[u8]) -> bool {
        let g = blinding_generator();

        let r = match self.commitment.decompress() {
            Some(r) => r,
            None => return false,
        };

        let p_point = match p.decompress() {
            Some(p) => p,
            None => return false,
        };

        let c = Self::compute_challenge(&self.commitment, p, context);

        // Verify: s * G = R + c * P
        let lhs = self.response * g;
        let rhs = r + c * p_point;

        lhs == rhs
    }

    fn compute_challenge(
        r: &CompressedRistretto,
        p: &CompressedRistretto,
        context: &[u8],
    ) -> Scalar {
        let mut hasher = Sha512::new();
        hasher.update(b"mc_schnorr_challenge");
        hasher.update(context);
        hasher.update(r.as_bytes());
        hasher.update(p.as_bytes());
        crate::crypto::dalek_compat::scalar_from_hash(hasher)
    }
}

// ============================================================================
// Generators for ZK Fee Verification
// ============================================================================

/// Domain separator for wealth generator in fee proofs.
const WEALTH_GENERATOR_DOMAIN_TAG: &[u8] = b"mc_zk_fee_wealth_generator";

/// Domain separator for fee generator in fee proofs.
const FEE_GENERATOR_DOMAIN_TAG: &[u8] = b"mc_zk_fee_fee_generator";

/// Derive the generator for wealth commitments in fee proofs.
pub fn wealth_generator() -> RistrettoPoint {
    let mut hasher = Sha512::new();
    hasher.update(WEALTH_GENERATOR_DOMAIN_TAG);
    crate::crypto::dalek_compat::point_from_hash(hasher)
}

/// Derive the generator for fee commitments in fee proofs.
pub fn fee_generator() -> RistrettoPoint {
    let mut hasher = Sha512::new();
    hasher.update(FEE_GENERATOR_DOMAIN_TAG);
    crate::crypto::dalek_compat::point_from_hash(hasher)
}

#[cfg(test)]
mod tests {
    use super::*;
    use bth_util_from_random::OsRng;

    #[test]
    fn test_cluster_generators_unique() {
        let g1 = cluster_generator(ClusterId(1));
        let g2 = cluster_generator(ClusterId(2));
        let g3 = cluster_generator(ClusterId(1));

        // Different clusters have different generators
        assert_ne!(g1, g2);

        // Same cluster always gives same generator
        assert_eq!(g1, g3);
    }

    #[test]
    fn test_committed_tag_mass_creation() {
        let cluster = ClusterId(42);
        let mass = 500_000u64; // 50% weight on 1 unit value
        let blinding = crate::crypto::dalek_compat::random_scalar(&mut OsRng);

        let committed = CommittedTagMass::new(cluster, mass, blinding);
        assert_eq!(committed.cluster_id, cluster);
        assert!(committed.decompress().is_some());
    }

    #[test]
    fn test_commitment_homomorphism() {
        let cluster = ClusterId(1);
        let mass1 = 300_000u64;
        let mass2 = 200_000u64;
        let blinding1 = crate::crypto::dalek_compat::random_scalar(&mut OsRng);
        let blinding2 = crate::crypto::dalek_compat::random_scalar(&mut OsRng);

        let c1 = CommittedTagMass::new(cluster, mass1, blinding1);
        let c2 = CommittedTagMass::new(cluster, mass2, blinding2);
        let c_sum = CommittedTagMass::new(cluster, mass1 + mass2, blinding1 + blinding2);

        // C1 + C2 should equal C_sum (homomorphic property)
        let sum = c1.decompress().unwrap() + c2.decompress().unwrap();
        assert_eq!(sum, c_sum.decompress().unwrap());
    }

    #[test]
    fn test_committed_tag_vector_from_secrets() {
        let mut tags = HashMap::new();
        tags.insert(ClusterId(1), 500_000); // 50%
        tags.insert(ClusterId(2), 300_000); // 30%

        let value = 1000u64;
        let secret = CommittedTagVectorSecret::from_plaintext(value, &tags, &mut OsRng);
        let committed = secret.commit();

        assert_eq!(committed.len(), 2);

        // Entries should be sorted by cluster_id
        assert_eq!(committed.entries[0].cluster_id, ClusterId(1));
        assert_eq!(committed.entries[1].cluster_id, ClusterId(2));
    }

    #[test]
    fn test_decay_application() {
        let mut tags = HashMap::new();
        tags.insert(ClusterId(1), TAG_WEIGHT_SCALE); // 100%

        let value = 1_000_000u64;
        let secret = CommittedTagVectorSecret::from_plaintext(value, &tags, &mut OsRng);

        // 5% decay
        let decay_rate = 50_000;
        let decayed = secret.apply_decay(decay_rate, &mut OsRng);

        // Mass should be 95% of original
        let expected_mass = (value as u128 * 950_000 / TAG_WEIGHT_SCALE as u128) as u64;
        assert_eq!(decayed.total_mass, expected_mass);
    }

    #[test]
    fn test_schnorr_proof() {
        let x = crate::crypto::dalek_compat::random_scalar(&mut OsRng);
        let p = (x * blinding_generator()).compress();

        let proof = SchnorrProof::prove(x, b"test_context", &mut OsRng);
        assert!(proof.verify(&p, b"test_context"));

        // Wrong context should fail
        assert!(!proof.verify(&p, b"wrong_context"));

        // Wrong point should fail
        let wrong_p = (crate::crypto::dalek_compat::random_scalar(&mut OsRng)
            * blinding_generator())
        .compress();
        assert!(!proof.verify(&wrong_p, b"test_context"));
    }

    #[test]
    fn test_conservation_proof_valid() {
        // Input: 1,000,000 units with 100% weight to cluster 1
        let mut input_tags = HashMap::new();
        input_tags.insert(ClusterId(1), TAG_WEIGHT_SCALE);

        let input_value = 1_000_000u64;
        let input_secret =
            CommittedTagVectorSecret::from_plaintext(input_value, &input_tags, &mut OsRng);

        // After 5% decay, output should have 95% of input mass
        let decay_rate = 50_000; // 5%
        let output_secret = input_secret.apply_decay(decay_rate, &mut OsRng);

        // Create prover
        let prover = TagConservationProver::new(
            vec![input_secret.clone()],
            vec![output_secret.clone()],
            decay_rate,
        );

        // Generate proof
        let proof = prover.prove(&mut OsRng);
        assert!(proof.is_some(), "Should generate valid proof");
        let proof = proof.unwrap();

        // Create verifier with commitments
        let input_commitment = input_secret.commit();
        let output_commitment = output_secret.commit();

        let verifier = TagConservationVerifier::new(
            vec![input_commitment],
            vec![output_commitment],
            decay_rate,
        );

        // Verify
        assert!(verifier.verify(&proof), "Proof should verify");
    }

    #[test]
    fn test_conservation_proof_multiple_clusters() {
        // Input: 50% cluster 1, 30% cluster 2
        let mut input_tags = HashMap::new();
        input_tags.insert(ClusterId(1), 500_000);
        input_tags.insert(ClusterId(2), 300_000);

        let input_value = 1_000_000u64;
        let input_secret =
            CommittedTagVectorSecret::from_plaintext(input_value, &input_tags, &mut OsRng);

        let decay_rate = 50_000;
        let output_secret = input_secret.apply_decay(decay_rate, &mut OsRng);

        let prover = TagConservationProver::new(
            vec![input_secret.clone()],
            vec![output_secret.clone()],
            decay_rate,
        );

        let proof = prover.prove(&mut OsRng).expect("Should generate proof");

        // Should have proofs for both clusters
        assert_eq!(proof.cluster_proofs.len(), 2);

        let verifier = TagConservationVerifier::new(
            vec![input_secret.commit()],
            vec![output_secret.commit()],
            decay_rate,
        );

        assert!(verifier.verify(&proof));
    }

    #[test]
    fn test_conservation_proof_rejects_inflation() {
        // Input: 50% to cluster 1
        let mut input_tags = HashMap::new();
        input_tags.insert(ClusterId(1), 500_000);

        let input_value = 1_000_000u64;
        let input_secret =
            CommittedTagVectorSecret::from_plaintext(input_value, &input_tags, &mut OsRng);

        // Try to create inflated output (more than decayed input)
        let mut inflated_tags = HashMap::new();
        inflated_tags.insert(ClusterId(1), 600_000); // 60% > 50% * 95%

        let output_value = 1_000_000u64;
        let inflated_output =
            CommittedTagVectorSecret::from_plaintext(output_value, &inflated_tags, &mut OsRng);

        let decay_rate = 50_000;
        let prover =
            TagConservationProver::new(vec![input_secret], vec![inflated_output], decay_rate);

        // Should fail to generate proof
        let proof = prover.prove(&mut OsRng);
        assert!(proof.is_none(), "Should reject inflated tags");
    }

    // ========================================================================
    // Proof Size Measurements (Issue #80)
    // ========================================================================

    /// Helper to create a secret with N clusters.
    fn create_n_cluster_secret(num_clusters: usize, value: u64) -> CommittedTagVectorSecret {
        let mut tags = HashMap::new();
        let weight_per_cluster = TAG_WEIGHT_SCALE / num_clusters as u32;

        for i in 0..num_clusters {
            tags.insert(ClusterId(i as u64), weight_per_cluster);
        }

        CommittedTagVectorSecret::from_plaintext(value, &tags, &mut OsRng)
    }

    #[test]
    fn test_schnorr_proof_size() {
        let x = crate::crypto::dalek_compat::random_scalar(&mut OsRng);
        let proof = SchnorrProof::prove(x, b"test", &mut OsRng);
        let bytes = proof.to_bytes();

        // SchnorrProof: 32 (commitment) + 32 (response) = 64 bytes
        assert_eq!(bytes.len(), 64, "SchnorrProof should be 64 bytes");
    }

    #[test]
    fn test_committed_tag_vector_sizes() {
        // Test sizes for different cluster counts
        for num_clusters in [1, 3, 5, 8] {
            let secret = create_n_cluster_secret(num_clusters, 1_000_000);
            let committed = secret.commit();
            let bytes = committed.to_bytes();

            // Expected: 4 (entry count) + 40*n (entries) + 32 (total commitment)
            // Entry: 8 (cluster_id) + 32 (commitment) = 40 bytes
            let expected_size = 4 + (40 * num_clusters) + 32;
            assert_eq!(
                bytes.len(),
                expected_size,
                "CommittedTagVector with {} clusters should be {} bytes",
                num_clusters,
                expected_size
            );
        }
    }

    #[test]
    fn test_conservation_proof_sizes() {
        // Test sizes for different cluster counts
        for num_clusters in [1, 3, 5, 8] {
            let input_secret = create_n_cluster_secret(num_clusters, 1_000_000);
            let decay_rate = 50_000;
            let output_secret = input_secret.apply_decay(decay_rate, &mut OsRng);

            let prover =
                TagConservationProver::new(vec![input_secret], vec![output_secret], decay_rate);

            let proof = prover.prove(&mut OsRng).expect("Should generate proof");
            let bytes = proof.to_bytes();

            // Expected: 4 (count) + 72*n (cluster proofs) + 64 (total proof)
            // ClusterConservationProof: 8 (cluster_id) + 64 (schnorr) = 72 bytes
            let expected_size = 4 + (72 * num_clusters) + 64;
            assert_eq!(
                bytes.len(),
                expected_size,
                "TagConservationProof with {} clusters should be {} bytes",
                num_clusters,
                expected_size
            );
        }
    }

    #[test]
    fn test_proof_size_under_1kb_target() {
        // Issue #80: Verify proof overhead < 1KB for typical 1-3 cluster transactions
        for num_clusters in [1, 2, 3] {
            let input_secret = create_n_cluster_secret(num_clusters, 1_000_000);
            let decay_rate = 50_000;
            let output_secret = input_secret.apply_decay(decay_rate, &mut OsRng);

            let prover = TagConservationProver::new(
                vec![input_secret.clone()],
                vec![output_secret.clone()],
                decay_rate,
            );

            let proof = prover.prove(&mut OsRng).expect("Should generate proof");

            // Calculate total proof overhead (what goes in the transaction)
            let conservation_proof_size = proof.to_bytes().len();
            let input_vector_size = input_secret.commit().to_bytes().len();
            let output_vector_size = output_secret.commit().to_bytes().len();

            let total_overhead = conservation_proof_size + input_vector_size + output_vector_size;

            assert!(
                total_overhead < 1024,
                "Total proof overhead for {} clusters should be < 1KB, got {} bytes",
                num_clusters,
                total_overhead
            );
        }
    }

    #[test]
    fn test_proof_size_summary() {
        // Print a summary table of proof sizes for documentation
        // This test always passes but provides useful data

        let scenarios = [1, 2, 3, 5, 8];
        let decay_rate = 50_000;

        for &num_clusters in &scenarios {
            let input_secret = create_n_cluster_secret(num_clusters, 1_000_000);
            let output_secret = input_secret.apply_decay(decay_rate, &mut OsRng);

            let prover = TagConservationProver::new(
                vec![input_secret.clone()],
                vec![output_secret.clone()],
                decay_rate,
            );

            let proof = prover.prove(&mut OsRng).expect("Should generate proof");

            let conservation_size = proof.to_bytes().len();
            let input_vec_size = input_secret.commit().to_bytes().len();
            let output_vec_size = output_secret.commit().to_bytes().len();
            let total = conservation_size + input_vec_size + output_vec_size;

            // Verify expected sizes
            assert_eq!(conservation_size, 4 + (72 * num_clusters) + 64);
            assert_eq!(input_vec_size, 4 + (40 * num_clusters) + 32);
            assert_eq!(output_vec_size, 4 + (40 * num_clusters) + 32);

            // Document the relationship
            let _expected_total = 4 + (72 * num_clusters) + 64  // conservation proof
                + 2 * (4 + (40 * num_clusters) + 32); // 2x tag vectors
            assert_eq!(total, _expected_total);
        }
    }
}
