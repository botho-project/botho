//! Agent-based economic simulation for cluster taxation validation.
//!
//! This module provides infrastructure for simulating diverse economic actors
//! (whales, merchants, retail users, etc.) interacting under the cluster tax
//! mechanism, allowing empirical validation of parameter choices.
//!
//! ## Privacy Simulation
//!
//! The `privacy` submodule models the effective bits of privacy that users can
//! expect from ring signatures under various adversary models and network
//! conditions.
//!
//! ## Constrained Analysis
//!
//! The `constrained_analysis` submodule extends privacy simulation to analyze
//! the impact of wallet-side tag-based constraints (age similarity, factor
//! ceiling) on ring signature anonymity.
//!
//! ## Lottery Simulation
//!
//! The `lottery` submodule models the lottery-based fee redistribution system
//! as an alternative to cluster-based progressive fees.

mod agent;
pub mod agents;
#[cfg(any(feature = "cli", test))]
pub mod bridge_import_sweep;
#[cfg(any(feature = "cli", test))]
pub mod constrained_analysis;
#[cfg(any(feature = "cli", test))]
pub mod decoy_flood_sweep;
#[cfg(any(feature = "cli", test))]
pub mod decoy_quantile_sweep;
#[cfg(any(feature = "cli", test))]
pub mod demurrage_quantization_sweep;
#[cfg(any(feature = "cli", test))]
pub mod downgrade_overcharge_sweep;
#[cfg(any(feature = "cli", test))]
pub mod emission_sweep;
pub mod lottery;
#[cfg(any(feature = "cli", test))]
pub mod lottery_reward_cap_faithful;
pub mod lottery_reward_cap_sweep;
#[cfg(any(feature = "cli", test))]
pub mod lottery_selection_sweep;
#[cfg(any(feature = "cli", test))]
pub mod lottery_sybil_brake_sweep;
#[cfg(any(feature = "cli", test))]
pub mod m2;
#[cfg(any(feature = "cli", test))]
pub mod m2_production;
mod metrics;
#[cfg(any(feature = "cli", test))]
pub mod privacy;
#[cfg(any(feature = "cli", test))]
pub mod privacy_routes;
#[cfg(any(feature = "cli", test))]
pub mod provenance_factor_sweep;
#[cfg(any(feature = "cli", test))]
pub mod redistribution_redesign;
mod runner;
#[cfg(any(feature = "cli", test))]
pub mod settlement_horizon_sweep;
mod state;

pub use agent::{Action, Agent, AgentId};
pub use agents::{
    MarketMakerAgent, MerchantAgent, MinterAgent, MixerServiceAgent, RetailUserAgent, WhaleAgent,
    WhaleStrategy,
};
pub use lottery::{
    run_sybil_test, LotteryConfig, LotterySimulation, SybilStrategy, SybilTestResult,
};
pub use metrics::{Metrics, SimulationMetrics};
pub use runner::{run_simulation, RoundSummary, SimulationConfig, SimulationResult};
pub use state::{MonetaryStats, SimulationState};
